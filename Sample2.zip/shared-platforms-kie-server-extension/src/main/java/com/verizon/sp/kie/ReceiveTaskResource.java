package com.verizon.sp.kie;

import static org.kie.server.remote.rest.common.util.RestUtils.notFound;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.JSON;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.XML;
import static org.kie.server.remote.rest.jbpm.resources.Messages.TASK_NOT_FOUND;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Variant;

import org.jbpm.process.instance.ProcessInstance;
import org.jbpm.services.api.DefinitionService;
import org.jbpm.services.api.DeploymentNotFoundException;
import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.model.NodeDesc;
import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.ProcessInstanceDesc;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.query.QueryContext;
import org.kie.server.remote.rest.common.Header;
import org.kie.server.remote.rest.common.util.RestUtils;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

/**
 * Provides a kie-server extension to interact with a task identified as
 * ReceiveTask in RHPAM. A Receive Task has a correlationMap that identifies the
 * message its waiting for. An example of the correlationMap content can be:
 * OrderId=1122, which means that the work item handler is waiting for an
 * inbound message to include the same OrderId to continue. The implementation
 * uses the complete {@link WorkItem} logic to continue operation once the
 * signal is received
 * 
 * @author tordi7z
 */
@Api(value = "Verizon Receive Task")
@Path("verizon/server/")
public class ReceiveTaskResource {
	private static final Logger logger = LoggerFactory.getLogger(ReceiveTaskResource.class);
	private ProcessService processService;
	private RuntimeDataService runtimeDataService;
	private KieServerRegistry context;
	private MarshallerHelper marshallerHelper;
	private DefinitionService definitionService;
	
	private static final String WORK_FLOW_ID="workflowId";

	// @formatter:off
	private static final String VAR_MAP_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
			+ "<map-type>\n" 
			+ "    <entries>\n" 
			+ "        <entry>\n" 
			+ "            <key>correlationMap</key>\n"
			+ "            <value xsi:type=\"xs:map-type\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"\n "
			+ "                   xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
			+ "                <entries>\n" 
			+ "                    <entry>\n"
			+ "                        <key>orderId</key>\n"
			+ "                        <value xsi:type=\"xs:int\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"\n "
			+ "                               xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">25</value>\n"
			+ "                    </entry>\n" + "                    <entry>\n"
			+ "                        <key>person</key>\n"
			+ "                        <value xsi:type=\"person\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
			+ "                            <name>john</name>\n" 
			+ "                        </value>\n"
			+ "                    </entry>\n" 
			+ "                </entries>\n" 
			+ "            </value>\n"
			+ "        </entry>\n"
			+ "        <entry>\n" 
			+ "            <key>additionalProperty</key>\n"
			+ "            <value xsi:type=\"xs:string\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"\n "
			+ "                   xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">additional value</value>\n"
			+ "        </entry>\n"
			+ "    </entries>\n" 
			+ "</map-type>";
	
	private static final String VAR_MAP_JSON = "{\n" 
			+ "    \"correlationMap\": {\n" 
			+ "        \"orderId\": 25, \n"
			+ "        \"person\": {\n" 
			+ "            \"Person\": {\n" 
			+ "                \"name\": \"john\"\n"
			+ "            }\n" 
			+ "        }\n" 
			+ "    },\n" 
			+ "    \"additionalProperty\": \"additional value\"/n"
			+ "}";
	// @formatter:on

	public ReceiveTaskResource(ProcessService processService, RuntimeDataService runtimeDataService, DefinitionService definitionService,
			KieServerRegistry context) {
		this.processService = processService;
		this.runtimeDataService = runtimeDataService;
		this.definitionService = definitionService;
		this.context = context;
		this.marshallerHelper = new MarshallerHelper(context);
	}

	/**
	 * Receive a task with a correlationMap payload. The active process ids for
	 * a given process name are evaluated to be waiting for a work item handler
	 * with an specific task name and a matching correlationMap.
	 * 
	 * @param headers
	 * @param processName
	 * @param taskName
	 * @param payload
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Receive task with correlationMap", response = Long.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 201, response = Long.class, message = "completed"),
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process or Task not found") })
	@POST
	@Path("receive-task/{processName}/{taskName}")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response receiveTask(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "process name", required = true) @PathParam("processName") String processName,
			@ApiParam(value = "task name", required = true) @PathParam("taskName") String taskName,
			@ApiParam(value = "correlationMap", required = false, examples = @Example(value = {
					@ExampleProperty(mediaType = XML, value = VAR_MAP_XML),
					@ExampleProperty(mediaType = JSON, value = VAR_MAP_JSON) })) @DefaultValue("") String payload) {
		logger.debug("Processing Receive task for processName: {}, taskName: {}, payload: {}", processName, taskName,
				payload);
		final Variant v = RestUtils.getVariant(headers);
		final String contentType = RestUtils.getContentType(headers);
		// Assume first container for conversation headers
		String containerId = context.getContainers().isEmpty() ? "default-container"
				: context.getContainers().get(0).getContainerId();
		Map<String, Object> payloadItems;
		/////
		// SHORT CIRCUIT! NOT A VALID JSON/XML PAYLOAD
		/////
		try {
			payloadItems = marshallerHelper.unmarshal(payload, contentType, Map.class);
			logger.debug("Payload Items {}", payloadItems);
		} catch (Exception e) {
			logger.warn("Unable to marshall receive task message payload {}, ERROR DETAILS: {}", payload,
					e.getMessage());
			return notFound(MessageFormat.format(TASK_NOT_FOUND, taskName), v);
		}

		/////
		// SHORT CIRCUIT! NO CORRELATION MAP FOUND IN PARAMETERS TO FILTER TASKS
		/////
		if (payloadItems.get("correlationMap") == null
				|| !Map.class.isAssignableFrom(payloadItems.get("correlationMap").getClass())) {
			logger.debug("correlation map not found, or not given in the proper format");
			return notFound(MessageFormat.format(TASK_NOT_FOUND, taskName), v);
		}

		Map<String, Object> correlationMap = (Map<String, Object>) payloadItems.get("correlationMap");
		logger.debug("correlationMap {}", correlationMap);

		Collection<ProcessInstanceDesc> candidateProcessInstances;
		int candidateInstancesOffset = 0;
		int completedWorkItems = 0;
		do {
			candidateProcessInstances = runtimeDataService.getProcessInstancesByProcessName(
					Arrays.asList(ProcessInstance.STATE_PENDING, ProcessInstance.STATE_ACTIVE), processName, null,
					new QueryContext(candidateInstancesOffset, candidateInstancesOffset + 1000));
			logger.debug("{} active process instances found for process name {}",
					candidateInstancesOffset + candidateProcessInstances.size(), processName);

			completedWorkItems += completeWorkItemsInCollection(candidateProcessInstances, taskName, correlationMap,
					payloadItems);

			candidateInstancesOffset += 1000;
		} while (candidateProcessInstances.size() != 0);

		if (completedWorkItems > 0) {
			logger.debug("Completed {} tasks with name {}", completedWorkItems, taskName);
			//return prepareResponse(headers, containerId, v, contentType, completedWorkItems, Response.Status.OK);
			return Response.ok().entity("{\"statusCode\":0, \"errorCode\":\"SUCCESS\"}").build();
		} else {
			try {
				Collection<ProcessInstanceDesc> processInstanceList = null;
				if (!correlationMap.containsKey(WORK_FLOW_ID)) {
					for (Entry<String, Object> correlation : correlationMap.entrySet()) {
						processInstanceList = runtimeDataService.getProcessInstancesByVariableAndValue("_rt_"+correlation.getKey(),
								correlation.getValue().toString(), null, new QueryContext(0, 1000));
					}
					if (null != processInstanceList && !processInstanceList.isEmpty()) {
						return setProcessVariable(processName, taskName, payload,
								processInstanceList.iterator().next().getId());
					} else {
						logger.debug("Task {} not found in process {} with correlationMap {}", taskName, processName,
								correlationMap);
						//return Response.status(Status.NOT_FOUND).entity("{\"Result\":\"Error\", \"ErrorMsg\":\"Task " + taskName + "not found in process " + processName +" with requested correlationMap \"}").build();
						return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":1, \"errorCode\":\"FLOW_NODE_NOT_PRESENT\"}").build();
					}
				} else {
					return setProcessVariable(processName, taskName, payload,
							Long.parseLong(correlationMap.get(WORK_FLOW_ID).toString()));
				}
			}
			catch(Exception e)
			{
				logger.error("Exception occurred in receive task service call : ", e);
				//return Response.status(Status.INTERNAL_SERVER_ERROR).entity("{\"Result\":\"Error\", \"ErrorMsg\":\"" + e.getMessage() + "\"}").build();
				return Response.status(Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
			}
		}
	}

	/** Returns response describing the status of receive message
	 * @param processName
	 * @param taskName
	 * @param payload
	 * @param processInstanceId
	 * @return Success or failure response
	 */
	private Response setProcessVariable(String processName, String taskName, String payload, Long processInstanceId) {
	
			ProcessInstanceDesc processInstanceDesc = findRootProcessInstance(processInstanceId);

			String taskContent = taskName.replace(" ", "");
			if (null != processInstanceDesc) {
				String rtVariable = (String) processService.getProcessInstanceVariable(processInstanceDesc.getId(),
						"_rt_" + processName + "_" + taskContent);

				// Set the given payload to process variable if the given task in not in active
				// state
				if (null == rtVariable) {
					processService.setProcessVariable(processInstanceDesc.getId(),
							"_rt_" + processName + "_" + taskContent, payload);

					return Response.accepted().entity(
							"{\"Result\":\"Success\", \"SuccessMsg\":\"Task is not in Ready state, the request has been queued\"}")
							.build();
				} else {
					processService.setProcessVariable(processInstanceDesc.getId(),
							"_rt_" + processName + "_" + taskContent, payload);
					return Response.accepted().entity(
							"{\"Result\":\"Success\", \"SuccessMsg\":\"Request for this task has already been received, the message has been replaced\"}")
							.build();
				}
			} else {
				logger.debug("Unable to find process instance details for task {} and process {}", taskName, processName);
				return Response.status(Status.NOT_FOUND)
						.entity("{\"Result\":\"Error\", \"ErrorMsg\":\"Task " + taskName + " not found in process " + processName +" with requested correlationMap \"}").build();
			}
	}

	private int completeWorkItemsInCollection(Collection<ProcessInstanceDesc> candidateProcessInstances,
			String taskName, Map<String, Object> correlationMap, Map<String, Object> payloadItems) {
		logger.debug("Searching for active tasks with name {} in {} process instances", taskName,
				candidateProcessInstances.size());
		int completedWorkItems = 0;
		for (ProcessInstanceDesc processInstance : candidateProcessInstances) {
			Collection<NodeInstanceDesc> activeNodes;
			activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstance.getId(),
					new QueryContext(0, 1000));
			logger.debug("found {} active tasks in process instance {}", activeNodes.size(), processInstance.getId());
			try {
				completedWorkItems += completeActiveNodesInCollection(processInstance, activeNodes, taskName,
						correlationMap, payloadItems);
			} catch (Exception e) {
				logger.warn("Exception occurred while completing receive task due to: {}",e.getMessage());
			}
		}
		return completedWorkItems;
	}

	@SuppressWarnings("unchecked")
	private int completeActiveNodesInCollection(ProcessInstanceDesc processInstance,
			Collection<NodeInstanceDesc> activeNodes, String taskName, Map<String, Object> correlationMap,
			Map<String, Object> payloadItems) {
		logger.debug("Searching for task with name {} and correlationMap {} in {} active tasks", taskName,
				correlationMap, activeNodes.size());
		int completedWorkItems = 0;
		// Filters: task name, has a correlationMap, its web service stage
		// received, and correlation map matches
		List<WorkItem> workItemsToComplete = activeNodes.stream().filter(n -> taskName.equals(n.getName()))
				.map(n -> processService.getWorkItem(n.getWorkItemId())).filter(w -> {
					Object oCorrelationMap = w.getParameter("correlationMap");
					if (oCorrelationMap != null) {
						Boolean wsStageCompleted = processService.getProcessInstanceVariable(processInstance.getId(),
								"ws_stage_" + w.getId()) != null
								&& (Boolean) processService.getProcessInstanceVariable(processInstance.getId(),
										"ws_stage_" + w.getId());
						Boolean skipRESTOutbound = w.getParameter("SkipRESTOutbound") != null
								&& (Boolean) w.getParameter("SkipRESTOutbound");
						if (wsStageCompleted || skipRESTOutbound) {
							logger.debug("Found the node, does it match the correlation map?");
							logger.debug("correlationMap in work item: {}", oCorrelationMap);
							return Map.class.isAssignableFrom(oCorrelationMap.getClass())
									&& correlationMap.equals(oCorrelationMap);
						} else {
							logger.debug("active work item not ready for receive task {}", w.getName());
						}
					} else {
						logger.debug("active node work item found with no correlation map {}", w.getName());
					}
					return false;
				}).collect(Collectors.toList());

		for (WorkItem wi : workItemsToComplete) {
			logger.debug("Completing work item id {}", wi.getId());
			Object wiS1Payload = processService.getProcessInstanceVariable(processInstance.getId(),
					"payload_wi_" + wi.getId());
			if (wiS1Payload != null && Map.class.isAssignableFrom(wiS1Payload.getClass())) {
				payloadItems.putAll((Map<String, Object>) wiS1Payload);
			}
			processService.completeWorkItem(wi.getId(), payloadItems);
			completedWorkItems++;
		}
		return completedWorkItems;
	}

	/**
	 * Prepares the {@link Response} based on the passed in input parameters
	 * along with the {@link Status} code
	 * 
	 * @return {@link Response} object
	 */
	private Response prepareResponse(HttpHeaders headers, String containerId, final Variant v, final String contentType,
			long piId, Status status) {

		Header conversationIdHeader = RestUtils.buildConversationIdHeader(containerId, context, headers);
		String response = marshallerHelper.marshal(contentType, piId);
		return RestUtils.createResponse(response, v, status, conversationIdHeader);
	}
	
	/*
	 * Receive task with Process instance id and task name
	 * Checks for active workitem with given task name,
	 * if it is available completes the workitem with the given payload
	 * else creates a process variable with _rt_#{taskName} and sets the payload value to that variable
	 */
	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Receive task with process instance id and taskName", response = Long.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 201, response = Long.class, message = "completed"),
			@ApiResponse(code = 202, message = "Accepted"),
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process or Task not found") })
	@POST
	@Path("processes/instances/{processInstanceId}/receivetask/{taskName}")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Response receiveTaskWithPid(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "process instance id", required = true) @PathParam("processInstanceId") String processInstanceId,
			@ApiParam(value = "task name", required = true) @PathParam("taskName") String taskName,
			@ApiParam(value = "data to be sent to task", required = false) @DefaultValue("{}") String payload) {
		logger.debug("Processing Receive task for processInstanceId: {}, taskName: {}, payload: {}", processInstanceId,
				taskName, payload);
		final Variant v = RestUtils.getVariant(headers);
		final String contentType = RestUtils.getContentType(headers);

		Map<String, Object> payloadItems;
		Long pId = Long.valueOf(processInstanceId);
		ProcessInstanceDesc processInstance = runtimeDataService.getProcessInstanceById(pId);
		// Return an error message if the given processInstance is not valid
		if (null == processInstance) {
			return Response.status(Status.NOT_FOUND).entity(
					"{\"Result\":\"Error\", \"ErrorMsg\":\"No process instance is available with the given id\"}")
					.build();
		}

		String containerId = processInstance.getDeploymentId();

		/////
		// SHORT CIRCUIT! NOT A VALID JSON PAYLOAD
		/////
		try {
			payloadItems = marshallerHelper.unmarshal(payload, contentType, Map.class);
			logger.debug("Payload Items {}", payloadItems);
		} catch (Exception e) {
			logger.warn("Unable to marshall receive task message payload {}, ERROR DETAILS: {}", payload,
					e.getMessage());
			return notFound(MessageFormat.format("Invalid json {0} ", payload), v);
		}
		// Get all nodes from a process definition for given processInstance
		Set<NodeDesc> nodeDescSet = definitionService
				.getProcessDefinition(containerId, processService.getProcessInstance(pId).getProcessId()).getNodes();
		try {
			nodeDescSet.stream().filter(n -> taskName.equals(n.getName())).findFirst()
					.orElseThrow(() -> new IllegalArgumentException(
							"Task with name " + taskName + " is not found in given process instance"));
		}
		// Return 404 if the given task name is not present in node instance list
		catch (IllegalArgumentException e) {
			return Response.status(Status.NOT_FOUND)
					.entity("{\"Result\":\"Error\", \"ErrorMsg\":\"" + e.getMessage() + "\"}").build();
		}
		Optional<NodeInstanceDesc> nodeInstanceList;
		// Get all active nodeInstances from given processInstance
		Collection<NodeInstanceDesc> activeNodes;
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(pId, new QueryContext(0, 1000));

		// Get the workItemId if the given task is in Active nodes list
		nodeInstanceList = activeNodes.stream().filter(n -> n.getName().equals(taskName)).findFirst();
		Long workItemId = null;
		if (nodeInstanceList.isPresent()) {
			workItemId = nodeInstanceList.get().getWorkItemId();
		}
		String taskContent = taskName.replace(" ", "");
		String rtVariable = (String) processService.getProcessInstanceVariable(pId, "_rt_" + taskContent);
		// Complete the task if it is in Active state
		if (null != workItemId) {
			processService.completeWorkItem(workItemId, payloadItems);
			if (null != rtVariable) {
				processService.setProcessVariable(pId, rtVariable, null);
			}
			return Response.ok().entity("{\"Result\":\"Success\", \"SuccessMsg\":\"Task is completed successfully\"}")
					.build();
		}
		
		String updateMsg=null;

		// Set the given payload to process variable if the given task in not in active
		// state
		if (null == rtVariable) {
			processService.setProcessVariable(pId, "_rt_" + taskContent, payload);
			updateMsg = "Task is not in Ready state, the request has been queued";
		}
		else{
			processService.setProcessVariable(pId, "_rt_" + taskContent, payload);
			updateMsg = "Request for this task has already been received, the message has been replaced";
		}
			

		for (int retryCount = 0; retryCount < 2; retryCount++) {
			activeNodes = runtimeDataService.getProcessInstanceHistoryActive(pId, new QueryContext(0, 1000));

			// Get the workItemId if the given task is in Active nodes list
			nodeInstanceList = activeNodes.stream().filter(n -> n.getName().equals(taskName)).findFirst();
			
			if (nodeInstanceList.isPresent()) {
				workItemId = nodeInstanceList.get().getWorkItemId();
				if (null != workItemId) {
					processService.completeWorkItem(workItemId, payloadItems);
					if (null != rtVariable) {
						processService.setProcessVariable(pId, rtVariable, null);
					}
					return Response.ok()
							.entity("{\"Result\":\"Success\", \"SuccessMsg\":\"Task is completed successfully\"}").build();
				}
			}
			 else {
				try {
					Thread.sleep(100);
				} catch (InterruptedException ex) {
					logger.warn("InterruptedException occured during thread sleep {}", ex.getMessage());
					Thread.currentThread().interrupt();
				}
			}
		}

		return Response.accepted().entity(
				"{\"Result\":\"Success\", \"SuccessMsg\":\""+ updateMsg + "\"}")
				.build();

	}
	
	/**
	 * Bubbles up to find and return the root process instance of inquired base
	 * process instance
	 *
	 * @param processInstanceId Base process instance to be fetched
	 * @return {@link ProcessInstanceDesc} root process instance of base process
	 *         instance
	 * @throws DeploymentNotFoundException
	 */
	private ProcessInstanceDesc findRootProcessInstance(Long processInstanceId) throws DeploymentNotFoundException {
		logger.debug("Find the Root Process Instance for {}", processInstanceId);
		ProcessInstanceDesc _pid = runtimeDataService.getProcessInstanceById(processInstanceId);
		if (null != _pid) {
			if (_pid.getParentId() == -1) {
				logger.debug("Found the Root Process Instance {}", processInstanceId);
				return _pid;
			} else {
				logger.debug("Found a Parent Process Instance {}", _pid.getParentId());
				return findRootProcessInstance(_pid.getParentId());
			}
		}
		return null;
	}
}
