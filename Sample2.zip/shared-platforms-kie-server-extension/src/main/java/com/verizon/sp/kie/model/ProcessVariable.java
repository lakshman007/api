/**
 * 
 */
package com.verizon.sp.kie.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author tordi7z
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verizon-dynamic-task")
public class ProcessVariable {
	
	@XmlElement(name = "var-name")
	private String varName;
	@XmlElement(name = "var-value")
	private String varValue;	
	public String getVarName() {
		return varName;
	}
	public void setVarName(String varName) {
		this.varName = varName;
	}
	public String getVarValue() {
		return varValue;
	}
	public void setVarValue(String varValue) {
		this.varValue = varValue;
	}
	
	
	@Override
	public String toString() {
		return "{\"var-name\": \"" + varName + "\", \"var-value\": \"" + varValue +"\"}";
	}
	
}
