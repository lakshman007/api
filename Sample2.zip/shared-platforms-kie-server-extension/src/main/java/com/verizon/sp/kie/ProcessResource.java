package com.verizon.sp.kie;

import static org.kie.server.remote.rest.common.util.RestUtils.badRequest;
import static org.kie.server.remote.rest.common.util.RestUtils.buildConversationIdHeader;
import static org.kie.server.remote.rest.common.util.RestUtils.createResponse;
import static org.kie.server.remote.rest.common.util.RestUtils.getContentType;
import static org.kie.server.remote.rest.common.util.RestUtils.getVariant;
import static org.kie.server.remote.rest.common.util.RestUtils.internalServerError;
import static org.kie.server.remote.rest.common.util.RestUtils.notFound;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.JSON;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.LONG_RESPONSE_JSON;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.LONG_RESPONSE_XML;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.VAR_MAP_JSON;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.VAR_MAP_XML;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.XML;
import static org.kie.server.remote.rest.jbpm.resources.Messages.CONTAINER_NOT_FOUND;
import static org.kie.server.remote.rest.jbpm.resources.Messages.CREATE_RESPONSE_ERROR;
import static org.kie.server.remote.rest.jbpm.resources.Messages.PROCESS_DEFINITION_NOT_FOUND;
import static org.kie.server.remote.rest.jbpm.resources.Messages.PROCESS_INSTANCE_NOT_FOUND;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Variant;

import org.jbpm.services.api.DefinitionService;
import org.jbpm.services.api.DeploymentNotActiveException;
import org.jbpm.services.api.DeploymentNotFoundException;
import org.jbpm.services.api.ProcessDefinitionNotFoundException;
import org.jbpm.services.api.ProcessInstanceNotFoundException;
import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.server.api.rest.RestURI;
import org.kie.server.remote.rest.common.Header;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.locator.ContainerLocatorProvider;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.kie.server.services.jbpm.locator.ByProcessInstanceIdContainerLocator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.fasterxml.jackson.databind.util.JSONWrappedObject;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

@Api(value = "Verizon Process Instances")
@Path("verizon/server/" + RestURI.PROCESS_URI)
public class ProcessResource {
	private static final Logger logger = LoggerFactory.getLogger(ProcessResource.class);

	private static final String PROPERTY_FILE_LOCATION = "com.verizon.provisioning.sp.kie.property.file.location";
	private static final String PROPERTY_FILE_EXTENSION_DEFAULT = ".properties";
	private static final String ROOT_PROCESS_ID_URI = "{" + "processInstanceId" + "}/rootProcessInstanceId";

	private ProcessService processService;
	private DefinitionService definitionService;
	private KieServerRegistry context;
	private MarshallerHelper marshallerHelper;
	private RuntimeDataService runtimeDataService;

	public ProcessResource() {
	}

	protected static String getRelativePath(HttpServletRequest httpRequest) {
		String url = httpRequest.getRequestURI();
		url = url.replaceAll(".*/rest", "");
		return url;
	}

	public ProcessResource(ProcessService processService, DefinitionService definitionService, RuntimeDataService runtimeDataService,
			KieServerRegistry context) {
		this.processService = processService;
		this.definitionService = definitionService;
		this.runtimeDataService=runtimeDataService;
		this.context = context;
		this.marshallerHelper = new MarshallerHelper(context);
	}

	@ApiOperation(value = "Starts a new process instance of a specified process.", response = Long.class, code = 201)
	@ApiResponses(value = {
			@ApiResponse(code = 201, response = Long.class, message = "Process instance started", examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = LONG_RESPONSE_JSON),
					@ExampleProperty(mediaType = XML, value = LONG_RESPONSE_XML) })),
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process ID or Container Id not found") })
	@POST
	@Path(RestURI.START_PROCESS_POST_URI)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response startProcessSynchronous(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "Container alias where the process definition resides", required = true) @PathParam(RestURI.CONTAINER_ID) String containerAlias,
			@ApiParam(value = "Process id that new instance should be created from", required = true) @PathParam(RestURI.PROCESS_ID) String processId,
			@ApiParam(value = "Optional flag to also return container id and container alias", required = false) @QueryParam("includeContainerId") @DefaultValue("false") boolean includeContainerId,
			@ApiParam(value = "Optional map of process variables", required = false, examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = VAR_MAP_JSON),
					@ExampleProperty(mediaType = XML, value = VAR_MAP_XML) })) @DefaultValue("") String payload) {
		final Variant v = getVariant(headers);
		final String type = getContentType(headers);
		String containerId = containerAlias;
		
		try {
			containerId = context.getContainerId(containerAlias, ContainerLocatorProvider.get().getLocator());
			logger.info("Verizon KIE Server Extension: startProcessSynchronous(containerAlias= " + containerAlias
					+ ", containerId=" + containerId + ", processID=" + processId + ")");
			Map<String, Object> payloadItems = addPropertiesToPayload(containerId, type, processId, payload);

			// Start the process with the updated payload
			definitionService.getProcessDefinition(containerId, processId);
			Long processInstanceId = processService.startProcess(containerId, processId, payloadItems);
			String response = "";
			// Check for optional boolean
			if (includeContainerId) {
				response = "{\n" +
						"  \"process-instance-id\": " + processInstanceId + ",\n" +
						"  \"container-id\": \"" + containerId + "\",\n" +
						"  \"container-alias\": \"" + containerAlias + "\"\n" +
						"}\n";
			}
			else {
				response = marshallerHelper.marshal(containerId, type, processInstanceId);
			}
			Header conversationIdHeader = buildConversationIdHeader(containerId, context, headers);
			return createResponse(response, v, Response.Status.CREATED, conversationIdHeader);
		} catch (DeploymentNotActiveException e) {
			return badRequest(e.getMessage(), v);
		} catch (DeploymentNotFoundException e) {
			return notFound(MessageFormat.format(CONTAINER_NOT_FOUND, containerId), v);
		} catch (ProcessDefinitionNotFoundException e) {
			return notFound(MessageFormat.format(PROCESS_DEFINITION_NOT_FOUND, processId, containerId), v);
		} catch (Exception e) {
			logger.error("Unexpected error during processing {}", e.getMessage(), e);
			return internalServerError(MessageFormat.format(CREATE_RESPONSE_ERROR, e.getMessage()), v);
		}
	}

	/**
	 * API to fetch the root process instance id from any of it's child process
	 * instance
	 * 
	 * @param headers           headers from the request
	 * @param containerId       container Id of which the process instance belongs
	 *                          to
	 * @param processInstanceId process instance id for which the root parent
	 *                          process instance id is required
	 * @return {@link Response} which contains the root process instance id, If the
	 *         process instance id which is passed as input itself is a root process
	 *         it will return the process instance id we passed, in all other cases
	 *         will resolve the root process instance id and return it.
	 */

	@ApiOperation(value = "Returns root process instance identifier for any child process instance", response = Long.class, code = 200)
	@ApiResponses(value = {
			@ApiResponse(code = 200, response = Long.class, message = "Obtained Root Process Instance Identifier", examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = LONG_RESPONSE_JSON),
					@ExampleProperty(mediaType = XML, value = LONG_RESPONSE_XML) })),
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process ID or Container Id not found") })
	@GET
	@Path(ROOT_PROCESS_ID_URI)
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getRootProcessInstance(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "container id that process instance belongs to", required = true, example = "evaluation_1.0.0-SNAPSHOT") @PathParam(RestURI.CONTAINER_ID) String containerId,
			@ApiParam(value = "identifier of the process instance for which the root parent instance id has to be resolved", required = true, example = "123") @PathParam(RestURI.PROCESS_INST_ID) Long processInstanceId) {
		Variant v = getVariant(headers);
		Header conversationIdHeader = buildConversationIdHeader(containerId, context, headers);
		Long parentProcessInstanceId = 0L;
		try {
			/**
			 * First we assign the process instance id as a parentProcessInstanceId, because
			 * if process instance doesn't have any parent then we need to return the same
			 * process instance id as root parent process instance id
			 */
			parentProcessInstanceId = processInstanceId;
			/**
			 * Resolve container Id, alias is passed
			 */
			String id = context.getContainerId(containerId,
					new ByProcessInstanceIdContainerLocator(parentProcessInstanceId));
			/**
			 * This is the variable, we are going to return as result
			 */
			Long response = 0L;
			do {
				/**
				 * As this will be executed at least once, we update the value of response here.
				 */
				response = parentProcessInstanceId;
				// Get Process Instance Details, which contains the parent process instance id
				ProcessInstance processInstanceDetails = processService.getProcessInstance(id, parentProcessInstanceId);
				if (processInstanceDetails == null) {
					throw new ProcessInstanceNotFoundException(
							"No active process instance exists with the input identifier");
				}
				// Obtain parent process instance id from process instance details
				parentProcessInstanceId = processInstanceDetails.getParentProcessInstanceId();

				logger.debug("For Process instance id " + processInstanceId
						+ " resolved Parent Process Instance id is : " + parentProcessInstanceId);
			} while (parentProcessInstanceId != -1L);

			logger.debug("Returning OK response with content '{}'", response);
			return createResponse(response, v, Response.Status.OK, conversationIdHeader);

		} catch (ProcessInstanceNotFoundException e) {
			return notFound(MessageFormat.format(PROCESS_INSTANCE_NOT_FOUND, parentProcessInstanceId), v,
					conversationIdHeader);
		} catch (DeploymentNotFoundException e) {
			return notFound(MessageFormat.format(CONTAINER_NOT_FOUND, containerId), v, conversationIdHeader);
		} catch (Exception e) {
			logger.error("Unexpected error during processing {}", e.getMessage(), e);
			return internalServerError(MessageFormat.format(CREATE_RESPONSE_ERROR, e.getMessage()), v);
		}
	}
	
	
	/*
	 * 
	 * Aborts Specified Active Process Instance
	 * 
	 * 
	 */
	
	@ApiOperation(value = "Aborts a specified process instance in a specified KIE container.", response = String.class, code = 200)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Process instance Aborted"),/*, examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = LONG_RESPONSE_JSON),
					@ExampleProperty(mediaType = XML, value = LONG_RESPONSE_XML) })*/
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process ID or Container Id not found") })
	@DELETE
	@Path(RestURI.ABORT_PROCESS_INST_DEL_URI)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response abortProcessInstance(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "container id that process instance belongs to", required = true, example = "evaluation_1.0.0-SNAPSHOT") @PathParam(RestURI.CONTAINER_ID) String containerId,
			@ApiParam(value = "identifier of the process instance for specified Container", required = true, example = "123") @PathParam(RestURI.PROCESS_INST_ID) Long processInstanceId) {
	try {
		Variant v = getVariant(headers);
		Header conversationIdHeader = buildConversationIdHeader(containerId, context, headers);
			if(runtimeDataService.getProcessInstanceById(processInstanceId)!=null) 
			{
					if(runtimeDataService.getProcessInstanceById(processInstanceId).getState()==1) {
					processService.abortProcessInstance(processInstanceId);
					return Response.ok().entity("{\"statusCode\":0, \"errorCode\":\"SUCCESS\"}").build();
					//return createResponse(null,v,Response.Status.NO_CONTENT,conversationIdHeader);
				}
				else {
					return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":-1, \"errorCode\":\"PROCESS_INSTANCE_NOT_ACTIVE\"}").build();
				}
			}
					else {
						return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":1, \"errorCode\":\"PROCESS_INSTANCE_NOT_PRESENT\"}").build();
					}
		}
		catch(Exception e) {	
				return Response.status(Status.INTERNAL_SERVER_ERROR).entity("{\"statusCode\":1, \"errorCode\":\"Unexpected Error Occured\"}").build();
		}	
	}
	
	
	/*
	 * 
	 * Update Variables in the given Active ProcessInstance
	 * 
	 */
	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Updates the values of one or more variable for a specified process instance. The request is a map in which the key is the variable name and the value is the new variable value.", response = Long.class, code = 200)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Variables updated Successfully"),/*, examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = LONG_RESPONSE_JSON),
					@ExampleProperty(mediaType = XML, value = LONG_RESPONSE_XML) })),*/
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "ProcessInstance ID or Container Id not found") })
	@POST
	@Path(RestURI.PROCESS_INSTANCE_VARS_POST_URI)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response updateProcessInstanceVariables(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "container id that process instance belongs to", required = true) @PathParam(RestURI.CONTAINER_ID) String containerId,
			@ApiParam(value = "identifier of the process instance to be updated", required = true) @PathParam(RestURI.PROCESS_INST_ID) Long processInstanceId,
			@ApiParam(value = "variable data give as map", required = true, examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = VAR_MAP_JSON),
					@ExampleProperty(mediaType = XML, value = VAR_MAP_XML) })) @DefaultValue("") String payload) {
		
		final Variant v = getVariant(headers);
		final String type = getContentType(headers);
		Map<String,Object> payloadItems=new HashMap<String,Object>();
		try {
			if(runtimeDataService.getProcessInstanceById(processInstanceId)!=null) {
		if(runtimeDataService.getProcessInstanceById(processInstanceId).getState()==1||runtimeDataService.getProcessInstanceById(processInstanceId).getState()==4) {
		payloadItems = marshallerHelper.unmarshal(containerId, payload, type, Map.class);
		processService.setProcessVariables(containerId, processInstanceId, payloadItems);
		return Response.ok().entity("{\"Result\":\"Success\", \"SuccessMsg\":\"Variables updated Successfully\"}").build();
		}
		else {
			return Response.status(Status.NOT_FOUND).entity("{\"Result\":\"FAILURE\", \"FailureMsg\":\"ProcessInstance is not Active, Variables cannot be updated.\"}").build();
		}
			}
			else {
				return Response.status(Status.NOT_FOUND).entity("{\"Result\":\"FAILURE\", \"FailureMsg\":\"ProcessInstanceId is not valid or Created yet\"}").build();
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity("{\"Result\":\"FAILURE\", \"FailureMsg\":\"Unexpected Error\"}").build();
		}
	}
	

	private Map<String, Object> addPropertiesToPayload(String containerId, String type, String processId,
			String payload) {

		Map<String, Object> payloadItems = new HashMap<String, Object>();

		// Get these properties from the environment
		String propFileLocation = System.getProperty(PROPERTY_FILE_LOCATION);
		Properties properties = new Properties();

		// Look for a properties file based on the process definition id
		if (containerId != null) {
			String containerIdBasedPropFile = propFileLocation + File.separator + processId + PROPERTY_FILE_EXTENSION_DEFAULT;
			try {
				logger.info("Loading properties for process definition : " + processId + " using properties file "
						+ containerIdBasedPropFile + "...");
				properties.load(new FileInputStream(containerIdBasedPropFile));
				// processed = true;
			} catch (FileNotFoundException fnfe) {
				logger.info("Unable to find properties file: " + containerIdBasedPropFile + ", of container id: "
						+ containerId + "...");
			} catch (IOException ioe) {
				logger.info("Unable to process properties file: " + containerIdBasedPropFile + ", of container id: "
						+ containerId + "...");
			}
		}

		// Combine the properties with the payload
		payloadItems = marshallerHelper.unmarshal(containerId, payload, type, Map.class);

		// Add the configuration properties from the environment to the payload
		@SuppressWarnings("unchecked")
		Enumeration<String> enums = (Enumeration<String>) properties.propertyNames();
		while (enums.hasMoreElements()) {
			String name = enums.nextElement();
			String value = properties.getProperty(name);
			payloadItems.putIfAbsent(name, (String) value);
		}

		return payloadItems;
	}
}