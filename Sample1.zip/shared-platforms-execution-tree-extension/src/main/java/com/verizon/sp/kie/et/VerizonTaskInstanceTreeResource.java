package com.verizon.sp.kie.et;

import static org.kie.server.remote.rest.common.util.RestUtils.buildConversationIdHeader;
import static org.kie.server.remote.rest.common.util.RestUtils.createResponse;
import static org.kie.server.remote.rest.common.util.RestUtils.errorMessage;
import static org.kie.server.remote.rest.common.util.RestUtils.getContentType;
import static org.kie.server.remote.rest.common.util.RestUtils.getVariant;
import static org.kie.server.remote.rest.common.util.RestUtils.internalServerError;
import static org.kie.server.remote.rest.common.util.RestUtils.notFound;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.JSON;
import static org.kie.server.remote.rest.jbpm.resources.Messages.PROCESS_INSTANCE_NOT_FOUND;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Variant;

import org.drools.persistence.api.TransactionManager;
import org.drools.persistence.api.TransactionManagerFactory;
import org.jbpm.ruleflow.core.RuleFlowProcess;
import org.jbpm.services.api.ProcessInstanceNotFoundException;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.workflow.core.node.WorkItemNode;
import org.kie.api.definition.process.Node;
import org.kie.api.runtime.KieSession;
import org.kie.server.remote.rest.common.Header;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.sp.kie.et.model.NodeInstanceTree;
import com.verizon.sp.kie.et.model.ProcessInstanceTree;
import com.verizon.sp.kie.et.model.VerizonTask;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

/**
 * Provides a kie-server extension that retrieves all the execution tree of the
 * elements related to a parent process instance. This endpoint locates the
 * parent process instance and returns the complete execution tree from the
 * parent process instance id and represents multi-instance sub-process
 * instances as an element of the executed node instance.
 *
 * @author motappa
 * 
 * @author jblacket
 * @Todo Filter by control nodes and callable tasks
 */
@Api(value = "Task Status Tree")
@Path("verizon")
public class VerizonTaskInstanceTreeResource extends AbstractExecutionTree {
	private static final Logger logger = LoggerFactory.getLogger(VerizonTaskInstanceTreeResource.class);

	private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");

	// @formatter:off
    public static final String GET_PROCESS_INSTANCE_TREE_RESPONSE_JSON = "{\n" +
    	    "  \"taskName\":\"initiateWorkflow\",\n" +
    	    "  \"startDate\":\"Mon Jul 06 11:37:54 EDT 2020\",\n" +
    	    "  \"startDateMillis\":\"1594049874208\",\n" +
    	    "  \"endDateMillis\":\"1594049898799\",\n" +
    	    "  \"endDate\":\"Mon Jul 06 11:38:18 EDT 2020\",\n" +
    	    "  \"taskId\":\"574084241\",\n" +
    	    "  \"parentContainerId\":15951610,\n" +
    	    "  \"rootContainerId\":\"15950951\",\n" +
    	    "  \"parentName\":\"workflowParent\",\n" +
    	    "  \"taskType\":\"RECEIVE_TASK\",\n" +
    	    "  \"taskStatus\":\"completed\",\n" +
    	    "  \"sourceObjectId\":332840356,\n" +
    	    "  \"subWorkFlow\":[{\n    \"taskName\":\"initiateWorkflow\",\n    \"startDate\":\"Mon Jul 06 11:37:54 EDT 2020\",\n    \"startDateMillis\":\"1594049874208\",\n    \"endDateMillis\":\"1594049898799\",\n    \"endDate\":\"Mon Jul 06 11:38:18 EDT 2020\",\n    \"taskId\":\"574084241\",\n    \"parentContainerId\":15951610,\n  \"rootContainerId\":\"15950951\",\n    \"parentName\":\"workflowParent\",\n    \"taskType\":\"RECEIVE_TASK\",\n    \"taskStatus\":\"completed\",\n    \"sourceObjectId\":\"332840356\",\n    \"subWorkFlow\":[]\n  }]\n}"
    	    ;
    // @formatter:on

	public VerizonTaskInstanceTreeResource() {
	}

	public VerizonTaskInstanceTreeResource(RuntimeDataService dataService, KieServerRegistry context) {
		this.dataService = dataService;
		this.marshallerHelper = new MarshallerHelper(context);
		this.context = context;
	}

	public void setMarshallerHelper(MarshallerHelper marshallerHelper) {
		this.marshallerHelper = marshallerHelper;
	}

	/**
	 * Returns process instance execution tree with information about a
	 * specified process instance tree in a specified KIE Container.
	 *
	 * @param headers
	 * @param processInstanceId
	 *            Identifier of the base process instance to be fetched
	 * @param includeControlNodes
	 *            Optional flag to include control nodes, defaults to false
	 * @return {@link Response} with process instance execution tree JSON format
	 *         structure
	 */
	@ApiOperation(value = "Returns information about a specified process instance tree in a specified KIE Container.", response = ProcessInstanceTree.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process instance or Container Id not found"),
			@ApiResponse(code = 200, message = "Successful response", examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = GET_PROCESS_INSTANCE_TREE_RESPONSE_JSON) })) })
	@GET
	@Path("task-status-tree/{processInstanceId}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getProcessInstanceTree(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "identifier of the process instance to be fetched", required = true, example = "123") @PathParam("processInstanceId") Long processInstanceId,
			@ApiParam(value = "Task Types", allowMultiple = true, allowableValues = "SubProcessNode, HumanTaskNode, WorkItemNode, ActionNode, TimerNode, EventNode, StartNode, EndNode, Split, ReceiveTaskNode, ExternalCallerNode") @QueryParam("taskType") List<String> nodesFilter) {
		Variant v = getVariant(headers);
		String type = getContentType(headers);
		Header conversationIdHeader = buildConversationIdHeader("", context, headers);

		if (nodesFilter == null || nodesFilter.isEmpty() || nodesFilter.get(0).equals("")) {
			logger.debug("Found null or empty nodes filter, setting default value");
			nodesFilter = Arrays.asList("SubProcessNode", "HumanTaskNode", "WorkItemNode", "ActionNode", "TimerNode",
					"EventNode", "ExternalCallerNode", "ReceiveTaskNode");
		}

		try {
			logger.info("Requested Verizon Task Tree for process instance id {}", processInstanceId);
			/**
			 * Find root process using processId
			 *
			 */
			String response = pitByPid(processInstanceId, type, nodesFilter);

			logger.info("Variant: " + v);
			logger.info("Returning OK response with content '{}'", nodesFilter);

			Response resp = createResponse(response, v, Response.Status.OK, conversationIdHeader);
			return resp;
		} catch (ProcessInstanceNotFoundException e) {
			logger.warn("Process Instance not found when building Verizon task tree for process instance id {}",
					processInstanceId);
			return notFound(MessageFormat.format(PROCESS_INSTANCE_NOT_FOUND, processInstanceId), v,
					conversationIdHeader);
		} catch (Exception e) {
			logger.error("Unexpected error during processing {}", e.getMessage(), e);
			return internalServerError(errorMessage(e), v);
		}
	}

	/**
	 * Trigger search for root process and marshal process instance tree
	 *
	 * @param processInstanceId
	 *            Identifier of the base process instance to be fetched
	 * @param marshallingType
	 * @param includeNodes
	 *            Optional flag to include control nodes, defaults to false
	 * @return {@link Response} with process instance execution tree JSON format
	 *         structure
	 */
	private String pitByPid(Long processInstanceId, String marshallingType, List<String> nodesFilter) {
		logger.debug("Calculating process instance tree for process instance id {}", processInstanceId);
		TransactionManager txm = null;
		boolean transactionOwner = false;
		try {
			// Unit tests does not share a context with a valid kie session
			if (context != null && context.getContainers() != null && context.getContainers().size() > 0
					&& context.getContainers().get(0) != null) {
				logger.debug("Using a connected transaction in the kie-server");
				KieSession ksession = context.getContainers().get(0).getKieContainer().getKieSession();
				if (ksession != null) {
					txm = TransactionManagerFactory.get().newTransactionManager(ksession.getEnvironment());
				} else {
					txm = TransactionManagerFactory.get().newTransactionManager();
				}
			} else {
				logger.debug("Using a brand new transaction for testing");
				txm = TransactionManagerFactory.get().newTransactionManager();
			}

			ProcessInstanceTree _pit = getProcessInstanceTree(processInstanceId, true);

			// If no parent process exists
			if (_pit == null) {
				throw new ProcessInstanceNotFoundException(String.valueOf(processInstanceId));
			}

			transactionOwner = txm.begin();
			List<VerizonTask> verizonTaskList = convertToVerizonTask(_pit, nodesFilter, _pit.getId(),
					_pit.getProcessId(), _pit.getId());
			txm.commit(transactionOwner);

			logger.debug("About to marshal process instance tree with id '{}' {}", processInstanceId, verizonTaskList);
			String response = marshallerHelper.marshal(marshallingType, verizonTaskList);
			return response;
		} catch (Exception e) {
			if (txm != null) {
				txm.rollback(transactionOwner);
			}
			e.printStackTrace();
			logger.error("Unable to insert dynamic task", e);
			throw new RuntimeException(e);
		}
	}

	private List<VerizonTask> convertToVerizonTask(ProcessInstanceTree instance, List<String> nodesFilter, Long rootId,
			String parentName, Long parentId) {
		logger.debug("Converting process instance to task instance tree {}", instance);
		NodeInstanceTree[] nit = instance.getProcessNodes();
		List<VerizonTask> verizonTaskLists = new ArrayList<VerizonTask>();

		RuleFlowProcess process;
		if (context != null && context.getContainers() != null && context.getContainers().size() > 0
				&& context.getContainers().get(0) != null) {
			KieSession _ksession = context.getContainers().get(0).getKieContainer().getKieSession();
			process = (RuleFlowProcess) _ksession.getKieBase().getProcess(instance.getProcessId());
		} else {
			logger.debug("Retrieving node information for instance {}", instance);
			process = (RuleFlowProcess) ksession.getKieBase().getProcess(instance.getProcessId());
		}

		for (NodeInstanceTree ni : nit) {

			if (!nodesFilter.contains(ni.getNodeType())) {
				continue;
			}

			VerizonTask verizonTask = new VerizonTask();
			verizonTask.setTaskName(ni.getName());
			verizonTask.setStartDate(
					ni.getNodeStartTime() != null ? simpleDateFormat.format(ni.getNodeStartTime()) : null);
			verizonTask.setStartDateMillis(ni.getNodeStartTime() != null ? ni.getNodeStartTime().getTime() : null);
			verizonTask.setEndDate(ni.getNodeEndTime() != null ? simpleDateFormat.format(ni.getNodeStartTime()) : null);
			verizonTask.setEndDateMillis(ni.getNodeEndTime() != null ? ni.getNodeEndTime().getTime() : null);
			verizonTask.setTaskId(ni.getId());
			verizonTask.setParentName(instance.getProcessName());

			verizonTask.setTaskType("WorkItemNode".equals(ni.getNodeType())
					? calculateWorkItemTaskName(process, ni.getNodeId()) : ni.getNodeType());

			verizonTask.setTaskStatus(ni.isCompleted() ? "completed" : ni.isFailed() ? "failing" : "not completed");

			verizonTask.setSourceObjectId(ni.getWorkItemId());
			verizonTask.setParentContainerId(ni.getProcessInstanceId());
			verizonTask.setRootContainerId(rootId);

			if ("SubProcessNode".equals(ni.getNodeType()) && ni.getProcessInstanceTree() != null) {
				verizonTask.setSourceObjectId(ni.getProcessInstanceTree().getId());
				verizonTask.setParentContainerId(instance.getId());
				verizonTask.getSubWorkFlow().addAll(convertToVerizonTask(ni.getProcessInstanceTree(), nodesFilter,
						rootId, instance.getProcessId(), instance.getId()));
			}

			verizonTaskLists.add(verizonTask);
		}

		return verizonTaskLists;
	}

	private String calculateWorkItemTaskName(RuleFlowProcess process, String nodeId) {
		logger.debug("Looking for node id {}", nodeId);
		for (Node node : process.getNodes()) {
			if (nodeId.equals(node.getMetaData().get("UniqueId"))) {
				WorkItemNode win = (WorkItemNode) node;
				return win.getWork().getName();
			}
		}

		return "WorkItemNode";
	}

	public void setKieSession(KieSession ksession) {
		this.ksession = ksession;
	}
}