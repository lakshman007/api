package com.verizon.sp.kie.et.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.jbpm.kie.services.impl.model.NodeInstanceDesc;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "node-instance")
public class NodeInstanceTree extends NodeInstanceDesc {
	private static final long serialVersionUID = 1L;
	@XmlElement(name = "process-instance")
	private ProcessInstanceTree processInstanceTree;
	@XmlElement(name = "node-start-time")
	private Date nodeStartTime;
	@XmlElement(name = "node-end-time")
	private Date nodeEndTime;
	
	private boolean completed;
	private boolean failed;

	/**
	 * default constructor
	 */
	public NodeInstanceTree() {
		super();
	}

	public NodeInstanceTree(String id, String nodeId, String name, String nodeType, String deploymentId,
			long processInstanceId, Date date, String connection, int type, Long workItemId, Long referenceId,
			String nodeContainerId, Date slaDueDate, Integer slaCompliance) {
		super(id, nodeId, name, nodeType, deploymentId, processInstanceId, date, connection, type, workItemId,
				referenceId, nodeContainerId, slaDueDate, slaCompliance);
	}
	
	/**
	 * @return nodeStartTime Return node execution start time.
	 */
	public Date getNodeStartTime() {
		return nodeStartTime;
	}

	/**
	 * @param nodeStartTime Start time of node execution
	 */
	public void setNodeStartTime(Date nodeStartTime) {
		this.nodeStartTime = nodeStartTime;
	}

	/**
	 * @return nodeEndtime Return node execution end time.
	 */
	public Date getNodeEndTime() {
		return nodeEndTime;
	}

	/**
	 * @param nodeEndTime End time of node execution
	 */
	public void setNodeEndTime(Date nodeEndTime) {
		this.nodeEndTime = nodeEndTime;
	}

	/**
	 * @return ProcessInstanceTree return the processInstanceTree
	 */
	public ProcessInstanceTree getProcessInstanceTree() {
		return processInstanceTree;
	}

	/**
	 * @param processInstanceTree ProcessInstanceTree to set
	 */
	public void setProcessInstanceTree(ProcessInstanceTree processInstanceTree) {
		this.processInstanceTree = processInstanceTree;
	}

	/**
	 * @return completed boolean value
	 */
	public boolean isCompleted() {
		return completed;
	}

	/**
	 * @param completed completed boolean value to set
	 */
	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public boolean isFailed() {
		return failed;
	}

	public void setFailed(boolean failed) {
		this.failed = failed;
	}

}