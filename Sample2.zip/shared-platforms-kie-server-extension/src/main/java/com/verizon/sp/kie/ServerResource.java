package com.verizon.sp.kie;

import static org.kie.server.remote.rest.common.docs.ParameterSamples.CREATE_CONTAINER_RESPONSE_JSON;
import static org.kie.server.remote.rest.common.docs.ParameterSamples.CREATE_CONTAINER_JSON;
import static org.kie.server.remote.rest.common.docs.ParameterSamples.CREATE_CONTAINER_XML;
import static org.kie.server.remote.rest.common.docs.ParameterSamples.JSON;
import static org.kie.server.remote.rest.common.docs.ParameterSamples.XML;
import static org.kie.server.remote.rest.common.util.RestUtils.buildConversationIdHeader;
import static org.kie.server.remote.rest.common.util.RestUtils.createCorrectVariant;
import static org.kie.server.remote.rest.common.util.RestUtils.getContentType;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.kie.server.api.model.KieContainerResource;
import org.kie.server.api.model.ReleaseId;
import org.kie.server.api.model.ServiceResponse;
import org.kie.server.remote.rest.common.Header;
import org.kie.server.services.impl.KieServerImpl;
import org.kie.server.services.impl.KieServerLocator;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.sp.kie.util.RestUtils;
import com.verizon.sp.kie.util.ParameterSamples;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

@Api(value = "Verizon KIE Server")
@Path("verizon/server/")
public class ServerResource {

	private static final Logger logger = LoggerFactory.getLogger(ServerResource.class);

	private KieServerImpl server;
	private MarshallerHelper marshallerHelper;

	public ServerResource() {
		this.server = KieServerLocator.getInstance();
		this.marshallerHelper = new MarshallerHelper(this.server.getServerRegistry());
	}

	public ServerResource(KieServerImpl server) {
		this.server = server;
		this.marshallerHelper = new MarshallerHelper(server.getServerRegistry());
	}

	public KieServerImpl getServer() {
		return this.server;
	}

	public void setServer(KieServerImpl server) {
		this.server = server;
	}

	@ApiOperation(value = "Creates a new KIE container in the KIE Server with a specified KIE container ID", response = ServiceResponse.class, code = 201)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 400, message = "container could not be created"),
			@ApiResponse(code = 201, message = "Successfull response", examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = CREATE_CONTAINER_RESPONSE_JSON) })) })

	@PUT
	@Path("containers/")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response createContainer(@Context HttpHeaders headers,
			@ApiParam(value = "KIE Container resource to be deployed as KieContainerResource", required = true, examples=@Example(value= {
                    @ExampleProperty(mediaType=JSON, value=ParameterSamples.CREATE_CONTAINER_JSON),
                    @ExampleProperty(mediaType=XML, value=ParameterSamples.CREATE_CONTAINER_XML)})) String containerPayload) {

		ServiceResponse<?> forbidden = this.server.checkAccessability();
		if (forbidden != null) {
			return createCorrectVariant(forbidden, headers, Status.BAD_REQUEST);
		}

		String contentType = getContentType(headers);
		KieContainerResource container = marshallerHelper.unmarshal(containerPayload, contentType,
				KieContainerResource.class);

		// Synthesize the container-id from the release-id structure
		ReleaseId releaseID = container.getReleaseId();
		if (releaseID != null) {
			String containerID = releaseID.getArtifactId() + "_" + releaseID.getVersion();
			logger.debug("Setting synthetic container-id to " + containerID);
			container.setContainerId(containerID);
		}

		ServiceResponse<KieContainerResource> response = server.createContainer(container.getContainerId(), container);
		Header conversationIdHeader = buildConversationIdHeader(container.getContainerId(), server.getServerRegistry(),
				headers);

		if (response.getType() == ServiceResponse.ResponseType.SUCCESS) {
			return createCorrectVariant(response, headers, Status.CREATED, conversationIdHeader);
		}

		return createCorrectVariant(response, headers, Status.BAD_REQUEST);
	}
}