package com.verizon.sp.kie.et;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.jbpm.services.api.RuntimeDataService;
import org.kie.server.services.api.KieServerApplicationComponentsService;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.api.SupportedTransports;
import org.kie.server.services.jbpm.JbpmKieServerExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Loads the Process Instance Tree Extension which returns the list of task
 * nodes within whole process, including subprocess task nodes etc.
 * 
 */
public class VerizonTaskInstanceTreeService implements KieServerApplicationComponentsService {
	private static final Logger logger = LoggerFactory.getLogger(VerizonTaskInstanceTreeService.class);
	private final String OWNER_EXTENSION = JbpmKieServerExtension.EXTENSION_NAME;

	/**
	 * Returns a collection of app components
	 * 
	 * @param extension
	 * @param type
	 * @param services
	 * @return Collection of app components
	 */
	public Collection<Object> getAppComponents(String extension, SupportedTransports type, Object... services) {
		if (!OWNER_EXTENSION.equals(extension)) {
			return Collections.emptyList();
		}

		logger.info("Loading Process Instance Tree KIE Server extension ...");
		RuntimeDataService runtimeDataService = null;
		KieServerRegistry context = null;

		for (Object o : services) {
			if (RuntimeDataService.class.isAssignableFrom(o.getClass())) {
				runtimeDataService = (RuntimeDataService) o;
				continue;
			}

			if (KieServerRegistry.class.isAssignableFrom(o.getClass())) {
				context = (KieServerRegistry) o;
				continue;
			}
		}

		List<Object> components = new ArrayList<Object>(1);
		if (SupportedTransports.REST.equals(type)) {
			logger.info("Adding Process Instance Tree resource endpoints ...");
			components.add(new VerizonTaskInstanceTreeResource(runtimeDataService, context));
		}
		return components;
	}
}