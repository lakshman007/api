package com.verizon.sp.kie;

import static org.kie.server.remote.rest.common.util.RestUtils.getContentType;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.WorkItemNotFoundException;
import org.jbpm.services.api.admin.ProcessInstanceAdminService;
import org.jbpm.services.api.model.NodeInstanceDesc;
import org.kie.api.runtime.query.QueryContext;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

@Api(value = "Complete WorkItem")
@Path("verizon/server")
public class WorkitemResource {
	private static final Logger logger = LoggerFactory.getLogger(WorkitemResource.class);
	
	private ProcessService processService;
	private ProcessInstanceAdminService adminService;
	private RuntimeDataService runtimeDataService;
	private MarshallerHelper marshallerHelper;
	private KieServerRegistry context;
	
	   public static final String COMPLETE_WORKITEM_JSON = "{\n" +
	            "    \"Age\" : 30,\n" +
	            "    \"person\" : {\n" + 
	            "        \"First name\" : \"John\",\n" +
	            "        \"Last name\" : \"smith\",\n" +
	            "        \"ID\" : \"1345\"\n" +
	            "    }\n" +
	            "}";
	   
	public WorkitemResource(ProcessService processService, RuntimeDataService runtimeDataService,
			ProcessInstanceAdminService adminService, KieServerRegistry context) {
		this.processService = processService;
		this.runtimeDataService = runtimeDataService;
		this.adminService = adminService;
		this.context = context;
		this.marshallerHelper = new MarshallerHelper(context);
	}
	
	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Completes a specified work item for a specified process instance.", response = String.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process instance or WorkItem id not found"),
			@ApiResponse(code = 200, message = "Successfull response") })
	@PUT
	@Path("/processes/instances/{processInstanceId}/workitems/{workItemId}/completed")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN })
	public Response completeworkitem(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "identifier of the process instance", required = true, example = "123") @PathParam("processInstanceId") Long processInstanceId,
			@ApiParam(value = "identifier of the WorkItem Id to be completed", required = true, example = "14236") @PathParam("workItemId") Long workItemId,
			@ApiParam(value = "optional outcome data give as map", required = false, examples = @Example(value = {
					@ExampleProperty(mediaType = "application/json", value = COMPLETE_WORKITEM_JSON) })) String wipayload) {

		logger.debug("WorkItem Id {} in process Instance id: {} with workitem payload {}", workItemId, processInstanceId, wipayload);
		Map<String,Object> payloadItems=new HashMap<String,Object>();
		final String type = getContentType(headers);
		try 
		{
					if(wipayload!=null) {
					payloadItems = marshallerHelper.unmarshal(wipayload, type, Map.class);}
					try {
					if(processService.getWorkItem(workItemId)!=null)
					{
						logger.info("Came after checking workitem exists");
						if(processService.getWorkItem(workItemId).getState()==0)
						{
							logger.info("came into Workitem active");
						processService.completeWorkItem(workItemId, payloadItems);
						logger.info("Completed workitem");
						return Response.ok().entity("{\"statusCode\":0, \"errorCode\":\"SUCCESS\"}").build();
						//return Response.ok().entity("Successful").build();
						}
						else 
						{
							return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":-1, \"errorCode\":\"FLOW_NODE_NOT_ACTIVE\"}").build();
							//return Response.status(Status.NOT_FOUND).entity("WorkItem Id Not Active").build();
						}
					}
					}
					catch(WorkItemNotFoundException e)
					{
						e.printStackTrace();
						logger.info("Came into Catch");
						NodeInstanceDesc  nodeinstance=runtimeDataService.getNodeInstanceForWorkItem(workItemId);
						logger.info("got NodeInstanceDesc:: "+nodeinstance);
						if(nodeinstance!=null) {
							return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":-1, \"errorCode\":\"FLOW_NODE_NOT_ACTIVE\"}").build();
						}
						else
						{
							return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":1, \"errorCode\":\"FLOW_NODE_NOT_PRESENT\"}").build();
						}
					}
			return null;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.debug(e.getMessage());
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	
    }
}
