package com.verizon.sp.kie.et;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.jbpm.services.api.model.NodeInstanceDesc;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.query.QueryContext;
import org.kie.internal.runtime.manager.context.EmptyContext;

import com.verizon.sp.kie.et.model.ProcessInstanceTree;

/**
 * 
 */
public class ProcessInstanceTreeServiceTest extends AbstractExecutionTreeTest {
	/**
	 * Testing 2 stops in Human tasks for a single parent with available not
	 * started sub-processes. Should always reply with a ProcessInstanceTree
	 * that reports the parent process with no sub-processes
	 */
	
	@Before
	public void setKSessionForDiagrams() {
		pitResource.setKieSession(deploymentService.getDeployedUnit(deploymentUnit.getIdentifier())
				.getRuntimeManager().getRuntimeEngine(EmptyContext.get()).getKieSession());
	}

	@Test
	public void testCompletedChildlessProcessInstance() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", false);
		params.put("runC", false);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Task", activeNodes.iterator().next().getName());

		assertEquals(1, _pit.getProcessNodes().length);

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert parent with only parent process instance.
		_pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);

		// The Parent Second Task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Second Task", activeNodes.iterator().next().getName());

		assertEquals(2, _pit.getProcessNodes().length);
		assertTrue("First node should be completed", _pit.getProcessNodes()[0].isCompleted());
		assertFalse("Second node should not be completed", _pit.getProcessNodes()[1].isCompleted());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert process completed
		pi = processService.getProcessInstance(processInstanceId);
		assertNull(pi);
		// Assert tree
		_pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);

		assertEquals(2, _pit.getProcessNodes().length);
		assertTrue("First node should be completed", _pit.getProcessNodes()[0].isCompleted());
		assertTrue("Second node should be completed", _pit.getProcessNodes()[1].isCompleted());
	}

	/**
	 * The parent process starts a simple sub-process with a human task. Before
	 * starting the sub-process the tree should not show any sub-processes.
	 * After starting the sub-process the tree shows 1 sub-process, and after
	 * completing the sub-process should still show 1 sub-process. Should always
	 * report the parent in the tree.
	 */

	@Test
	public void testLevel1SubProcess() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", true);
		params.put("runC", false);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert process variable to run sub-process
		assertEquals(true, processService.getProcessInstanceVariable(processInstanceId, "runB"));

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);
		assertEquals(1, _pit.getProcessNodes().length);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		Map<String, Object> htParams = new HashMap<String, Object>();
		htParams.put("oTaskParent", "Example output value");
		htParams.put("htRunA", false);
		htParams.put("htRunB", true);
		htParams.put("htRunC", false);
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		// Assert process variable to run sub-process
		assertEquals(true, processService.getProcessInstanceVariable(processInstanceId, "runB"));

		// Assert parent waiting for sub-process
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("spB", activeNodes.iterator().next().getName());

		// Assert tree with sub-process
		_pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);
		// Assert sub-process waiting for human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(
				_pit.getProcessNodes()[1].getProcessInstanceTree().getId(), new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Base Process Task", activeNodes.iterator().next().getName());
		assertEquals("spB", _pit.getProcessNodes()[1].getName());
		assertEquals("SubProcessNode", _pit.getProcessNodes()[1].getNodeType());
		assertNotNull(_pit.getProcessNodes()[1].getProcessInstanceTree());
		assertEquals("Base Process Task",
				_pit.getProcessNodes()[1].getProcessInstanceTree().getProcessNodes()[1].getName());

		// Claim and complete sub-process task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());
		// Assert tree contains parent and sub-process
		_pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);

		// Assert parent-process completed
		assertTrue("Parent process not completed", _pit.getState().equals(ProcessInstance.STATE_COMPLETED));
		// Assert sub-process completed
		assertTrue("Sub process not completed", _pit.getProcessNodes()[1].isCompleted());
		assertNotNull(_pit.getProcessNodes()[1].getProcessInstanceTree());
		assertTrue("Sub process not completed",
				_pit.getProcessNodes()[1].getProcessInstanceTree().getState().equals(ProcessInstance.STATE_COMPLETED));
	}

	/**
	 * Parent sub-process starts A, B and C; Then Process A starts X, Y and Z.
	 * Process B meanwhile is a base sub-process with only a human task. Process
	 * C starts another Base process. A.X starts another sub-process. A.Y starts
	 * another base sub-process. A.Z starts another base sub-process.
	 * A.X.sub-process starts another base sub-process. Each sub-process might
	 * have a human task to test waiting before starting the next sub-process
	 * and controlling if the sub-process should be started.
	 */

	@Test
	public void testAllSubprocessLevels() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", true);
		params.put("runB", true);
		params.put("runC", true);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);
		assertEquals(1, _pit.getProcessNodes().length);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		Map<String, Object> htParams = new HashMap<String, Object>();
		htParams.put("oTaskParent", "Example output value");
		htParams.put("htRunA", true);
		htParams.put("htRunB", true);
		htParams.put("htRunC", true);
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		// Assert process variable to run sub-process
		assertEquals(true, processService.getProcessInstanceVariable(processInstanceId, "runA"));
		assertEquals(true, processService.getProcessInstanceVariable(processInstanceId, "runB"));
		assertEquals(true, processService.getProcessInstanceVariable(processInstanceId, "runC"));

		// Assert parent waiting for sub-process
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(3, activeNodes.size());

		List<String> nodeNamesList = activeNodes.stream().map(n -> n.getName()).collect(Collectors.toList());
		assertTrue("Node spA not found", nodeNamesList.contains("spA"));
		assertTrue("Node spB not found", nodeNamesList.contains("spB"));
		assertTrue("Node sbC not found", nodeNamesList.contains("spC"));

		// Assert tree with sub-process
		_pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);
		assertEquals("SubProcessNode", _pit.getProcessNodes()[1].getNodeType());
		assertEquals("SubProcessNode", _pit.getProcessNodes()[2].getNodeType());
		assertEquals("SubProcessNode", _pit.getProcessNodes()[3].getNodeType());

		// find sub processes instance ids
		Long _spAId = 0L, _spBId = 0L, _spCId = 0L;
		int aIx = 0, bIx = 0, cIx = 0;
		for (int i = 1; i <= 3; i++) {
			if ("spA".equals(_pit.getProcessNodes()[i].getName())) {
				aIx = i;
			}
			if ("spB".equals(_pit.getProcessNodes()[i].getName())) {
				bIx = i;
			}
			if ("spC".equals(_pit.getProcessNodes()[i].getName())) {
				cIx = i;
			}
		}

		assertEquals("spA", _pit.getProcessNodes()[aIx].getName());
		_spAId = _pit.getProcessNodes()[aIx].getProcessInstanceTree().getId();
		assertEquals("spB", _pit.getProcessNodes()[bIx].getName());
		_spBId = _pit.getProcessNodes()[bIx].getProcessInstanceTree().getId();
		assertEquals("spC", _pit.getProcessNodes()[cIx].getName());
		_spCId = _pit.getProcessNodes()[cIx].getProcessInstanceTree().getId();

		// ===========================================================
		// RESOLVING SUB PROCESS A
		// ===========================================================
		// Assert sub-process A human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spAId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Process A Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		htParams = new HashMap<String, Object>();
		htParams.put("oTProcA", "Example output value");
		htParams.put("goX", true);
		htParams.put("goY", true);
		htParams.put("goZ", true);
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		// Assert process variable to run sub-process
		assertEquals(true, processService.getProcessInstanceVariable(_spAId, "goX"));
		assertEquals(true, processService.getProcessInstanceVariable(_spAId, "goY"));
		assertEquals(true, processService.getProcessInstanceVariable(_spAId, "goZ"));

		// Assert parent waiting for sub-process
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spAId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(3, activeNodes.size());

		nodeNamesList = activeNodes.stream().map(n -> n.getName()).collect(Collectors.toList());
		assertTrue("Node sp-X not found", nodeNamesList.contains("sp-X"));
		assertTrue("Node sp-Y not found", nodeNamesList.contains("sp-Y"));
		assertTrue("Node sb-Z not found", nodeNamesList.contains("sp-Z"));

		// Assert tree with sub-process
		_pit = pitResource.getProcessInstanceTree(_spAId, false);
		assertNotNull(_pit);

		int xIx = 0, yIx = 0, zIx = 0;
		for (int i = 1; i <= 3; i++) {
			if ("sp-X".equals(_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[i].getName())) {
				xIx = i;
			}
			if ("sp-Y".equals(_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[i].getName())) {
				yIx = i;
			}
			if ("sp-Z".equals(_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[i].getName())) {
				zIx = i;
			}
		}

		assertNotNull(
				_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[xIx].getProcessInstanceTree());
		assertEquals("SubProcessNode",
				_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[xIx].getNodeType());
		assertNotNull(
				_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[yIx].getProcessInstanceTree());
		assertEquals("SubProcessNode",
				_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[yIx].getNodeType());
		assertNotNull(
				_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[zIx].getProcessInstanceTree());
		assertEquals("SubProcessNode",
				_pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[zIx].getNodeType());

		// get sub process instance ids
		Long _spAXId = 0L, _spAYId = 0L, _spAZId = 0L;
		assertEquals("sp-X", _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[xIx].getName());
		_spAXId = _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[xIx].getProcessInstanceTree()
				.getId();

		assertEquals("sp-Y", _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[yIx].getName());
		_spAYId = _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[yIx].getProcessInstanceTree()
				.getId();

		assertEquals("sp-Z", _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[zIx].getName());
		_spAZId = _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[zIx].getProcessInstanceTree()
				.getId();

		// ===========================================================
		// RESOLVING SUB PROCESS A.X
		// ===========================================================
		// Assert sub-process A.X human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spAXId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Single Exclusive Task", activeNodes.iterator().next().getName());

		htParams = new HashMap<String, Object>();
		htParams.put("outTSE", "Example output value");
		htParams.put("execSub", true);

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		// Assert A.X waiting for sub-process
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spAXId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("base", activeNodes.iterator().next().getName());

		// Process Instance Tree has an additional sub-process
		_pit = pitResource.getProcessInstanceTree(_spAXId, false);
		assertNotNull(_pit);
		assertEquals("SubProcessNode", _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[xIx]
				.getProcessInstanceTree().getProcessNodes()[1].getNodeType());
		// assert the root parent id
		assertEquals(processInstanceId, _pit.getId());

		// Get the A.X.SUB process instance id
		Long _axSubId = _pit.getProcessNodes()[aIx].getProcessInstanceTree().getProcessNodes()[xIx]
				.getProcessInstanceTree().getProcessNodes()[1].getProcessInstanceTree().getId();

		// ===========================================================
		// RESOLVING SUB PROCESS A.X.SUB
		// ===========================================================
		// Assert sub-process A.X.SUB human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_axSubId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Base Process Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// tree remains the same, although latest sub-process was completed
		_pit = pitResource.getProcessInstanceTree(_axSubId, false);
		assertNotNull(_pit);
		// assert the root parent id
		assertEquals(processInstanceId, _pit.getId());

		// ===========================================================
		// RESOLVING SUB PROCESS A.Y
		// ===========================================================
		// Assert sub-process A.Y human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spAYId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Base Process Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// tree remains the same, although latest sub-process was completed
		_pit = pitResource.getProcessInstanceTree(_spAYId, false);
		assertNotNull(_pit);
		// assert the root parent id
		assertEquals(processInstanceId, _pit.getId());

		// ===========================================================
		// RESOLVING SUB PROCESS A.Z
		// ===========================================================
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spAZId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Base Process Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// tree remains the same, although latest sub-process was completed
		_pit = pitResource.getProcessInstanceTree(_spAZId, false);
		assertNotNull(_pit);
		// assert the root parent id
		assertEquals(processInstanceId, _pit.getId());

		// ===========================================================
		// RESOLVING SUB PROCESS B
		// ===========================================================
		// Assert sub-process B human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spBId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Base Process Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// tree remains the same, although latest sub-process was completed
		_pit = pitResource.getProcessInstanceTree(_spBId, false);
		assertNotNull(_pit);
		assertEquals(processInstanceId, _pit.getId());

		// ===========================================================
		// RESOLVING SUB PROCESS C
		// ===========================================================
		// Assert sub-process C human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spCId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Single Exclusive Task", activeNodes.iterator().next().getName());

		htParams = new HashMap<String, Object>();
		htParams.put("outTSE", "Example output value");
		htParams.put("execSub", true);

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		// Assert C waiting for sub-process
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_spCId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("base", activeNodes.iterator().next().getName());

		_pit = pitResource.getProcessInstanceTree(_spCId, false);
		assertNotNull(_pit);
		// assert the root parent id
		assertEquals(processInstanceId, _pit.getId());

		// Process Instance Tree has an additional sub-process
		assertNotNull(
				_pit.getProcessNodes()[cIx].getProcessInstanceTree().getProcessNodes()[1].getProcessInstanceTree());
		assertEquals("SubProcessNode",
				_pit.getProcessNodes()[cIx].getProcessInstanceTree().getProcessNodes()[1].getNodeType());

		// Get the C.SUB process instance id
		Long _cSubId = _pit.getProcessNodes()[cIx].getProcessInstanceTree().getProcessNodes()[1]
				.getProcessInstanceTree().getId();

		// ===========================================================
		// RESOLVING SUB PROCESS C.SUB
		// ===========================================================
		// Assert sub-process C.SUB human task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(_cSubId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Base Process Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// tree remains the same, although latest sub-process was completed
		_pit = pitResource.getProcessInstanceTree(_cSubId, false);
		assertNotNull(_pit);
		// assert the root parent id
		assertEquals(processInstanceId, _pit.getId());

		// Assert parent-process completed
		assertTrue("Parent process not completed", _pit.getState().equals(ProcessInstance.STATE_COMPLETED));

	}

	/**
	 * Parent subprocess hides The Parent Task from results list.
	 */

	@Test
	public void testSubProcessWithNodesDontDisplayHidden() {
		String hiddenNodeName = "The Parent Task";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", true);
		params.put("runB", true);
		params.put("runC", true);
		params.put("hiddenNodes", hiddenNodeName);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, true);
		assertNotNull(_pit);

		assertFalse("hiddent task should not appear in nodes list",
				Arrays.asList(_pit.getProcessNodes()).stream().anyMatch(n -> hiddenNodeName.equals(n.getName())));

		processService.abortProcessInstance(processInstanceId);
	}

	/**
	 * Parent subprocess displays nodes.
	 */

	@Test
	public void testSubProcessWithNodesDisplayNodes() {
		String humanTaskName = "The Parent Task";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", true);
		params.put("runB", true);
		params.put("runC", true);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, true);
		assertNotNull(_pit);

		assertTrue("Task should appear in nodes list",
				Arrays.asList(_pit.getProcessNodes()).stream().anyMatch(n -> humanTaskName.equals(n.getName())));
		processService.abortProcessInstance(processInstanceId);

	}
	
	@Test
	public void testSubProcessWithReceiveTaskNode() {
		Map<String, Object> params = new HashMap<String, Object>();

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"test-project.receive-task-with-external-call", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);

		assertEquals(_pit.getProcessNodes()[0].getNodeType(), "ReceiveTaskNode");
		processService.abortProcessInstance(processInstanceId);

	}
	
	@Test
	public void testSubProcessWithExternalCallerNode() {
		Map<String, Object> params = new HashMap<String, Object>();

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"test-project.external-caller", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);

		assertEquals(_pit.getProcessNodes()[0].getNodeType(), "ExternalCallerNode");
		processService.abortProcessInstance(processInstanceId);

	}

	@Test
	public void testShowControlNodes() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", false);
		params.put("runC", false);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, true);
		assertNotNull(_pit);
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Task", activeNodes.iterator().next().getName());

		assertEquals(2, _pit.getProcessNodes().length);
		assertEquals("StartNode", _pit.getProcessNodes()[0].getNodeType());
		assertEquals("The Parent Task", _pit.getProcessNodes()[1].getName());
		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testShowFailingNodes() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", false);
		params.put("runC", false);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		// Assert parent with only parent process instance.
		ProcessInstanceTree _pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("The Parent Task", activeNode.getName());

		assertEquals(1, _pit.getProcessNodes().length);
		assertEquals("The Parent Task", _pit.getProcessNodes()[0].getName());
		assertFalse(_pit.getProcessNodes()[0].isCompleted());
		assertFalse(_pit.getProcessNodes()[0].isFailed());

		processService.setProcessVariable(processInstanceId, "_failed_wis", activeNode.getWorkItemId());
		_pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);

		// assert node tagged as failed
		assertEquals(1, _pit.getProcessNodes().length);
		assertEquals("The Parent Task", _pit.getProcessNodes()[0].getName());
		assertFalse(_pit.getProcessNodes()[0].isCompleted());
		assertTrue(_pit.getProcessNodes()[0].isFailed());

		// assert node continues flagged as failed after completed
		Map<String, Object> htParams = new HashMap<String, Object>();
		htParams.put("oTaskParent", "Example output value");
		htParams.put("htRunA", false);
		htParams.put("htRunB", false);
		htParams.put("htRunC", false);
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNode.getWorkItemId()).getTaskId(), "Administrator",
				htParams);

		_pit = pitResource.getProcessInstanceTree(processInstanceId, false);
		assertNotNull(_pit);

		// assert node tagged as failed after completed
		assertEquals(2, _pit.getProcessNodes().length);
		assertEquals("The Parent Task", _pit.getProcessNodes()[0].getName());
		assertTrue(_pit.getProcessNodes()[0].isCompleted());
		assertTrue(_pit.getProcessNodes()[0].isFailed());

		processService.abortProcessInstance(processInstanceId);
	}
}