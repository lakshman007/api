/**
 * 
 */
package com.verizon.sp.kie;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.VariableDesc;
import org.junit.Test;
import org.kie.api.runtime.query.QueryContext;
import org.kie.server.services.impl.KieServerRegistryImpl;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author tordi7z
 *
 */
public class ReceiveTaskResourceTest extends ExternalCallerAbstractTest {

	@Test
	public void testCompleteReceiveTaskWithReceiveTaskExtension() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());

		Map<String, Object> vars = processService.getProcessInstanceVariables(processInstanceId);
		Boolean wsStageCompleted = (Boolean) vars.get("ws_stage_1");
		assertTrue(wsStageCompleted);

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService, bpmn2Service,
				new KieServerRegistryImpl());
		String correlationMapPayload = "{\"restResponseCode\":\"200\", \"correlationMap\": {\"orderId\":123}}";
		receiveTaskResource.receiveTask(testHeaders(), WIH_RECEIVE_TASK_PROCESS_NAME, "Test Work Item Handler",
				correlationMapPayload);

		// process instance is completed
		assertNull(processService.getProcessInstance(1L));
	}
	
	@Test
	public void testCompleteReceiveTaskWithTerminateEnd() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_TERMINATE_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());

		Map<String, Object> vars = processService.getProcessInstanceVariables(processInstanceId);
		Boolean wsStageCompleted = (Boolean) vars.get("ws_stage_1");
		assertTrue(wsStageCompleted);

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService, bpmn2Service,
				new KieServerRegistryImpl());
		String correlationMapPayload = "{\"restResponseCode\":\"200\", \"correlationMap\": {\"orderId\":123}}";
		receiveTaskResource.receiveTask(testHeaders(), WIH_RECEIVE_TASK_TERMINATE_PROCESS_NAME, "Test Work Item Handler",
				correlationMapPayload);

		// process instance is completed
		assertNull(processService.getProcessInstance(1L));
	}

	@Test
	public void testReceiveTaskNotFoundWithReceiveTaskExtension() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());

		Map<String, Object> vars = processService.getProcessInstanceVariables(processInstanceId);
		Boolean wsStageCompleted = (Boolean) vars.get("ws_stage_1");
		assertTrue(wsStageCompleted);

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService, bpmn2Service,
				new KieServerRegistryImpl());
		String payload = "{\"restResponseCode\":\"200\"}";
		javax.ws.rs.core.Response response = receiveTaskResource.receiveTask(testHeaders(),
				WIH_RECEIVE_TASK_PROCESS_NAME, "Test Work Item Handler", payload);
		assertTrue(response.getStatus() == 404);

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testServiceAndReceiveTaskPayloadsAreMerged() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"200\", \"variable_stage_1\": \"value_stage_1\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());

		Map<String, Object> vars = processService.getProcessInstanceVariables(processInstanceId);
		Boolean wsStageCompleted = (Boolean) vars.get("ws_stage_1");
		assertTrue(wsStageCompleted);

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService, bpmn2Service,
				new KieServerRegistryImpl());
		String correlationMapPayload = "{\"restResponseCode\":\"400\", \"variable_stage_2\": \"value_stage_2\", \"correlationMap\": {\"orderId\":123}}";
		receiveTaskResource.receiveTask(testHeaders(), WIH_RECEIVE_TASK_PROCESS_NAME, "Test Work Item Handler",
				correlationMapPayload);

		Collection<VariableDesc> stage1Var = runtimeDataService.getVariableHistory(processInstanceId,
				"variable_stage_1", new QueryContext());
		logger.debug("stage 1 var: {}", stage1Var);
		assertEquals("value_stage_1", stage1Var.iterator().next().getNewValue());

		Collection<VariableDesc> stage2Var = runtimeDataService.getVariableHistory(processInstanceId,
				"variable_stage_2", new QueryContext());
		logger.debug("stage 2 var: {}", stage2Var);
		assertEquals("value_stage_2", stage2Var.iterator().next().getNewValue());

		// process instance is completed
		assertNull(processService.getProcessInstance(1L));
	}

	@Test
	public void testCompleteReceiveTaskAllowsReceiveWhenSkipRESTIsTrue() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);
		params.put("SkipRESTOutbound", true);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService, bpmn2Service,
				new KieServerRegistryImpl());
		String correlationMapPayload = "{\"restResponseCode\":\"400\", \"variable_stage_2\": \"value_stage_2\", \"correlationMap\": {\"orderId\":123}}";
		receiveTaskResource.receiveTask(testHeaders(), WIH_RECEIVE_TASK_PROCESS_NAME, "Test Work Item Handler",
				correlationMapPayload);

		Collection<VariableDesc> stage2Var = runtimeDataService.getVariableHistory(processInstanceId,
				"variable_stage_2", new QueryContext());
		logger.debug("stage 2 var: {}", stage2Var);
		assertEquals("value_stage_2", stage2Var.iterator().next().getNewValue());

		// process instance is completed
		assertNull(processService.getProcessInstance(1L));
	}
	
	@Test
	public void testReceiveTaskWaitsForExternalAgent() {

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_RECEIVE_TASK_HT);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "HT"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Receive Test"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Receive Test", activeNodes.iterator().next().getName());

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService,
				bpmn2Service, new KieServerRegistryImpl());
		String payload = "{\"asyncStatusMessage\":\"deleteNetworkService\", \"asyncStatus\":\"true\"}";
		receiveTaskResource.receiveTaskWithPid(testHeaders(), String.valueOf(processInstanceId), "Receive Test",
				payload);
		assertEquals("deleteNetworkService",
				processService.getProcessInstanceVariable(processInstanceId, "asyncStatusMessage"));
		assertEquals("true", processService.getProcessInstanceVariable(processInstanceId, "asyncStatus"));

		// Assert that the state of the process is in "Task B"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task B", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testReceiveTaskWithIncorrectName() {

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_RECEIVE_TASK_HT);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "HT"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService,
				bpmn2Service, new KieServerRegistryImpl());
		Response response = receiveTaskResource.receiveTaskWithPid(testHeaders(), String.valueOf(processInstanceId),
				"Receive ", null);
		assertEquals(404, response.getStatus());
		Map<String, String> responseMap = null;
		try {
			responseMap = new ObjectMapper().readValue((String) response.getEntity(), Map.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("Task with name Receive  is not found in given process instance", responseMap.get("ErrorMsg"));

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testReceiveTaskWithPTWaitsForExternalAgent() {
		
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);
		params.put("SkipRESTOutbound", true);
		
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_RECEIVE_TASK_HT_PROCESS_ID,params);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "HT"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Receive Test"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Test Work Item Handler", activeNodes.iterator().next().getName());

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService,
				bpmn2Service, new KieServerRegistryImpl());
		String payload = "{\"receiveMessage\":\"deleteNetworkService\", \"correlationMap\": {\"orderId\":123}}";
		receiveTaskResource.receiveTask(testHeaders(), WIH_RECEIVE_TASK_HT_PROCESS_NAME, "Test Work Item Handler",
				payload);
		assertEquals("deleteNetworkService",
				processService.getProcessInstanceVariable(processInstanceId, "receiveMsg"));

		// Assert that the state of the process is in "Task B"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task B", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);

	}
	
	@Test
	public void testReceiveTaskWithWIHNotActive() {
		
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);
		params.put("SkipRESTOutbound", true);
		params.put("_rt_orderId", 123);
		
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_RECEIVE_TASK_HT_PROCESS_ID,params);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "HT"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService,
				bpmn2Service, new KieServerRegistryImpl());
		String payload = "{\"receiveMessage\":\"deleteNetworkService\", \"correlationMap\": {\"orderId\":123}}";
		receiveTaskResource.receiveTask(testHeaders(), WIH_RECEIVE_TASK_HT_PROCESS_NAME, "Test Work Item Handler",
				payload);
		
		assertEquals(payload,processService.getProcessInstanceVariable(processInstanceId, "_rt_"+WIH_RECEIVE_TASK_HT_PROCESS_NAME+"_TestWorkItemHandler"));

		processService.abortProcessInstance(processInstanceId);

	}
	
	@Test
	public void testReceiveTaskWithWIHNotActiveWithWorkflowId() {
		
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("workflowId", "1");
		params.put("correlationMap", correlationMap);
		params.put("SkipRESTOutbound", true);
		params.put("_rt_orderId", 123);
		
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_RECEIVE_TASK_HT_PROCESS_ID,params);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "HT"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		ReceiveTaskResource receiveTaskResource = new ReceiveTaskResource(processService, runtimeDataService,
				bpmn2Service, new KieServerRegistryImpl());
		String payload = "{\"receiveMessage\":\"deleteNetworkService\", \"correlationMap\": {\"orderId\":123}}";
		receiveTaskResource.receiveTask(testHeaders(), WIH_RECEIVE_TASK_HT_PROCESS_NAME, "Test Work Item Handler",
				payload);
		
		assertEquals(payload,processService.getProcessInstanceVariable(processInstanceId, "_rt_"+WIH_RECEIVE_TASK_HT_PROCESS_NAME+"_TestWorkItemHandler"));

		processService.abortProcessInstance(processInstanceId);

	}
}

