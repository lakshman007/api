/**
 * 
 */
package com.verizon.sp.kie;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.jbpm.services.api.DeploymentNotFoundException;
import org.jbpm.services.api.NodeNotFoundException;
import org.jbpm.services.api.ProcessInstanceNotFoundException;
import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.admin.ProcessInstanceAdminService;
import org.jbpm.services.api.model.NodeInstanceDesc;
import org.kie.api.runtime.query.QueryContext;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.sp.kie.model.ReflowRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

/**
 * @author tordi7z
 *
 */
@Api(value = "Reflow API")
@Path("verizon/reflow")
public class ReflowResource {
	private static final Logger logger = LoggerFactory.getLogger(ReflowResource.class);

	//@formatter:off
	private final static String JSON_EXAMPLE = "{\n" +
	"    \"death-pool\": [\"External Caller\", \"Human Task\"],\n" +
	"    \"compensation-name\": \"compensate\",\n" + 
	"    \"process-vars\": {\n" +
	"        \"foo\": \"test value\"\n"+
	"    }\n" +
	"}";
	//@formatter:on

	private ProcessService processService;
	private ProcessInstanceAdminService adminService;
	private RuntimeDataService runtimeDataService;

	private MarshallerHelper marshallerHelper;

	public ReflowResource(ProcessService processService, RuntimeDataService runtimeDataService,
			ProcessInstanceAdminService adminService) {
		this.processService = processService;
		this.runtimeDataService = runtimeDataService;
		this.adminService = adminService;

		this.marshallerHelper = new MarshallerHelper(null);
	}

	@ApiOperation(value = "Reflow a process instance to a previously executed node", response = String.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process instance, Container id or node name not found"),
			@ApiResponse(code = 200, message = "Successfull response", examples = @Example(value = {
					@ExampleProperty(mediaType = "text/plain", value = "Successful") })) })
	@POST
	@Path("{processInstanceId}/{taskName}")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.TEXT_PLAIN })
	public Response reflow(
			@ApiParam(value = "identifier of the process instance to be modified", required = true, example = "123") @PathParam("processInstanceId") Long processInstanceId,
			@ApiParam(value = "task name to reflow to", required = true, example = "TaskA") @PathParam("taskName") String taskName,
			@ApiParam(value = "Reflow request details", required = false, examples = @Example(value = {
					@ExampleProperty(mediaType = "application/json", value = JSON_EXAMPLE) })) String reflowRequest) {

		logger.debug("Reflowing task {} in process Instance id: {} with reflow definition {}", taskName,
				processInstanceId, reflowRequest);

		try {
			ReflowRequest request = marshallerHelper.unmarshal(reflowRequest, "application/json", ReflowRequest.class);
			Collection<NodeInstanceDesc> nodeInstances = adminService.getActiveNodeInstances(processInstanceId);

			// Assign all process variables
			// Here we are assigning before reflowing, because automatic tasks
			// can take the new values when reflowing so they can possibly
			// follow a different gateway or decision path.
			Map<String, Object> variables = new HashMap<>();
			if (null != request && null != request.getProcessVars() && request.getProcessVars().size() != 0) {
				for (Map.Entry<String, Object> pv : request.getProcessVars().entrySet()) {
					logger.debug("Variable Name: {}", pv.getKey());
					logger.debug("Variable Value: {}", pv.getValue());
					variables.put(pv.getKey(), pv.getValue());
				}
			}
			processService.setProcessVariables(processInstanceId, variables);

			// Cancel Node Instances
			// WARNING: "restarting" a node instance with out adding it to the
			// death pool, can cause concurrent modification issues to shared
			// classes and data through the process instance
			if (null != request && null != request.getDeathPool() && !request.getDeathPool().isEmpty()) {
				nodeInstances.stream().forEach(n -> {
					// Validate if ALL is in the list of cancel nodes or if the
					// node-name is included in the list of cancel nodes
					if (request.getDeathPool().contains("ALL") || request.getDeathPool().contains(n.getName())) {
						logger.debug("Found node with name {}, Cancelling node instance id id: {}", n.getName(),
								n.getId());
						adminService.cancelNodeInstance(processInstanceId, n.getId());
					}
					// We had the idea that re-starting could take advantage of
					// this loop to know its node id and reflow. Note that the
					// nodeId received from adminService.getActiveNodes is not
					// the same id that we receive from
					// adminService.getProcessNodes. The
					// adminService.getProcessNodes give us a ProcessNode, with
					// a processNodeId; that is the id required to reflow. The
					// Id that we hold here is different than the one received
					// from the ProcessNode.
				});
			}

			adminService.triggerNode(processInstanceId, getNodeIdFromName(processInstanceId, taskName));

			// trigger signal only when compensation signal is sent
			// We compensate the transaction to the end, in case the signal is
			// performing some termination actions that can possibly prevent us
			// from activating/deactivating nodes
			if (null != request.getCompensationName() && !request.getCompensationName().isEmpty()) {
				// Compensate and signal the process instance
				processService.signalProcessInstance(processInstanceId, request.getCompensationName(), null);
			}
		} catch (NodeNotFoundException | DeploymentNotFoundException | ProcessInstanceNotFoundException
				| IllegalArgumentException e) {
			logger.debug("not found exception: {}", e);
			return Response.status(Status.NOT_FOUND).entity(e.getMessage()).build();
		} catch (Exception e) {
			logger.error("Exception while triggering node", e);
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

		return Response.ok().entity("Successful").build();
	}

	private Long getNodeIdFromName(Long processInstanceId, String nodeName) {
		// Validate that the node id has been previously executed
		runtimeDataService.getProcessInstanceHistoryCompleted(processInstanceId, new QueryContext(0, 1000)).stream()
				.filter(n -> nodeName.equals(n.getName())).findFirst().orElseThrow(() -> new IllegalArgumentException(
						"Node " + nodeName + " Not found in process instance executed nodes."));

		return adminService.getProcessNodes(processInstanceId).stream().filter(n -> nodeName.equals(n.getNodeName()))
				.findFirst()
				.orElseThrow(() -> new IllegalArgumentException("Node " + nodeName + " Not found in process instance."))
				.getNodeId();
	}

}
