
package com.verizon.sp.kie;

import static org.kie.server.remote.rest.common.util.RestUtils.internalServerError;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.JSON;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.VAR_MAP_JSON;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.VAR_MAP_XML;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.XML;
import static org.kie.server.remote.rest.jbpm.resources.Messages.CREATE_RESPONSE_ERROR;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Variant;

import org.drools.core.process.instance.WorkItemHandler;
import org.jbpm.services.api.DeploymentNotFoundException;
import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.ProcessInstanceDesc;
import org.jbpm.services.api.model.UserTaskInstanceDesc;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.process.WorkItem;
import org.kie.server.api.rest.RestURI;
import org.kie.server.remote.rest.common.Header;
import org.kie.server.remote.rest.common.util.RestUtils;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.sp.caller.ExternalCaller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

/**
 * Provides two kie-server extensions - 1) Is to either REFLOW the external call
 * to fuse or abort the {@link WorkItemHandler} - 2) To complete the
 * {@link WorkItem}, which has an additional signaling logic based on the
 * response code received
 * 
 * @author motappa
 */
@Api(value = "Verizon Workitem Handler Completion/Reflow")
@Path("verizon/server/" + RestURI.PROCESS_URI)
public class ReflowExternalCallerResource {

	private static final Logger logger = LoggerFactory.getLogger(ReflowExternalCallerResource.class);
	private ProcessService processService;
	private RuntimeDataService runtimeDataService;
	private KieServerRegistry context;
	private MarshallerHelper marshallerHelper;
	private static final String SIGNAL_MAP = "SignalMap";
	private static final String RESPONSE_CODE = "999";
	private static final String REFLOW = "REFLOW";
	private static final String ABORT = "ABORT";
	private static final String REST_RESPONSE_CODE = "restResponseCode";
	private static final String DEFAULT = "default";
	private static final String RESULT = "result";
	private static final String WORK_ITEM_ID = "workItemId";
	private static final String CORRELATION_MAP = "correlationMap";
	private static final String TASK_NAME = "taskName";
	private static final String REST_RESULT = "restResult";
	private static final String TASK_HEADER = "taskHeader";
	private static final String HUMAN_TASK_INFO_ID = "humanTaskInfoId";
	private static final String EXTERNAL_TASK_ID = "externalTaskId";
	private static final String TASK_ACTION = "taskAction";

	public ReflowExternalCallerResource(ProcessService processService, RuntimeDataService runtimeDataService,
			KieServerRegistry context) {
		this.processService = processService;
		this.runtimeDataService = runtimeDataService;
		this.context = context;
		this.marshallerHelper = new MarshallerHelper(context);
	}

	/**
	 * Provides the ability to complete the {@link WorkItemHandler} and in addition
	 * sends the signal to parent process based on the received {@link Response}
	 * code
	 */
	@ApiOperation(value = "Complete external caller", response = Long.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 201, response = Long.class, message = "completed"),
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process ID, Container ID, or WorkItem ID not found") })
	@POST
	@Path(RestURI.PROCESS_INSTANCE_WORK_ITEM_COMPLETE_PUT_URI)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response completeExternalCallerWorkItem(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "Container ID", required = true) @PathParam(RestURI.CONTAINER_ID) String containerId,
			@ApiParam(value = "Process Instance ID", required = true) @PathParam(RestURI.PROCESS_INST_ID) String processInstanceId,
			@ApiParam(value = "WorkItem ID", required = true) @PathParam(RestURI.WORK_ITEM_ID) String workItemId,
			@ApiParam(value = "Payload of external call", required = false, examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = VAR_MAP_JSON),
					@ExampleProperty(mediaType = XML, value = VAR_MAP_XML) })) @DefaultValue("") String externalCallPayload) {
		logger.debug("Received call to complete work item {} with payload: {}", workItemId, externalCallPayload);
		final Variant v = RestUtils.getVariant(headers);
		final String contentType = RestUtils.getContentType(headers);

		try {
			validateInput(containerId, processInstanceId, workItemId);

			final Long piId = Long.parseLong(processInstanceId);
			final Long wiId = Long.parseLong(workItemId);

			List<String> uteResponse = Arrays.asList(TASK_HEADER, HUMAN_TASK_INFO_ID, EXTERNAL_TASK_ID, TASK_ACTION);

			boolean isUTEResponse = uteResponse.stream().allMatch(s -> externalCallPayload.contains(s));

			if (isUTEResponse) {
				Map<String, Object> responseMap = new ObjectMapper().readValue(externalCallPayload, Map.class);
				logger.info("UTE service call responsecode,response: {},{}", responseMap.get(REST_RESPONSE_CODE),
						responseMap.get(REST_RESULT));
			} else {
				Thread asyncThread = new Thread(() -> {
					WorkItem workItem = null;
					for (int retrycount = 0; retrycount <= 5; retrycount++) {
						try {
							workItem = processService.getWorkItem(wiId);
							logger.debug("WorkItem object parameters are " + workItem.getParameters());
							break;
						} catch (Exception e) {
							if (retrycount < 5) {
								logger.debug(
										"Workitem for workitemid {} is not ready. If the request is for completing human task please ignore the warning.. retrying {}",
										workItemId, retrycount + 1);
								try {
									Thread.sleep(1000L);
								} catch (InterruptedException e1) {
									logger.warn("InterruptedException occured during thread sleep");
								}
							} else {
								logger.warn(
										"Workitemid {} could not be found, retries exhausted If the request is for completing human task please ignore the warning..",
										workItemId);

								try {
									Map<String, Object> responseMap = new ObjectMapper().readValue(externalCallPayload,
											Map.class);
									logger.info("Response for Workitem {} with responsecode,responsebody: {},{}",
											workItemId, responseMap.get(REST_RESPONSE_CODE),
											responseMap.get(REST_RESULT));
								} catch (IOException exception) {
									logger.error("Unsuccessful response for workitemid {}: {}", workItemId,
											externalCallPayload);
								}

							}
						}
					}
					if (null != workItem) {
						signalAndCompleteWorkitem(workItem, externalCallPayload, contentType, containerId);
					}
				});
				asyncThread.start();
			}
			logger.debug("Replying back to caller, completed work item {}", workItemId);
			return prepareResponse(headers, containerId, v, contentType, piId, Response.Status.OK);
		} catch (Exception e) {
			logger.error("Unexpected error during processing", e);
			return internalServerError(MessageFormat.format(CREATE_RESPONSE_ERROR, e), v);
		}
	}

	/**
	 * Provides the ability to either REFLOW or ABORT the {@link WorkItemHandler},
	 * in addition to default {@link WorkItemHandler} this API provides an option to
	 * either REFLOW Rest call to fuse or ABORT {@link WorkItemHandler}
	 */
	@ApiOperation(value = "Reflow external caller", response = Long.class, code = 202)
	@ApiResponses(value = { @ApiResponse(code = 201, response = Long.class, message = "completed"),
			@ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process ID, Container ID, or WorkItem ID not found") })
	@POST
	@Path("instances/{processInstanceId}/workitems/{workItemId}/reflow")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response reflowOrAbortExternalCallerWorkItem(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "Container ID", required = true) @PathParam(RestURI.CONTAINER_ID) String containerId,
			@ApiParam(value = "Process Instance ID", required = true) @PathParam(RestURI.PROCESS_INST_ID) String processInstanceId,
			@ApiParam(value = "WorkItem ID", required = true) @PathParam(RestURI.WORK_ITEM_ID) String workItemId,
			@ApiParam(value = "optional action to perform (reflow,abort) - defaults to reflow (1) only", required = false, allowableValues = "REFLOW,ABORT") @QueryParam("action") List<String> action,
			@ApiParam(value = "Payload of external call", required = false, examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = VAR_MAP_JSON),
					@ExampleProperty(mediaType = XML, value = VAR_MAP_XML) })) @DefaultValue("") String externalCallPayload) {

		final Variant v = RestUtils.getVariant(headers);
		final String contentType = RestUtils.getContentType(headers);
		long piId = -2L;
		long wiId = -2L;
		try {
			validateInput(containerId, processInstanceId, workItemId);

			piId = Long.parseLong(processInstanceId);
			wiId = Long.parseLong(workItemId);

			if (null == action || action.isEmpty() || action.size() > 1) {
				action = new ArrayList<String>();
				logger.debug("Defaulting to REFLOW as there is no input action");
				action.add(REFLOW);
			}

			Response response = null;

			if (action.get(0).equalsIgnoreCase(REFLOW)) {
				Status status = reflow(containerId, piId, wiId);
				response = prepareResponse(headers, containerId, v, contentType, piId, status);
			} else if (action.get(0).equalsIgnoreCase(ABORT)) {
				logger.info("Aborting the workitem : {}", wiId);
				processService.abortWorkItem(containerId, piId, wiId);
				logger.debug("Abort request was processed...");
				response = prepareResponse(headers, containerId, v, contentType, piId, Response.Status.ACCEPTED);
			} else {
				logger.error("Action might have wrong entries please validate and retry .....");
				response = prepareResponse(headers, containerId, v, contentType, piId, Response.Status.BAD_REQUEST);
			}
			return response;
		} catch (Exception e) {
			logger.error("Unexpected error during processing", e);
			return internalServerError(MessageFormat.format(CREATE_RESPONSE_ERROR, e.getMessage()), v);
		}
	}

	@SuppressWarnings("unchecked")
	private void signalAndCompleteWorkitem(WorkItem workItem, String externalCallPayload, String contentType,
			String containerId) {
		logger.debug("WorkItem object parameters are " + workItem.getParameters());

		Map<String, Object> payloadItems = new HashMap<String, Object>();
		/**
		 * Unmarshall the payload - the unmarshal will return if the null or empty
		 * payload if sent.
		 */

		// Sample payload -
		// {"version":"1.1.4","restResult":"<jsonresponse>","result":"<xml/errorresponse>","restResponseCode":"404"}
		try {
			payloadItems = marshallerHelper.unmarshal(externalCallPayload, contentType, Map.class);
			logger.debug("payload items after marshalling: " + payloadItems);

			// This is executed only if result is not empty
			String result = null != payloadItems.get(RESULT) ? payloadItems.get(RESULT).toString() : null;
			if (null != result && !result.isEmpty()) {
				extractXMLResponse(result, payloadItems);
			}

		} catch (Exception e) {

			payloadItems.put(RESULT, externalCallPayload);
			logger.warn(
					"Payload received from FUSE is not Json marshable, communicating the following to the process: [{}]",
					externalCallPayload);
		}
		/**
		 * Adding a default code of 999, this is for situations when we don't receive a
		 * null, blank response code from FUSE
		 */

		String restResponseCodeStr = (String) payloadItems.getOrDefault(REST_RESPONSE_CODE, RESPONSE_CODE);
		int restResponseCodeInt = Integer.valueOf(restResponseCodeStr);
		Status status = Status.fromStatusCode(restResponseCodeInt) == null ? Status.INTERNAL_SERVER_ERROR
				: Status.fromStatusCode(restResponseCodeInt);

		/**
		 * From WorkItem, read signalMap which defines what action should be taken based
		 * on the received response code.
		 **/
		Object statusCodeActionsObj = workItem.getParameter(SIGNAL_MAP);
		logger.debug("Signal map: {}", statusCodeActionsObj);
		// Set workitemId for handling a scenario in Exception handling
		NodeInstanceDesc nodeInstance = runtimeDataService.getNodeInstanceForWorkItem(workItem.getId());
		payloadItems.put(WORK_ITEM_ID, workItem.getId());
		payloadItems.put(TASK_NAME, nodeInstance.getName());
		if (null != statusCodeActionsObj && statusCodeActionsObj instanceof Map<?, ?>) {
			Map<String, String> statusCodeActions = (Map<String, String>) statusCodeActionsObj;
			if (statusCodeActions.containsKey(restResponseCodeStr)) {
				logger.debug("Triggering signal {}", statusCodeActions.get(restResponseCodeStr));
				triggerSignal(workItem.getProcessInstanceId(), payloadItems,
						statusCodeActions.get(restResponseCodeStr));
			} else if (statusCodeActions.containsKey(DEFAULT)
					&& status.getFamily() != Response.Status.Family.SUCCESSFUL) {
				logger.debug("Triggering DEFAULT Signal");
				triggerSignal(workItem.getProcessInstanceId(), payloadItems, statusCodeActions.get(DEFAULT));
			}
		}

		// Complete only if no error found, and HaltOnException is False.
		Boolean haltOnException = workItem.getParameter("HaltOnException") == null ? false
				: (Boolean) workItem.getParameter("HaltOnException");

		Boolean isHumanTask = workItem.getParameter("Skippable") != null;
		Boolean succeed = status.getFamily() == Response.Status.Family.SUCCESSFUL;

		if (!succeed) {
			final String failedWisVarName = "_failed_wis";
			String failedWis = (String) processService.getProcessInstanceVariable(workItem.getProcessInstanceId(),
					failedWisVarName);
			if (failedWis == null || failedWis.trim().length() == 0) {
				processService.setProcessVariable(workItem.getProcessInstanceId(), failedWisVarName,
						String.valueOf(workItem.getId()));
			} else {
				failedWis = failedWis + "," + workItem.getId();
				processService.setProcessVariable(workItem.getProcessInstanceId(), failedWisVarName, failedWis);
			}
		}

		Boolean isReceiveTask = workItem.getParameter(CORRELATION_MAP) != null;

		// This is POSSIBLY a Human Task, as human tasks are one of the few
		// nodes to include an "Skippable" parameter
		if (isHumanTask) {
			isHumanTask = false;
			try {
				UserTaskInstanceDesc itid = runtimeDataService.getTaskByWorkItemId(workItem.getId());
				isHumanTask = itid != null;
			} catch (Exception e) {
			}
		}

		if (!isHumanTask && !isReceiveTask && succeed) {
			logger.debug("==== > Complete work item handler {}: succeed, Not a Human Task, nor a Receive Task",
					workItem.getId());
			processService.completeWorkItem(workItem.getId(), payloadItems);
		} else if (!isHumanTask && !succeed && !haltOnException && !isReceiveTask) {
			logger.debug(
					"==== > Complete work item handler {}: failed, not a Human Task, nor a Receive Task, and not a halt on exception {}",
					workItem.getId());
			processService.completeWorkItem(workItem.getId(), payloadItems);
		}

		if (haltOnException && !succeed && logger.isDebugEnabled()) {
			logger.debug("Halted on Exception, exception code received as {}", restResponseCodeStr);
		}

		if (isHumanTask) {
			logger.info("Human task service call responsecode,response: {},{}", payloadItems.get(REST_RESPONSE_CODE),
					payloadItems.get(REST_RESULT));
		}

		if (isReceiveTask) {

			String processName = ((ProcessInstanceDesc) runtimeDataService
					.getProcessInstanceById(workItem.getProcessInstanceId())).getProcessName();
			ProcessInstanceDesc processInstance = findRootProcessInstance(workItem.getProcessInstanceId());
			
			String rtVariable = "_rt_" + (null != processName ? processName.replace(" ", "") : null) + "_"
					+ (null != nodeInstance ? nodeInstance.getName().replace(" ", "") : null);
			String processVariable = null;
			if(null!= processInstance) {
				processVariable = (String) processService.getProcessInstanceVariable(processInstance.getId(),
						rtVariable);
			}
			if (null != processVariable && !processVariable.isEmpty()) {

				Map<String, Object> rtPayload = marshallerHelper.unmarshal(processVariable, "application/json",
						Map.class);
				payloadItems.putAll(rtPayload);
				processService.setProcessVariable(processInstance.getId(), rtVariable, null);
				processService.completeWorkItem(workItem.getId(), payloadItems);

			} else {

				processService.setProcessVariable(workItem.getProcessInstanceId(), "ws_stage_" + workItem.getId(),
						true);
				processService.setProcessVariable(workItem.getProcessInstanceId(), "payload_wi_" + workItem.getId(),
						payloadItems);
			}
		}
	}

	/**
	 * Bubbles up to find and return the root process instance of inquired base
	 * process instance
	 *
	 * @param processInstanceId Base process instance to be fetched
	 * @return {@link ProcessInstanceDesc} root process instance of base process
	 *         instance
	 * @throws DeploymentNotFoundException
	 */
	private ProcessInstanceDesc findRootProcessInstance(Long processInstanceId) throws DeploymentNotFoundException {
		logger.debug("Find the Root Process Instance for {}", processInstanceId);
		ProcessInstanceDesc _pid = runtimeDataService.getProcessInstanceById(processInstanceId);
		if(null!=_pid) {
			if (_pid.getParentId() == -1) {
				logger.debug("Found the Root Process Instance {}", processInstanceId);
				return _pid;
			} else {
				logger.debug("Found a Parent Process Instance {}", _pid.getParentId());
				return findRootProcessInstance(_pid.getParentId());
			}
		}
		return null;
	}

	/**
	 * Validates containerID, processInstanceID and WorkItemID are not null, blank
	 * or empty
	 * 
	 * @param containerId       ContainerID cannot be null, blank or empty
	 * @param processInstanceId ProcessInstanceID cannot be null, blank or empty
	 * @param workItemId        WorkItemID cannot be null, blank or empty
	 */
	private void validateInput(String containerId, String processInstanceId, String workItemId) {
		if (null == containerId || containerId.trim().isEmpty()) {
			logger.error("Container ID cannot be null, blank or empty");
			throw new IllegalArgumentException("Container ID is either null, blank or empty");
		}
		if (null == processInstanceId || processInstanceId.trim().isEmpty()) {
			logger.error("Process Instance ID cannot be null, blank or empty");
			throw new IllegalArgumentException("ProcessInstance ID is either null, blank or empty");
		}
		if (null == workItemId || workItemId.trim().isEmpty()) {
			logger.error("WorkItem ID cannot be null, blank or empty");
			throw new IllegalArgumentException("WorkItem ID is either null, blank or empty");
		}
	}

	/**
	 * Instantiates the REFLOW of call from PAM to FUSE
	 * 
	 * @param containerId ContainerID, should not be null, blank or empty
	 * @param piId        ProcessInstanceID, should not be null, blank or empty
	 * @param wiId        WorkItemID should not be null, blank or empty
	 * @return {@link Response} object
	 * @throws IOException
	 */
	private Status reflow(String containerId, long piId, long wiId) throws IOException {
		logger.info("Reflowing the workitem : {}", wiId);
		WorkItem workItem = processService.getWorkItem(containerId, piId, wiId);
		ExternalCaller caller = new ExternalCaller();
		Response response = caller.execute(workItem, false);
		logger.debug("Reflow request is processed and received response : {} ", response.toString());
		return Status.fromStatusCode(response.getStatus());
	}

	/**
	 * Prepares the {@link Response} based on the passed in input parameters along
	 * with the {@link Status} code
	 * 
	 * @return {@link Response} object
	 */
	private Response prepareResponse(HttpHeaders headers, String containerId, final Variant v, final String contentType,
			long piId, Status status) {
		String response = marshallerHelper.marshal(contentType, piId);
		if (context != null) {
			Header conversationIdHeader = RestUtils.buildConversationIdHeader(containerId, context, headers);
			return RestUtils.createResponse(response, v, status, conversationIdHeader);
		} else {
			return RestUtils.createResponse(response, v, status);
		}
	}

	/**
	 * Triggers signal event
	 * 
	 * @param piId
	 * @param payloadItems
	 * @param signalName
	 */
	private void triggerSignal(Long piId, Map<String, Object> payloadItems, String signalName) {
		logger.debug("=====> sending signal name: {}", signalName);
		ProcessInstance processInstance = processService.getProcessInstance(piId);
		logger.debug("=====> process instance id = {}", processInstance.getId());
		while (processInstance.getParentProcessInstanceId() >= 0) {
			processInstance = processService.getProcessInstance(processInstance.getParentProcessInstanceId());
			logger.debug("=====> parent process instance id = {}", processInstance.getId());
		}

		logger.debug("Triggering signal {} for process instance {}", signalName, processInstance.getId());
		processService.signalProcessInstance(processInstance.getId(), signalName, payloadItems);
	}

	/**
	 * This method is to umarshal the result field and set the value into restResult
	 * for xml/error responses
	 * 
	 * @param payloadItems
	 */
	private void extractXMLResponse(String result, Map<String, Object> payloadItems) {

		try {
			// Unmarshal the result field from the response with xml as we are expecting the
			// content to be either XML or text
			Map<String, Object> resultMap = marshallerHelper.unmarshal(result, "text/xml", Map.class);
			payloadItems.put(REST_RESULT, resultMap);
		} catch (Exception e) {
			// For the error response
			payloadItems.put(REST_RESULT, result);
		}
	}
}
