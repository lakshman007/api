package com.jbpm.services;

import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.UserTaskServicesClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jbpm.constants.JBPMConstants;

@Service("service")
@PropertySource("classpath:JBPM.properties")
public class JBPMService {

	private static final Logger logger = LoggerFactory.getLogger(JBPMService.class);

	@Autowired
	private Environment config;

	public Environment getConfig() {
		return config;
	}

	public KieServicesClient getKieClient() {
		logger.debug("[getKieClient]");
		return KieServicesFactory.newKieServicesClient(
				BPMRuntimeFactory.getKieConfig(config.getProperty(JBPMConstants.JBPM_SERVER_URL),
						config.getProperty(JBPMConstants.JBPM_USER), config.getProperty(JBPMConstants.JBPM_PASSWORD)));
	}

	public UserTaskServicesClient getTaskClient() {
		return getKieClient().getServicesClient(UserTaskServicesClient.class);
	}

}
