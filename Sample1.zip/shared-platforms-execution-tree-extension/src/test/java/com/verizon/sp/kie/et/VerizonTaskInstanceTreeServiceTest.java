package com.verizon.sp.kie.et;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.ProcessInstanceDesc;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.query.QueryContext;
import org.kie.internal.runtime.manager.context.EmptyContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.verizon.sp.kie.et.model.VerizonTask;

public class VerizonTaskInstanceTreeServiceTest extends AbstractExecutionTreeTest {
	private static final Logger logger = LoggerFactory.getLogger(VerizonTaskInstanceTreeServiceTest.class);

	@Before
	public void setKSessionForDiagrams() {
		vzPitResource.setKieSession(deploymentService.getDeployedUnit(deploymentUnit.getIdentifier())
				.getRuntimeManager().getRuntimeEngine(EmptyContext.get()).getKieSession());
	}
	
	@Test
	public void testCompletedChildlessProcessInstance() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", false);
		params.put("runC", false);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Task", activeNodes.iterator().next().getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertEquals(2, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals("The Parent Second Task", verizonTaskList.get(1).getTaskName());
		assertEquals("completed", verizonTaskList.get(0).getTaskStatus());
		assertEquals("not completed", verizonTaskList.get(1).getTaskStatus());

		// The Parent Second Task
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Second Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert process completed
		pi = processService.getProcessInstance(processInstanceId);
		assertNull(pi);

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertEquals(2, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals("The Parent Second Task", verizonTaskList.get(1).getTaskName());
		assertEquals("completed", verizonTaskList.get(0).getTaskStatus());
		assertEquals("completed", verizonTaskList.get(1).getTaskStatus());

	}

	@Test
	public void testCompletedProcessWithWorkItem() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Object> params = new HashMap<String, Object>();
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"test-project.receive-task-with-external-call", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("Test Work Item Handler", activeNode.getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		logger.debug("Task type for Script Task Node: {}", verizonTaskList.get(0).getTaskType());
		assertEquals("Test Work Item Handler", verizonTaskList.get(0).getTaskName());
		processService.completeWorkItem(activeNode.getWorkItemId(), new HashMap<String, Object>());

		pi = processService.getProcessInstance(processInstanceId);
		assertNull(pi);

		ProcessInstanceDesc pid = runtimeDataService.getProcessInstanceById(processInstanceId);
		assertNotNull(pid);
		assertTrue(pid.getState() == ProcessInstance.STATE_COMPLETED);

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		logger.debug("Verizon task list: {}", verizonTaskList);
		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		logger.debug("Task type for Script Task Node: {}", verizonTaskList.get(0).getTaskType());
		assertEquals("Test Work Item Handler", verizonTaskList.get(0).getTaskName());
	}

	@Test
	public void testFilterNoControlNodes() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("callableActivity", "sub-processes-kjar.base-process");

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"test-resources.all-activities", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("Decision Task", activeNode.getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(2, verizonTaskList.size());
		logger.debug("Task type for Script Task Node: {}", verizonTaskList.get(0).getTaskType());
		assertEquals("Task", verizonTaskList.get(0).getTaskName());
		logger.debug("Task type for Service Task Node: {}", verizonTaskList.get(1).getTaskType());
		assertEquals("Decision Task", verizonTaskList.get(1).getTaskName());

		processService.completeWorkItem(activeNode.getWorkItemId(), new HashMap<String, Object>());

		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		activeNode = activeNodes.iterator().next();
		assertEquals("Timer 5s", activeNode.getName());
		logger.debug("Current active node type {}", activeNode.getNodeType());

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(3, verizonTaskList.size());
		logger.debug("Task type for Script Task Node: {}", verizonTaskList.get(0).getTaskType());
		assertEquals("Task", verizonTaskList.get(0).getTaskName());
		logger.debug("Task type for Service Task Node: {}", verizonTaskList.get(1).getTaskType());
		assertEquals("Decision Task", verizonTaskList.get(1).getTaskName());
		logger.debug("Task type for Timer Node: {}", verizonTaskList.get(2).getTaskType());
		assertEquals("Timer 5s", verizonTaskList.get(2).getTaskName());

		try {
			logger.debug("Waiting 5 seconds to continue");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			logger.error("Unable to wait", e);
		}

		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		activeNode = activeNodes.iterator().next();
		assertEquals("Human Task", activeNode.getName());
		logger.debug("Current active node type {}", activeNode.getNodeType());

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertNotNull(verizonTaskList);
		assertEquals(4, verizonTaskList.size());
		assertEquals("Task", verizonTaskList.get(0).getTaskName());

		Map<String, Object> htParams = new HashMap<String, Object>();

		// Claim and complete parent task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		assertEquals(6, verizonTaskList.size());

		processService.signalProcessInstance(processInstanceId, "complete_process", null);
		assertEquals(6, verizonTaskList.size());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testFilterAllNodes() throws JsonParseException, JsonMappingException, IOException {
		List<String> ALL_NODES = new ArrayList<>(NO_CONTROL_NODES);
		ALL_NODES.add("StartNode");
		ALL_NODES.add("EndNode");
		ALL_NODES.add("Split");

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("callableActivity", "sub-processes-kjar.base-process");

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"test-resources.all-activities", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("Decision Task", activeNode.getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				ALL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(3, verizonTaskList.size());
		logger.debug("Task type for Start Node: {}", verizonTaskList.get(0).getTaskType());
		assertEquals("StartNode", verizonTaskList.get(0).getTaskType());
		logger.debug("Task type for Script Task Node: {}", verizonTaskList.get(1).getTaskType());
		assertEquals("Task", verizonTaskList.get(1).getTaskName());
		logger.debug("Task type for Service Task Node: {}", verizonTaskList.get(2).getTaskType());
		assertEquals("Decision Task", verizonTaskList.get(2).getTaskName());
		assertEquals("TestWorkItemHandler", verizonTaskList.get(2).getTaskType());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testFilterHumanTasksOnly() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("callableActivity", "sub-processes-kjar.base-process");

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"test-resources.all-activities", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("Decision Task", activeNode.getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				Arrays.asList("HumanTaskNode"));
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(0, verizonTaskList.size());
		processService.completeWorkItem(activeNode.getWorkItemId(), new HashMap<String, Object>());

		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		activeNode = activeNodes.iterator().next();
		assertEquals("Timer 5s", activeNode.getName());
		logger.debug("Current active node type {}", activeNode.getNodeType());

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				Arrays.asList("HumanTaskNode"));
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(0, verizonTaskList.size());
		try {
			logger.debug("Waiting 6 seconds to continue");
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			logger.error("Unable to wait", e);
		}

		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		activeNode = activeNodes.iterator().next();
		assertEquals("Human Task", activeNode.getName());
		logger.debug("Current active node type {}", activeNode.getNodeType());

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				Arrays.asList("HumanTaskNode"));
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Received response using Human Task: {}", verizonTaskResponse.getEntity().toString());

		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		assertEquals("Human Task", verizonTaskList.get(0).getTaskName());

		Map<String, Object> htParams = new HashMap<String, Object>();

		// Claim and complete parent task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				Arrays.asList("HumanTaskNode"));
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertEquals(1, verizonTaskList.size());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testFilterNotGivenRetunsNoControlNodes() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("callableActivity", "sub-processes-kjar.base-process");

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"test-resources.all-activities", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("Decision Task", activeNode.getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, null);
		assertEquals(200, verizonTaskResponse.getStatus());
		logger.debug("RESPONSE: {}", verizonTaskResponse.getEntity());

		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(2, verizonTaskList.size());
		logger.debug("Task type for Script Task Node: {}", verizonTaskList.get(0).getTaskType());
		assertEquals("Task", verizonTaskList.get(0).getTaskName());
		logger.debug("Task type for Service Task Node: {}", verizonTaskList.get(1).getTaskType());
		assertEquals("Decision Task", verizonTaskList.get(1).getTaskName());

		processService.completeWorkItem(activeNode.getWorkItemId(), new HashMap<String, Object>());

		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		activeNode = activeNodes.iterator().next();
		assertEquals("Timer 5s", activeNode.getName());
		logger.debug("Current active node type {}", activeNode.getNodeType());

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, null);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		logger.debug("Verizon task list: {}", verizonTaskList);

		assertNotNull(verizonTaskList);
		assertEquals(3, verizonTaskList.size());
		logger.debug("Task type for Script Task Node: {}", verizonTaskList.get(0).getTaskType());
		assertEquals("Task", verizonTaskList.get(0).getTaskName());
		logger.debug("Task type for Service Task Node: {}", verizonTaskList.get(1).getTaskType());
		assertEquals("Decision Task", verizonTaskList.get(1).getTaskName());
		logger.debug("Task type for Timer Node: {}", verizonTaskList.get(2).getTaskType());
		assertEquals("Timer 5s", verizonTaskList.get(2).getTaskName());

		processService.abortProcessInstance(processInstanceId);
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void testLevelWith1SubProcess() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", false);
		params.put("runC", true);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);
		assertEquals(true, processService.getProcessInstanceVariable(processInstanceId, "runC"));

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("The Parent Task", activeNode.getName());
		Long workItemId = activeNode.getWorkItemId();

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals(processInstanceId, verizonTaskList.get(0).getParentContainerId());
		assertEquals(workItemId, verizonTaskList.get(0).getSourceObjectId());

		Map<String, Object> htParams = new HashMap<String, Object>();
		htParams.put("oTaskParent", "Example output value");
		htParams.put("htRunA", false);
		htParams.put("htRunB", false);
		htParams.put("htRunC", true);

		// Claim and complete parent task

		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		assertEquals(2, verizonTaskList.size());

		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals("completed", verizonTaskList.get(0).getTaskStatus());

		assertEquals("not completed", verizonTaskList.get(1).getTaskStatus());
		assertEquals("spC", verizonTaskList.get(1).getTaskName());
		assertEquals(processInstanceId, verizonTaskList.get(1).getRootContainerId());

		// Assert SubProcess spC is active
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("spC", activeNodes.iterator().next().getName());
		assertEquals("SubProcessNode", activeNodes.iterator().next().getNodeType());

		Long spcId = runtimeDataService
				.getProcessInstancesByParent(processInstanceId,
						Arrays.asList(ProcessInstance.STATE_ACTIVE, ProcessInstance.STATE_PENDING), new QueryContext())
				.iterator().next().getId();
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(spcId, new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Single Exclusive Task", activeNodes.iterator().next().getName());

		assertNotNull(verizonTaskList);
		assertNotNull(verizonTaskList.get(1));
		assertNotNull(verizonTaskList.get(1).getSubWorkFlow());
		logger.debug("Current verizon task list: {}", verizonTaskList);
		logger.debug("Verizon task received from response: {}", verizonTaskResponse.getEntity().toString());
		List complexTaskListObject = marshaller.unmarshal((String) verizonTaskResponse.getEntity(), "application/json",
				List.class);

		Map complexSubProcessNode = (Map) complexTaskListObject.get(1);
		logger.debug("Sub process node type {}", complexSubProcessNode.get("taskType"));
		logger.debug("Sub process child count {}", ((List) complexSubProcessNode.get("subWorkFlow")).size());
		assertFalse(((List) complexSubProcessNode.get("subWorkFlow")).size() == 0);
		assertNotNull(((List) complexSubProcessNode.get("subWorkFlow")).get(0));

		Map complexExclusiveTaskNode = (Map) ((List) complexSubProcessNode.get("subWorkFlow")).get(0);
		assertEquals("Single Exclusive Task", complexExclusiveTaskNode.get("taskName"));
		assertEquals(processInstanceId, Long.valueOf((Integer) complexExclusiveTaskNode.get("rootContainerId")));
		assertEquals("single-exclusive", complexExclusiveTaskNode.get("parentName"));
		assertEquals(spcId, Long.valueOf((Integer) complexExclusiveTaskNode.get("parentContainerId")));

		// CLEANUP
		processService.abortProcessInstance(processInstanceId);
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void testLevelWith2SubProcesses() throws JsonParseException, JsonMappingException, IOException {
		vzPitResource.setKieSession(deploymentService.getDeployedUnit(deploymentUnit.getIdentifier())
				.getRuntimeManager().getRuntimeEngine(EmptyContext.get()).getKieSession());
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", true);
		params.put("runC", true);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);
		assertEquals(true, processService.getProcessInstanceVariable(processInstanceId, "runC"));

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("The Parent Task", activeNodes.iterator().next().getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());

		Map<String, Object> htParams = new HashMap<String, Object>();
		htParams.put("oTaskParent", "Example output value");
		htParams.put("htRunA", false);
		htParams.put("htRunB", true);
		htParams.put("htRunC", true);

		// Claim and complete parent task

		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", htParams);

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());

		logger.debug("Verizon task list {}", verizonTaskResponse.getEntity());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		assertEquals(3, verizonTaskList.size());

		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals("completed", verizonTaskList.get(0).getTaskStatus());

		assertEquals("not completed", verizonTaskList.get(1).getTaskStatus());
		assertEquals("spC", verizonTaskList.get(1).getTaskName());
		Long spCId = verizonTaskList.get(1).getSourceObjectId();
		assertEquals(processInstanceId, verizonTaskList.get(1).getRootContainerId());

		assertEquals("not completed", verizonTaskList.get(2).getTaskStatus());
		assertEquals("spB", verizonTaskList.get(2).getTaskName());
		assertEquals(processInstanceId, verizonTaskList.get(2).getRootContainerId());

		// Assert SubProcess spC is active
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(2, activeNodes.size());
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(verizonTaskList.get(1).getSourceObjectId(),
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Single Exclusive Task", activeNodes.iterator().next().getName());

		assertNotNull(verizonTaskList);
		assertNotNull(verizonTaskList.get(1));
		assertNotNull(verizonTaskList.get(1).getSubWorkFlow());
		logger.debug("Current verizon task list: {}", verizonTaskList);
		logger.debug("Verizon task received from response: {}", verizonTaskResponse.getEntity().toString());
		List complexTaskListObject = marshaller.unmarshal((String) verizonTaskResponse.getEntity(), "application/json",
				List.class);

		Map complexSubProcessNode = (Map) complexTaskListObject.get(1);
		logger.debug("Sub process node type {}", complexSubProcessNode.get("taskType"));
		logger.debug("Sub process child count {}", ((List) complexSubProcessNode.get("subWorkFlow")).size());
		assertFalse(((List) complexSubProcessNode.get("subWorkFlow")).size() == 0);
		assertNotNull(((List) complexSubProcessNode.get("subWorkFlow")).get(0));

		Map complexExclusiveTaskNode = (Map) ((List) complexSubProcessNode.get("subWorkFlow")).get(0);
		assertEquals("Single Exclusive Task", complexExclusiveTaskNode.get("taskName"));
		assertEquals(processInstanceId, Long.valueOf((Integer) complexExclusiveTaskNode.get("rootContainerId")));
		assertEquals("single-exclusive", complexExclusiveTaskNode.get("parentName"));
		assertEquals(spCId, Long.valueOf((Integer) complexExclusiveTaskNode.get("parentContainerId")));

		// CLEANUP
		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testFailingWorkItem() throws JsonParseException, JsonMappingException, IOException {

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("iParent", "Example input value");
		params.put("runA", false);
		params.put("runB", false);
		params.put("runC", false);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				"sub-processes-kjar.the-parent", params);
		assertNotNull(processInstanceId);

		ProcessInstance pi = processService.getProcessInstance(processInstanceId);
		assertNotNull(pi);

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("The Parent Task", activeNode.getName());

		Response verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId,
				NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		List<VerizonTask> verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals("not completed", verizonTaskList.get(0).getTaskStatus());

		// Assert that after setting _failed_wis, the status of the work item is
		// "failing"
		processService.setProcessVariable(processInstanceId, "_failed_wis", activeNode.getWorkItemId());
		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});
		assertNotNull(verizonTaskList);
		assertEquals(1, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals("failing", verizonTaskList.get(0).getTaskStatus());

		// Assert that after completing the work item, the status is changed to
		// "completed", even if task still reported in _failed_wis
		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		verizonTaskResponse = vzPitResource.getProcessInstanceTree(testHeaders(), processInstanceId, NO_CONTROL_NODES);
		assertEquals(200, verizonTaskResponse.getStatus());
		verizonTaskList = mapper.readValue(verizonTaskResponse.getEntity().toString(),
				new TypeReference<List<VerizonTask>>() {
				});

		assertEquals(2, verizonTaskList.size());
		assertEquals("The Parent Task", verizonTaskList.get(0).getTaskName());
		assertEquals("The Parent Second Task", verizonTaskList.get(1).getTaskName());
		assertEquals("completed", verizonTaskList.get(0).getTaskStatus());
		assertEquals("not completed", verizonTaskList.get(1).getTaskStatus());

		// Cleanup
		processService.abortProcessInstance(processInstanceId);
	}

	protected HttpHeaders testHeaders() {
		return new HttpHeaders() {

			@Override
			public MultivaluedMap<String, String> getRequestHeaders() {
				MultivaluedMap<String, String> headers = new MultivaluedHashMap<String, String>();
				headers.add("Accept", "application/json");
				return headers;
			}

			@Override
			public List<String> getRequestHeader(String name) {
				return null;
			}

			@Override
			public MediaType getMediaType() {
				return new MediaType();
			}

			@Override
			public int getLength() {
				return 0;
			}

			@Override
			public Locale getLanguage() {
				return null;
			}

			@Override
			public String getHeaderString(String name) {
				return null;
			}

			@Override
			public Date getDate() {
				return null;
			}

			@Override
			public Map<String, Cookie> getCookies() {
				return null;
			}

			@Override
			public List<MediaType> getAcceptableMediaTypes() {
				return Arrays.asList(new MediaType());
			}

			@Override
			public List<Locale> getAcceptableLanguages() {
				return null;
			}
		};
	}
}