package com.jbpm.services;

import java.util.HashSet;
import java.util.Set;

import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jbpm.beans.Model;

public class BPMRuntimeFactory {

	private static final Logger logger = LoggerFactory.getLogger(BPMRuntimeFactory.class);

	private static KieServicesConfiguration kieConfig;

	private BPMRuntimeFactory() {

	}

	public static KieServicesConfiguration getKieConfig(String serverURL, String userName, String password) {
		try {
			if (null == kieConfig) {
				kieConfig = KieServicesFactory.newRestConfiguration(serverURL, userName, password);
				kieConfig.setMarshallingFormat(MarshallingFormat.JAXB);
				kieConfig.setTimeout(3000L); // optional
				Set<Class<?>> allClasses = new HashSet<Class<?>>();
				allClasses.add(Model.class);
				kieConfig.addExtraClasses(allClasses);

				logger.debug("[getKieConfig]--> Runtime Engine initialised!");
			}
		} catch (Exception e) {
			logger.debug("[getKieConfig][Exception]", e);
		}
		return kieConfig;
	}

}