package com.verizon.sp.kie.et;

import java.util.Arrays;
import java.util.List;

import org.jbpm.services.api.model.DeploymentUnit;
import org.jbpm.test.services.AbstractKieServicesTest;
import org.kie.internal.runtime.conf.NamedObjectModel;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.KieServerRegistryImpl;
import org.kie.server.services.impl.marshal.MarshallerHelper;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public abstract class AbstractExecutionTreeTest extends AbstractKieServicesTest {
	protected static final String GROUP_ID = "org.acme.kie";
	protected static final String ARTIFACT_ID = "test-module";
	protected static final String VERSION = "1.0.0";
	protected static final List<String> NO_CONTROL_NODES = Arrays.asList("SubProcessNode", "HumanTaskNode",
			"WorkItemNode", "ActionNode", "TimerNode", "EventNode", "ExternalCallerNode", "ReceiveTaskNode");

	protected ProcessInstanceTreeResource pitResource;
	protected VerizonTaskInstanceTreeResource vzPitResource;
	protected MarshallerHelper marshaller;
	protected ObjectMapper mapper = new ObjectMapper();

	@Override
	protected void configureServices() {
		super.configureServices();
		KieServerRegistry context = new KieServerRegistryImpl();
		marshaller = new MarshallerHelper(context);
		vzPitResource = new VerizonTaskInstanceTreeResource(runtimeDataService, context);
		pitResource = new ProcessInstanceTreeResource(runtimeDataService, context);
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	}

	@Override
	protected List<String> getProcessDefinitionFiles() {
		return Arrays.asList("base-process.bpmn", "single-exclusive.bpmn", "processA.bpmn", "the-parent.bpmn",
				"all-activities.bpmn", "receive-task-with-external-call.bpmn", "external-caller.bpmn", "sampleprocess.bpmn");
	}

	@Override
	protected DeploymentUnit prepareDeploymentUnit() throws Exception {
		return createAndDeployUnit(GROUP_ID, ARTIFACT_ID, VERSION);
	}

	@Override
	protected boolean createDescriptor() {
		return true;
	}

	@Override
	protected List<NamedObjectModel> getWorkItemHandlers() {
		List<NamedObjectModel> wiHandlers = super.getWorkItemHandlers();
		wiHandlers.add(new NamedObjectModel("mvel", "TestWorkItemHandler",
				"new com.verizon.sp.kie.et.test.IncompleteWorkItemHandler()"));
		wiHandlers.add(new NamedObjectModel("mvel", "ExternalCaller",
				"new com.verizon.sp.kie.et.test.ExternalCallerWorkItemHandler()"));
		wiHandlers.add(new NamedObjectModel("mvel", "ReceiveMessageCaller",
				"new com.verizon.sp.kie.et.test.ReceiveCallerWorkItemHandler()"));
		return wiHandlers;
	}
}
