/**
 * 
 */
package com.verizon.sp.kie.et;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.ws.rs.core.Response;

import org.jbpm.ruleflow.core.RuleFlowProcess;
import org.jbpm.services.api.DeploymentNotFoundException;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.ProcessInstanceDesc;
import org.jbpm.services.api.model.UserTaskInstanceDesc;
import org.jbpm.services.api.model.VariableDesc;
import org.jbpm.workflow.core.node.WorkItemNode;
import org.kie.api.definition.process.Node;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.query.QueryContext;
import org.kie.server.api.model.instance.TaskSummaryList;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.sp.kie.et.model.NodeInstanceTree;
import com.verizon.sp.kie.et.model.ProcessInstanceTree;

/**
 * @author tordi7z
 *
 */
public abstract class AbstractExecutionTree {
	private static final Logger logger = LoggerFactory.getLogger(AbstractExecutionTree.class);
	// Defined control nodes
	protected static final List<String> controlNodes = Arrays.asList("StartNode", "EndNode", "Split");

	protected KieServerRegistry context;
	protected RuntimeDataService dataService;
	protected MarshallerHelper marshallerHelper;
	protected KieSession ksession;

	public void setMarshallerHelper(MarshallerHelper marshallerHelper) {
		this.marshallerHelper = marshallerHelper;
	}

	/**
	 * Returns process instance tree
	 *
	 * @param processInstanceId
	 *            Base process instance to be fetched
	 * @param includeControlNodes
	 *            Optional flag to include control nodes, defaults to false
	 * @return {@link ProcessInstanceTree} process instance tree
	 */
	public ProcessInstanceTree getProcessInstanceTree(Long processInstanceId, boolean includeControlNodes) {
		logger.debug("requested process instance tree for " + processInstanceId);
		ProcessInstanceDesc _rootPi = findRootProcessInstance(processInstanceId);
		return convertToProcessInstanceTree(_rootPi, includeControlNodes);
	}

	/**
	 * Bubbles up to find and return the root process instance of inquired base
	 * process instance
	 *
	 * @param processInstanceId
	 *            Base process instance to be fetched
	 * @return {@link ProcessInstanceDesc} root process instance of base process
	 *         instance
	 * @throws DeploymentNotFoundException
	 */
	private ProcessInstanceDesc findRootProcessInstance(Long processInstanceId) throws DeploymentNotFoundException {
		logger.debug("Find the Root Process Instance for {}", processInstanceId);
		ProcessInstanceDesc _pid = dataService.getProcessInstanceById(processInstanceId);
		if (_pid.getParentId() == -1) {
			logger.debug("Found the Root Process Instance {}", processInstanceId);
			return _pid;
		} else {
			logger.debug("Found a Parent Process Instance {}", _pid.getParentId());
			return findRootProcessInstance(_pid.getParentId());
		}
	}

	/**
	 * Trigger search for root process and marshal process instance tree
	 *
	 * @param processInstanceId
	 *            Identifier of the base process instance to be fetched
	 * @param marshallingType
	 * @param includeNodes
	 *            Optional flag to include control nodes, defaults to false
	 * @return {@link Response} with process instance execution tree JSON format
	 *         structure
	 */
	protected String pitByPid(Long processInstanceId, String marshallingType, boolean includeNodes) {
		ProcessInstanceTree _pit = getProcessInstanceTree(processInstanceId, includeNodes);

		// Marshal the process instance tree
		logger.debug("About to marshal process instance tree with id '{}' {}", processInstanceId, _pit);
		String response = marshallerHelper.marshal(marshallingType, _pit);
		return response;
	}

	/**
	 * Uses the root process instance to generate process instance tree
	 *
	 * @param pi
	 *            Root process instance of base process instance
	 * @param includeControlNodes
	 *            Optional flag to include control nodes, defaults to false
	 * @return {@link ProcessInstanceTree} process instance tree
	 */
	private ProcessInstanceTree convertToProcessInstanceTree(ProcessInstanceDesc pi, boolean includeControlNodes) {
		logger.debug("Converting process instance to process instance tree {}", pi);
		if (pi == null) {
			return null;
		}

		ProcessInstanceTree instance = new ProcessInstanceTree();
		instance.setId(pi.getId());
		instance.setProcessId(pi.getProcessId());
		instance.setProcessName(pi.getProcessName());
		instance.setProcessVersion(pi.getProcessVersion());
		instance.setContainerId(pi.getDeploymentId());
		instance.setProcessInstanceDescription(pi.getProcessInstanceDescription());
		instance.setCorrelationKey(pi.getCorrelationKey());
		instance.setParentId(pi.getParentId());
		instance.setDate(pi.getDataTimeStamp());
		instance.setInitiator(pi.getInitiator());
		instance.setState(pi.getState());
		instance.setSlaCompliance(pi.getSlaCompliance());
		instance.setSlaDueDate(pi.getSlaDueDate());

		setActiveTasks(pi, instance);
		buildChildNodes(pi, instance, includeControlNodes);

		return instance;
	}

	/**
	 * Recursivity in this method dives to the deeper child process instance.
	 * 
	 * @param pi
	 *            Root process instance of process instance request process
	 *            instance id
	 * @param instance
	 *            Process instance execution tree
	 * @param includeControlNodes
	 *            Optional flag to include control nodes, defaults to false
	 */
	private void buildChildNodes(ProcessInstanceDesc pi, ProcessInstanceTree instance, boolean includeControlNodes) {
		
		RuleFlowProcess process;
		if (context != null && context.getContainers() != null && context.getContainers().size() > 0
				&& context.getContainers().get(0) != null) {
			KieSession _ksession = context.getContainers().get(0).getKieContainer().getKieSession();
			process = (RuleFlowProcess) _ksession.getKieBase().getProcess(instance.getProcessId());
		} else {
				logger.debug("Retrieving node information for instance {}", instance);
				process = (RuleFlowProcess) ksession.getKieBase().getProcess(instance.getProcessId());
		}
		
		Collection<VariableDesc> variables = dataService.getVariablesCurrentState(instance.getId());
		VariableDesc vHiddenNodes = variables.stream().filter(v -> "hiddenNodes".equals(v.getVariableId())).findAny()
				.orElse(null);
		String hiddenNodes = null;
		if (vHiddenNodes != null) {
			hiddenNodes = vHiddenNodes.getNewValue();
		}

		
		VariableDesc vFailedWis = variables.stream().filter(v -> "_failed_wis".equals(v.getVariableId())).findAny()
				.orElse(null);
		String failedWis = null;
		logger.debug("failedWis: {}", vFailedWis);
		if (vFailedWis != null) {
			failedWis = vFailedWis.getNewValue();
		}

		// Retrieve nodes
		Collection<NodeInstanceDesc> nodesHistory;
		int historyOffset = 0;
		List<NodeInstanceTree> nodesList = new ArrayList<>();
		do {
			nodesHistory = dataService.getProcessInstanceFullHistory(instance.getId(),
					new QueryContext(historyOffset, historyOffset + 1000, "log_date", true));
			historyOffset += 1000;

			// The array list is sortable collection
			for (NodeInstanceDesc processNode : nodesHistory) {
				// Don't include the node if it is in the hidden nodes list
				// (csv)
				if (hiddenNodes != null && hiddenNodes.trim().length() > 0
						&& Arrays.asList(hiddenNodes.split(",")).contains(processNode.getName())) {
					continue;
				}

				// Don't include the node if it is a control node and filter is
				// requested
				if (!includeControlNodes && controlNodes.contains(processNode.getNodeType())) {
					continue;
				}

				// Update completed nodes while excluding duplicates (History
				// contains duplicates)
				if (nodesList.stream().anyMatch(n -> processNode.getNodeId().equals(n.getNodeId()))) {
					if (processNode.isCompleted()) {
						int index = nodesList.indexOf(nodesList.stream()
								.filter(n -> n.getNodeId().equals(processNode.getNodeId())).findFirst().get());
						nodesList.get(index).setNodeEndTime(processNode.getDataTimeStamp());
						nodesList.get(index).setCompleted(processNode.isCompleted());
					}
					continue;
				}
				logger.debug("including node type: " + processNode.getNodeType());

				NodeInstanceTree _nit = null;
				if ("SubProcessNode".equals(processNode.getNodeType())) {
					ProcessInstanceDesc _pid = dataService.getProcessInstanceById(processNode.getReferenceId());
					// Define that node type is sub-process and retrieve its
					// details (recursively)
					_nit = nodeDescToNodeInstanceTree(processNode,
							convertToProcessInstanceTree(_pid, includeControlNodes), failedWis, process);
				} else {
					_nit = nodeDescToNodeInstanceTree(processNode, null, failedWis, process);
				}
				
				//
				nodesList.add(_nit);
			}
		} while (nodesHistory.size() != 0);

		// Sort node collection by id
		NodeInstanceTree[] nodeInstanceArr = new NodeInstanceTree[nodesList.size()];

		Comparator<NodeInstanceTree> compareById = ((NodeInstanceTree o1, NodeInstanceTree o2) -> o1.getId()
				.compareTo(o2.getId()));
		Collections.sort(nodesList, compareById);

		nodesList.toArray(nodeInstanceArr);
		instance.setProcessNodes(nodeInstanceArr);
	}

	/**
	 * Returns the details Node instance tree for the process instance tree
	 *
	 * @param nid
	 *            Node instance tree
	 * @param pit
	 *            Process instance tree
	 * @return {@link NodeInstanceTree} Node instance tree
	 */
	private NodeInstanceTree nodeDescToNodeInstanceTree(NodeInstanceDesc nid, ProcessInstanceTree pit,
			String failedWis, RuleFlowProcess process) {
		
		String nodeType=nid.getNodeType();
		
		// If nodetype is workitemnode then calculate whether it is Receive task/ExternalCaller
		
		nodeType = "WorkItemNode".equals(nid.getNodeType())
				? calculateWorkItemNodeName(process, nid.getNodeId())
				: nid.getNodeType();
				
		NodeInstanceTree result = new NodeInstanceTree(nid.getId().toString(), nid.getNodeId(), nid.getName(),
				nodeType, nid.getDeploymentId(), nid.getProcessInstanceId(), nid.getDataTimeStamp(),
				nid.getConnection(), nid.isCompleted() ? 1 : 0, nid.getWorkItemId(), nid.getReferenceId(),
				nid.getNodeContainerId(), nid.getSlaDueDate(), nid.getSlaCompliance());
		result.setFailed(failedWis != null && failedWis.trim().length() > 0
				&& Arrays.asList(failedWis.split(",")).contains(String.valueOf(nid.getWorkItemId())));

		result.setCompleted(nid.isCompleted());
		result.setProcessInstanceTree(pit);
		result.setSlaDueDate(nid.getSlaDueDate());
		result.setNodeStartTime(nid.getDataTimeStamp());
		return result;
	}

	/**
	 * Populates details regarding the active tasks part of the process instance
	 * tree
	 *
	 * @param pi
	 *            Root process instance of process instance request process
	 *            instance id
	 * @param instance
	 *            Process instance tree
	 */
	private void setActiveTasks(ProcessInstanceDesc pi, ProcessInstanceTree instance) {
		if (pi.getActiveTasks() != null && !pi.getActiveTasks().isEmpty()) {
			org.kie.server.api.model.instance.TaskSummary[] tasks = new org.kie.server.api.model.instance.TaskSummary[pi
					.getActiveTasks().size()];
			int counter = 0;
			for (UserTaskInstanceDesc taskSummary : pi.getActiveTasks()) {
				org.kie.server.api.model.instance.TaskSummary task = org.kie.server.api.model.instance.TaskSummary
						.builder().id(taskSummary.getTaskId()).name(taskSummary.getName())
						.description(taskSummary.getDescription()).activationTime(taskSummary.getActivationTime())
						.actualOwner(taskSummary.getActualOwner()).containerId(taskSummary.getDeploymentId())
						.createdBy(taskSummary.getCreatedBy()).createdOn(taskSummary.getCreatedOn())
						.priority(taskSummary.getPriority()).processId(taskSummary.getProcessId())
						.processInstanceId(taskSummary.getProcessInstanceId()).status(taskSummary.getStatus()).build();
				tasks[counter] = task;
				counter++;
			}
			instance.setActiveUserTasks(new TaskSummaryList(tasks));
		}
	}
	
	private String calculateWorkItemNodeName(RuleFlowProcess process, String nodeId) {
		logger.debug("Looking for node id {}", nodeId);
		for (Node node : process.getNodes()) {
			if (nodeId.equals(node.getMetaData().get("UniqueId"))) {
				WorkItemNode win = (WorkItemNode) node;
				return win.getWork().getName().equalsIgnoreCase("ExternalCaller") ? "ExternalCallerNode"
						: (win.getWork().getName().equalsIgnoreCase("ReceiveMessageCaller") ? "ReceiveTaskNode"
								: "WorkItemNode");
			}
		}

		return "WorkItemNode";
	}

}
