package com.verizon.sp.kie;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.jbpm.services.api.model.DeploymentUnit;
import org.jbpm.test.services.AbstractKieServicesTest;
import org.kie.internal.runtime.conf.NamedObjectModel;
import org.kie.server.services.api.KieServerRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class ExternalCallerAbstractTest extends AbstractKieServicesTest {
	protected static Logger logger = LoggerFactory.getLogger(ExternalCallerAbstractTest.class);

	protected static final String ARTIFACT_ID = "test-module";
	protected static final String GROUP_ID = "com.verizon.pam";
	protected static final String VERSION = "1.0.0";

	protected static final String WIH_HT_PROCESS = "test-project.wih-ht-process";
	protected static final String WIH_SIGNAL_PROCESS = "test-project.wih-ht-process-with-signal";
	protected static final String WIH_RECEIVE_TASK_HT_PROCESS_ID = "test-project.receive-task-with-external-call-ht";
	protected static final String WIH_RECEIVE_TASK_HT_PROCESS_NAME = "receive-task-with-external-call-ht";
	protected static final String WIH_RECEIVE_TASK_PROCESS_ID = "test-project.receive-task-with-external-call";
	protected static final String WIH_RECEIVE_TASK_TERMINATE_PROCESS_ID = "test-project.receive-task-with-external-call-terminate";
	protected static final String WIH_RECEIVE_TASK_PROCESS_NAME = "receive-task-with-external-call";
	protected static final String WIH_RECEIVE_TASK_TERMINATE_PROCESS_NAME = "receive-task-with-external-call-terminate";
	protected static final String WIH_BOUNDARY_SIGNAL_PROCESS = "test-resources.boundary-signal-wih";
	protected static final String THROW_ON_EXIT_WIH = "test-resources.throw-on-exit";
	protected static final String WIH_RECEIVE_TASK_HT = "test.receive-task-with-ht";
	protected static final String SIGNAL_NAME = "Error_signal";
	protected static final String SIGNAL_MAP = "SignalMap";
	protected static final String HALT_ON_EXCEPTION = "haltOnException";
	protected static final String HT_PROCESS = "test-project.htprocess";
	protected static final String HT_PROCESS_Test_APIStatuscode = "sample.bpmn";
	protected HumanTaskResource humanTaskResource;
	
	protected KieServerRegistry context;

	protected ReflowExternalCallerResource reflowExternalCallerResource;

	@Override
	protected List<String> getProcessDefinitionFiles() {
		return Arrays.asList("wih-ht-process.bpmn", "wih-ht-process-with-signal.bpmn","receive-task-with-external-call.bpmn", "receive-task-with-external-call-terminate.bpmn", "boundary-signal-wih.bpmn", "throw-on-exit.bpmn", "receive-task-with-ht.bpmn", "htprocess.bpmn", "sampleprocess.bpmn");
	}
	@Override
	protected DeploymentUnit prepareDeploymentUnit() throws Exception {
		return createAndDeployUnit(GROUP_ID, ARTIFACT_ID, VERSION);
	}

	@Override
	protected void configureServices() {
		super.configureServices();
		this.reflowExternalCallerResource = new ReflowExternalCallerResource(processService, runtimeDataService, null);
		this.humanTaskResource=new HumanTaskResource(runtimeDataService,userTaskService);
	}

	@Override
	protected boolean createDescriptor() {
		return true;
	}

	@Override
	protected List<NamedObjectModel> getWorkItemHandlers() {
		List<NamedObjectModel> wiHandlers = super.getWorkItemHandlers();
		wiHandlers.add(new NamedObjectModel("mvel", "TestWorkItemHandler",
				"new com.verizon.sp.kie.test.IncompleteWorkitemHandler()"));
		return wiHandlers;
	}

	/**
	 * After the ASYNC change, response from reflowExternalCallerResource comes
	 * back too fast for these unit test, waiting 1 second for the complete work
	 * item thread to do it's magic before running any assertion
	 * 
	 * @param deploymentUnit
	 * @param processInstanceId
	 * @param workItemId
	 * @param payload
	 */
	protected void completeWorkItemAndWait(String deploymentUnit, String processInstanceId, String workItemId,
			String payload) {
		reflowExternalCallerResource.completeExternalCallerWorkItem(testHeaders(), deploymentUnit, processInstanceId,
				workItemId, payload);
		// After change ASYNC change, response from reflowExternalCallerResource
		// comes back too fast.
		// waiting 1 second for the complete work item thread to complete.
		try {
			logger.debug("Waiting 1 second for the work item to complete");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	protected HttpHeaders testHeaders() {
		return new HttpHeaders() {

			@Override
			public MultivaluedMap<String, String> getRequestHeaders() {
				MultivaluedMap<String, String> headers = new MultivaluedHashMap<String, String>();
				headers.add("Accept", "application/json");
				return headers;
			}

			@Override
			public List<String> getRequestHeader(String name) {
				return null;
			}

			@Override
			public MediaType getMediaType() {
				return new MediaType();
			}

			@Override
			public int getLength() {
				return 0;
			}

			@Override
			public Locale getLanguage() {
				return null;
			}

			@Override
			public String getHeaderString(String name) {
				return null;
			}

			@Override
			public Date getDate() {
				return null;
			}

			@Override
			public Map<String, Cookie> getCookies() {
				return null;
			}

			@Override
			public List<MediaType> getAcceptableMediaTypes() {
				return Arrays.asList(new MediaType());
			}

			@Override
			public List<Locale> getAcceptableLanguages() {
				return null;
			}
		};
	}
}