package com.verizon.sp.kie;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.jbpm.services.api.DefinitionService;
import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.admin.ProcessInstanceAdminService;
import org.kie.server.services.api.KieServerApplicationComponentsService;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.api.SupportedTransports;
import org.kie.server.services.impl.KieServerImpl;
import org.kie.server.services.impl.KieServerLocator;
import org.kie.server.services.jbpm.JbpmKieServerExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jbpm.services.api.UserTaskService;

public class VerizonExtension implements KieServerApplicationComponentsService {

	private static final Logger logger = LoggerFactory.getLogger(VerizonExtension.class);
	private final String OWNER_EXTENSION = JbpmKieServerExtension.EXTENSION_NAME;

	DefinitionService definitionService = null;
	ProcessService processService = null;
	RuntimeDataService runtimeDataService = null;
	ProcessInstanceAdminService adminService = null;
	KieServerRegistry context = null;
	UserTaskService userTaskService=null;

	public Collection<Object> getAppComponents(String extension, SupportedTransports type, Object... services) {

		if (!OWNER_EXTENSION.equals(extension)) {
			return Collections.emptyList();
		}

		logger.info("Loading Verizon KIE Server extension...");
		KieServerImpl server = KieServerLocator.getInstance();

		for (Object object : services) {
			if (DefinitionService.class.isAssignableFrom(object.getClass())) {
				definitionService = (DefinitionService) object;
				continue;
			} else if (ProcessService.class.isAssignableFrom(object.getClass())) {
				processService = (ProcessService) object;
				continue;
			} else if (RuntimeDataService.class.isAssignableFrom(object.getClass())) {
				runtimeDataService = (RuntimeDataService) object;
				continue;
			} else if (ProcessInstanceAdminService.class.isAssignableFrom(object.getClass())) {
				adminService = (ProcessInstanceAdminService) object;
			} else if (KieServerRegistry.class.isAssignableFrom(object.getClass())) {
				context = (KieServerRegistry) object;
				continue;
			}
			  else if (UserTaskService.class.isAssignableFrom(object.getClass())) {
				userTaskService= (UserTaskService) object;
				continue;
			}
		}

		List<Object> components = new ArrayList<Object>(1);
		if (SupportedTransports.REST.equals(type)) {
			logger.debug("Adding Verizon server resource endpoints...");
			components.add(new ServerResource(server));

			logger.debug("Adding Verizon process definition resource endpoints...");
			components.add(new ProcessDefinitionResource(definitionService, context));

			logger.debug("Adding Verizon process resource endpoints...");
			components.add(new ProcessResource(processService, definitionService, runtimeDataService, context));

			logger.debug("Adding Verizon External Caller Workitem Handler resource endpoints...");
			components.add(new ReflowExternalCallerResource(processService, runtimeDataService, context));

			logger.debug("Adding Verizon Receive Task resource endpoints...");
			components.add(new ReceiveTaskResource(processService, runtimeDataService, definitionService, context));

			logger.debug("Adding Verizon Reflow endpoints...");
			components.add(new ReflowResource(processService, runtimeDataService, adminService));
			
			logger.debug("Adding Human Task resource endpoints...");
			components.add(new HumanTaskResource(runtimeDataService, userTaskService));
			
			logger.debug("WorkItem resource endpoints...");
			components.add(new WorkitemResource(processService, runtimeDataService, adminService, context));
		}

		return components;
	}

}