/**
 * 
 */
package com.verizon.sp.kie;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.ProcessInstanceDesc;
import org.jbpm.services.api.model.VariableDesc;
import org.junit.Test;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.query.QueryContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author tordi7z
 *
 */
public class ReflowExternalCallerTest extends ExternalCallerAbstractTest {

	@Test
	public void testWorkItemCompleted() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_HT_PROCESS);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "{}");

		// This asserts that the state of the current process is in the human
		// task
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testHumanTaskKeepsStatus() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_HT_PROCESS);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "{}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		// Complete work item comes in for the Human task
		String htNodeInstanceId = String.valueOf(activeNodes.iterator().next().getWorkItemId());
		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), htNodeInstanceId,
				"{}");

		// Assert the human task is not completed
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert process instance is completed
		ProcessInstanceDesc pid = runtimeDataService.getProcessInstanceById(processInstanceId);
		// ProcessInstance.STATE_COMPLETED pid.getState();
		assertTrue(pid.getState() == ProcessInstance.STATE_COMPLETED);
	}

	@Test
	public void testWorkItemHaltedOnException() {
		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_HT_PROCESS, params);
		assertNotNull(processInstanceId);
		String failedWis = (String) processService.getProcessInstanceVariable(processInstanceId, "_failed_wis");
		assertNull(failedWis);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "{}");

		// Assert node was not completed
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc activeNode = activeNodes.iterator().next();
		assertEquals("Test Work Item Handler", activeNode.getName());
		
		failedWis = (String) processService.getProcessInstanceVariable(processInstanceId, "_failed_wis");
		assertNotNull(failedWis);
		assertEquals(String.valueOf(activeNode.getWorkItemId()), failedWis);

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemUnMarshalException() {
		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("default", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "Test");

		// Assert that the process variable "result" has value as "Test"
		Map<String, Object> variables = processService.getProcessInstanceVariables(processInstanceId);

		assertEquals("Test", variables.get("result"));

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemSignalDataHasWorkitemId() {

		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("500", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"500\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);

		/*
		 * Assert for two active instances 1. Workitem handler node 2. HumanTask Error
		 * handler node
		 */
		assertEquals(2, activeNodes.size());

		// Assert "workItemId" process variable to have value as "1"

		Map<String, Object> variables = processService.getProcessInstanceVariables(processInstanceId);

		assertEquals(1L, variables.get("WorkitemId"));

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemDefaultSignal() {
		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("default", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"500\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		/*
		 * Assert for two active instances 1. Workitem handler node 2. HumanTask Error
		 * handler node
		 */
		assertEquals(2, activeNodes.size());
		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemForErrorResponse() {

		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("500", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"version\":\"1.1.4\",\"restResult\":\"\",\"result\":\"Message-Error occured during service call\",\"restResponseCode\":\"500\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);

		/*
		 * Assert for two active instances 1. Workitem handler node 2. HumanTask Error
		 * handler node
		 */
		assertEquals(2, activeNodes.size());

		// Assert "restResult" process variable to have value as error message
		Map<String, Object> variables = processService.getProcessInstanceVariables(processInstanceId);

		assertEquals("Message-Error occured during service call", variables.get("restResult"));
		//TODO: Response code assertion

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemForXMLResponse() {

		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("500", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"version\":\"1.1.4\",\"restResult\":\"\",\"result\":\"<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\" standalone=\\\"yes\\\"?><CommonResponse><code>0</code><message>SUCCESS</message><parentCaseId>886681</parentCaseId></CommonResponse>\",\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);

		// Assert for one active node instance : Workitemhandler
		assertEquals(1, activeNodes.size());

		// Assert "restResult" process variable to have value as xml message
		Map<String, Object> variables = processService.getProcessInstanceVariables(processInstanceId);

		assertEquals(
				"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><CommonResponse><code>0</code><message>SUCCESS</message><parentCaseId>886681</parentCaseId></CommonResponse>",
				variables.get("restResult"));
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemForJSONResponse() throws JsonProcessingException {

		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("500", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"version\":\"1.1.4\",\"restResult\":{\"statusCode\":\"1\",\"statusDesc\":\"Target EndPoint is not configured for ProcessName and StepName\",\"errorCode\":\"DATA_NOT_FOUND\"},\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);

		// Assert for one active node instance : Workitemhandler
		assertEquals(1, activeNodes.size());

		// Assert "restResult" process variable to have value as xml message
		Map<String, Object> variables = processService.getProcessInstanceVariables(processInstanceId);

		ObjectMapper objectMapper = new ObjectMapper();
		String jsonResponse = objectMapper.writeValueAsString(variables.get("restResult"));
		assertEquals(
				"{\"statusCode\":\"1\",\"statusDesc\":\"Target EndPoint is not configured for ProcessName and StepName\",\"errorCode\":\"DATA_NOT_FOUND\"}",
				jsonResponse);
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemForEmptyResponse() throws JsonProcessingException {

		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("500", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"version\":\"1.1.4\",\"restResult\":\"\",\"result\":\"\",\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);

		// Assert for one active node instance : Workitemhandler
		assertEquals(1, activeNodes.size());

		// Assert "restResult" process variable to have value as xml message
		Map<String, Object> variables = processService.getProcessInstanceVariables(processInstanceId);

		ObjectMapper objectMapper = new ObjectMapper();
		String jsonResponse = objectMapper.writeValueAsString(variables.get("restResult"));
		assertEquals("\"\"", jsonResponse);
		assertEquals("200", variables.get("restResponseCode"));
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testWorkItemForEmptyErrorResponse() throws JsonProcessingException {

		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("500", SIGNAL_NAME);

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put(SIGNAL_MAP, signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"version\":\"1.1.4\",\"restResult\":\"\",\"result\":\"\",\"restResponseCode\":\"500\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);

		// Assert for one active node instance : Workitemhandler
		assertEquals(2, activeNodes.size());

		// Assert "restResult" process variable to have value as xml message
		Map<String, Object> variables = processService.getProcessInstanceVariables(processInstanceId);

		ObjectMapper objectMapper = new ObjectMapper();
		String jsonResponse = objectMapper.writeValueAsString(variables.get("restResult"));
		assertEquals("\"\"", jsonResponse);
		assertEquals("500", variables.get("restResponseCode"));

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testCompleteReceiveTaskKeepsWaitingOnSuccess() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());

		Map<String, Object> vars = processService.getProcessInstanceVariables(processInstanceId);
		Boolean wsStageCompleted = (Boolean) vars.get("ws_stage_1");
		assertTrue(wsStageCompleted);

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testCompleteReceiveTaskKeepsWaitingOnFailStageNotCompleted() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"500\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		Map<String, Object> vars = processService.getProcessInstanceVariables(processInstanceId);
		Boolean wsStageCompleted = (Boolean) vars.get("ws_stage_1");
		assertTrue(wsStageCompleted);

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testCompleteReceiveTaskKeepsWaitingWhenSkipRESTIsFalse() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);
		params.put("SkipRESTOutbound", false);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"200\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());

		Map<String, Object> vars = processService.getProcessInstanceVariables(processInstanceId);
		Boolean wsStageCompleted = (Boolean) vars.get("ws_stage_1");
		assertTrue(wsStageCompleted);

		processService.abortProcessInstance(processInstanceId);
	}
	
	@Test
	public void testCompleteReceiveTaskAfterReceiveAPICall() {
		// Receive task is identified because it has a "correlationMap"
		// parameter
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> correlationMap = new HashMap<>();
		correlationMap.put("orderId", 123);
		params.put("correlationMap", correlationMap);
		params.put("_rt_receive-task-with-external-call_TestWorkItemHandler", "{\"receiveMessage\":\"Message already arrived\"}");

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_ID, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"200\"}");

		assertNull(processService.getProcessInstance(1L));
		Collection<VariableDesc> varList=runtimeDataService.getVariableHistory(processInstanceId, "receiveMsg", null);
		assertEquals(varList.iterator().next().getNewValue().toString(), "Message already arrived");
		
	}

	@Test
	public void testBoundarySignal() {
		Map<String, Object> signalMap = new HashMap<>();
		signalMap.put("500", "fail");

		Map<String, Object> params = new HashMap<>();
		params.put(HALT_ON_EXCEPTION, true);
		params.put("signalMap", signalMap);

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_BOUNDARY_SIGNAL_PROCESS,
				params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"500\"}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Fix Me", activeNodes.iterator().next().getName());
		//logger.debug("Active nodes: {}", activeNodes);
		//assertEquals(2, activeNodes.size());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testThrowOnExit() {
		Map<String, Object> params = new HashMap<>();

		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), THROW_ON_EXIT_WIH, params);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1",
				"{\"restResponseCode\":\"500\"}");

		// After completing, the OnExit action evaluates restResponseCode, if
		// equals 500, is throwing an exception that is catched by the exception
		// node, activating the Fix Me Human task.

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);

		/*
		 * Assert fix me task active
		 */
		assertEquals(1, activeNodes.size());
		assertEquals("Fix Me", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}
	
	@Test
	public void testWorkItemCompletedFailed() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_HT_PROCESS);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "5", "{}");
		
		try {
			logger.debug("Waiting 5 second for the work item to complete");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// This asserts that the state of the current process is in the human
		// task
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Test Work Item Handler", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}
	
	@Test
	public void testUTEServiceCall() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_HT_PROCESS);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "{ \"taskHeader\": { \"taskSource\": \"SCOTS-CPA\", \"userId\": null, \"creator\": \"ACELA\", \"orderInfo\": { \"customerName\": null, \"serviceOrderNumber\": null, \"workOrderNumber\": null, \"internalWorkOrderNumber\": null, \"relatedOrder\": null, \"orderVersion\": null, \"orderType\": null, \"orderSource\": \"NETPRO\", \"orderDueDate\": null, \"lineOfBusiness\": \"SCOTS-CPA\", \"product\": null, \"subProduct\": null, \"circuitID\": null, \"cddd\": null }, \"requestedDueDate\": null }, \"humanTaskInfoId\": null, \"historyEntryId\": null, \"externalTaskId\": \"11-voipcpa-uber$44539\", \"externalTaskIdList\": null, \"errorCode\": null, \"errorDesc\": null, \"jeopCode\": null, \"jeopDesc\": null, \"holdCode\": null, \"holdDesc\": null, \"createDate\": null, \"modifyDate\": null, \"modifiedBy\": null, \"taskAction\": \"COMPLETE_TASK\", \"taskOutcome\": null, \"workGroup\": null, \"workPool\": null, \"internalTaskId\": \"11-976661\", \"taskAttributes\": null, \"routingAttributes\": null, \"assigmentInfo\": null, \"task\": null, \"statusMessage\": \"Task Completed\", \"statusCode\": \"Success\", \"comment\": null, \"rerouteOnUpdate\": null, \"GSAM\": null, \"GARM\": null }");
		
		//Asserting workitem status when the external service response is from UTE
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Test Work Item Handler", activeNodes.iterator().next().getName());
		
		processService.abortProcessInstance(processInstanceId);
	}
}
