package com.verizon.sp.kie.et;

import static org.kie.server.remote.rest.common.util.RestUtils.buildConversationIdHeader;
import static org.kie.server.remote.rest.common.util.RestUtils.createResponse;
import static org.kie.server.remote.rest.common.util.RestUtils.errorMessage;
import static org.kie.server.remote.rest.common.util.RestUtils.getContentType;
import static org.kie.server.remote.rest.common.util.RestUtils.getVariant;
import static org.kie.server.remote.rest.common.util.RestUtils.internalServerError;
import static org.kie.server.remote.rest.common.util.RestUtils.notFound;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.JSON;
import static org.kie.server.remote.rest.jbpm.resources.Messages.PROCESS_INSTANCE_NOT_FOUND;

import java.text.MessageFormat;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Variant;

import org.jbpm.services.api.ProcessInstanceNotFoundException;
import org.jbpm.services.api.RuntimeDataService;
import org.kie.api.runtime.KieSession;
import org.kie.server.remote.rest.common.Header;
import org.kie.server.services.api.KieServerRegistry;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.sp.kie.et.model.ProcessInstanceTree;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

/**
 * Provides a kie-server extension that retrieves all the execution tree of the
 * elements related to a parent process instance. This endpoint locates the
 * parent process instance and returns the complete execution tree from the
 * parent process instance id and represents multi-instance sub-process
 * instances as an element of the executed node instance.
 *
 * @author motappa
 */
@Api(value = "Process Instance Tree")
@Path("verizon")
public class ProcessInstanceTreeResource extends AbstractExecutionTree {
	private static final Logger logger = LoggerFactory.getLogger(ProcessInstanceTreeResource.class);

	// @formatter:off
    public static final String GET_PROCESS_INSTANCE_TREE_RESPONSE_JSON = "{\n" +
    "  \"process-instance-id\":27,\n" +
    "  \"process-id\":\"sub-processes-kjar.the-parent\",\n" +
    "  \"process-name\":\"the-parent\",\n" +
    "  \"process-version\":\"1.0\",\n" +
    "  \"process-instance-state\":1,\n" +
    "  \"container-id\":\"sub-process-kjar_1.0.0-SNAPSHOT\",\n" +
    "  \"initiator\":\"pamAdmin\",\n" +
    "  \"start-date\":1585145321000,\n" +
    "  \"process-instance-desc\":\"the-parent\",\n" +
    "  \"correlation-key\":\"27\",\n" +
    "  \"parent-instance-id\":-1,\n" +
    "  \"sla-compliance\":0,\n" +
    "  \"sla-due-date\":null,\n" +
    "  \"active-user-tasks\":null,\n" +
    "  \"process-instance-variables\":null,\n" +
    "  \"process-nodes\":[\n" +
    "  {\n" +
    "    \"id\":1,\n" +
    "    \"nodeId\":\"_B4498D4D-9217-436C-AF9A-78970CE5E490\",\n" +
    "    \"name\":\"The Parent Task\",\n" +
    "    \"deploymentId\":\"sub-process-kjar_1.0.0-SNAPSHOT\",\n" +
    "    \"processInstanceId\":27,\n" +
    "    \"nodeType\":\"HumanTaskNode\",\n" +
    "    \"connection\":null,\n" +
    "    \"type\":1,\n" +
    "    \"dataTimeStamp\":1585145353000,\n" +
    "    \"workItemId\":25,\n" +
    "    \"referenceId\":null,\n" +
    "    \"nodeContainerId\":null,\n" +
    "    \"slaDueDate\":null,\n" +
    "    \"slaCompliance\":0,\n" +
    "    \"completed\":true,\n" +
    "    \"process-instance\":null,\n" +
    "    \"node-start-time\":{\n" +
    "      \"java.util.Date\":1585145353000\n" +
    "    },\n" +
    "    \"node-end-time\":{\n" +
    "      \"java.util.Date\":1585145353222\n" +
    "    }\n" +
    "  },\n" +
    "  {\n" +
    "    \"id\":3,\n" +
    "    \"nodeId\":\"_78F05C9E-1FC5-4E26-BB52-A3331BB6C30B\",\n" +
    "    \"name\":\"spB\",\n" +
    "    \"deploymentId\":\"sub-process-kjar_1.0.0-SNAPSHOT\",\n" +
    "    \"processInstanceId\":27,\n" +
    "    \"nodeType\":\"SubProcessNode\",\n" +
    "    \"connection\":\"_0DAA3970-13A5-466A-BD2B-8C64F0008A7E\",\n" +
    "    \"type\":0,\n" +
    "    \"dataTimeStamp\":1585145353000,\n" +
    "    \"workItemId\":null,\n" +
    "    \"referenceId\":28,\n" +
    "    \"nodeContainerId\":null,\n" +
    "    \"slaDueDate\":null,\n" +
    "    \"slaCompliance\":0,\n" +
    "    \"completed\":false,\n" +
    "    \"process-instance\":{\n" +
    "      \"process-instance-id\":28,\n" +
    "      \"process-id\":\"sub-processes-kjar.base-process\",\n" +
    "      \"process-name\":\"base-process\",\n" +
    "      \"process-version\":\"1.0\",\n" +
    "      \"process-instance-state\":1,\n" +
    "      \"container-id\":\"sub-process-kjar_1.0.0-SNAPSHOT\",\n" +
    "      \"initiator\":\"pamAdmin\",\n" +
    "      \"start-date\":1585145353000,\n" +
    "      \"process-instance-desc\":\"base-process\",\n" +
    "      \"correlation-key\":\"27:sub-processes-kjar.base-process:1585163353007\",\n" +
    "      \"parent-instance-id\":27,\n" +
    "      \"sla-compliance\":0,\n" +
    "      \"sla-due-date\":null,\n" +
    "      \"active-user-tasks\":{\n" +
    "      \"task-summary\":[\n" +
    "        {\n" +
    "        \"task-id\":18,\n" +
    "        \"task-name\":\"Base Process Task\",\n" +
    "        \"task-subject\":null,\n" +
    "        \"task-description\":\"\",\n" +
    "        \"task-status\":\"Ready\",\n" +
    "        \"task-priority\":0,\n" +
    "        \"task-is-skipable\":null,\n" +
    "        \"task-actual-owner\":\"\",\n" +
    "        \"task-created-by\":\"\",\n" +
    "        \"task-created-on\":{\n" +
    "          \"java.util.Date\":1585145353000\n" +
    "        },\n" +
    "        \"task-activation-time\":{\n" +
    "          \"java.util.Date\":1585145353000\n" +
    "        },\n" +
    "        \"task-expiration-time\":null,\n" +
    "        \"task-proc-inst-id\":28,\n" +
    "        \"task-proc-def-id\":\"sub-processes-kjar.base-process\",\n" +
    "        \"task-container-id\":\"sub-process-kjar_1.0.0-SNAPSHOT\",\n" +
    "        \"task-parent-id\":null\n" +
    "        }\n" +
    "      ]\n" +
    "    },\n" +
    "    \"process-instance-variables\":null,\n" +
    "    \"process-nodes\":[],\n" +
    "    \"node-start-time\":{\n" +
    "      \"java.util.Date\":1585145353000\n" +
    "    },\n" +
    "    \"node-end-time\":{\n" +
    "      \"java.util.Date\":1585145353222\n" +
    "    }\n" +
    "  	}\n" +
    "  }\n" +
    " ]\n" +
    " } \n";
    // @formatter:on

	public ProcessInstanceTreeResource() {
	}

	public ProcessInstanceTreeResource(RuntimeDataService dataService, KieServerRegistry context) {
		this.dataService = dataService;
		this.marshallerHelper = new MarshallerHelper(context);
		this.context = context;
	}

	public void setMarshallerHelper(MarshallerHelper marshallerHelper) {
		this.marshallerHelper = marshallerHelper;
	}

	/**
	 * Returns process instance execution tree with information about a
	 * specified process instance tree in a specified KIE Container.
	 *
	 * @param headers
	 * @param processInstanceId
	 *            Identifier of the base process instance to be fetched
	 * @param includeControlNodes
	 *            Optional flag to include control nodes, defaults to false
	 * @return {@link Response} with process instance execution tree JSON format
	 *         structure
	 */
	@ApiOperation(value = "Returns information about a specified process instance tree in a specified KIE Container.", response = ProcessInstanceTree.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process instance or Container Id not found"),
			@ApiResponse(code = 200, message = "Successful response", examples = @Example(value = {
					@ExampleProperty(mediaType = JSON, value = GET_PROCESS_INSTANCE_TREE_RESPONSE_JSON) })) })
	@GET
	@Path("processtree/{processInstanceId}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getProcessInstanceTree(@javax.ws.rs.core.Context HttpHeaders headers,
			@ApiParam(value = "identifier of the process instance to be fetched", required = true, example = "123") @PathParam("processInstanceId") Long processInstanceId,
			@ApiParam(value = "optional include control nodes, defaults to false", required = false) @QueryParam("includeControlNodes") boolean includeControlNodes) {
		Variant v = getVariant(headers);
		String type = getContentType(headers);
		Header conversationIdHeader = buildConversationIdHeader("", context, headers);

		try {
			/**
			 * Find root process using processId
			 *
			 */
			String response = pitByPid(processInstanceId, type, includeControlNodes);
			logger.debug("Returning OK response with content '{}'", response);
			return createResponse(response, v, Response.Status.OK, conversationIdHeader);
		} catch (ProcessInstanceNotFoundException e) {
			return notFound(MessageFormat.format(PROCESS_INSTANCE_NOT_FOUND, processInstanceId), v,
					conversationIdHeader);
		} catch (Exception e) {
			logger.error("Unexpected error during processing {}", e.getMessage(), e);
			return internalServerError(errorMessage(e), v);
		}
	}
	
	public void setKieSession(KieSession ksession) {
		this.ksession = ksession;
	}
}