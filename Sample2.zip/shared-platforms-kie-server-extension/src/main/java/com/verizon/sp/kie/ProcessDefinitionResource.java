package com.verizon.sp.kie;

import static org.kie.server.remote.rest.common.util.RestUtils.buildConversationIdHeader;
import static org.kie.server.remote.rest.common.util.RestUtils.createCorrectVariant;
import static org.kie.server.remote.rest.common.util.RestUtils.getVariant;
import static org.kie.server.remote.rest.common.util.RestUtils.internalServerError;
import static org.kie.server.remote.rest.common.util.RestUtils.notFound;
import static org.kie.server.remote.rest.jbpm.docs.ParameterSamples.JSON;
import static org.kie.server.remote.rest.jbpm.resources.Messages.PROCESS_DEFINITION_NOT_FOUND;
import static org.kie.server.remote.rest.jbpm.resources.Messages.UNEXPECTED_ERROR;

import java.text.MessageFormat;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Variant;

import org.jbpm.kie.services.impl.model.ProcessAssetDesc;
import org.jbpm.services.api.DefinitionService;
import org.jbpm.services.api.model.NodeDesc;
import org.kie.server.api.model.definition.NodeDefinition;
import org.kie.server.api.rest.RestURI;
import org.kie.server.remote.rest.common.Header;
import org.kie.server.services.api.KieServerRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.sp.kie.model.ProcessDefinition;
import com.verizon.sp.kie.util.ParameterSamples;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

@Api(value = "Verizon Process Definitions")
@Path("verizon/server/" + RestURI.PROCESS_DEF_URI)
public class ProcessDefinitionResource {

	private static final Logger logger = LoggerFactory.getLogger(ProcessDefinitionResource.class);

	private DefinitionService definitionService;
	private KieServerRegistry context;

	public ProcessDefinitionResource() {
	}

	public ProcessDefinitionResource(DefinitionService definitionService, KieServerRegistry context) {
		this.definitionService = definitionService;
		this.context = context;
	}

	protected static String getRelativePath(HttpServletRequest httpRequest) {
		String url = httpRequest.getRequestURI();
		url = url.replaceAll(".*/rest", "");
		return url;
	}

	@ApiOperation(value = "Returns entity and task information for a specified process.", response = ProcessDefinition.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process or Container Id not found"),
			@ApiResponse(code = 200, message = "Successfull response") })
	@GET
	@Path(RestURI.PROCESS_DEF_GET_URI)
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getCompleteProcessDefinition(@Context HttpHeaders headers,
			@ApiParam(value = "Container id where the process definition resides", required = true, example = "evaluation_1.0.0-SNAPSHOT") @PathParam(RestURI.CONTAINER_ID) String containerId,
			@ApiParam(value = "Process id that the definition should be retrieved for", required = true, example = "evaluation") @PathParam(RestURI.PROCESS_ID) String processId) {

		logger.info("Verizon KIE Server Extension: getCompleteProcessDefinition(containerID=" + containerId
				+ ", processID=" + processId + ")");
		Variant v = getVariant(headers);
		Header conversationIdHeader = buildConversationIdHeader(containerId, context, headers);

		try {
			// Get the process definition
			ProcessAssetDesc pad = (ProcessAssetDesc) definitionService.getProcessDefinition(containerId, processId);

			// Map the original process definition to the new one
			ProcessDefinition processDefinition = new ProcessDefinition();
			processDefinition.setId(pad.getId());
			processDefinition.setContainerId(containerId);
			processDefinition.setDynamic(pad.isDynamic());

			// Walk the nodes, looking for sub-process nodes to expand upon
			for (NodeDesc nodeDesc : pad.getNodes()) {
				NodeDefinition nodeDefinition = new NodeDefinition();
				nodeDefinition.setId(nodeDesc.getId());

			}

			// Format the response
			return createCorrectVariant(processDefinition, headers, Response.Status.OK, conversationIdHeader);
		} catch (IllegalStateException e) {
			return notFound(MessageFormat.format(PROCESS_DEFINITION_NOT_FOUND, processId, containerId), v,
					conversationIdHeader);
		} catch (Exception e) {
			return internalServerError(MessageFormat.format(UNEXPECTED_ERROR, e.getMessage()), v, conversationIdHeader);
		}
	}
}