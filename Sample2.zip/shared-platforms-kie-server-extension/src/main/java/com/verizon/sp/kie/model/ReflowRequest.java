/**
 * 
 */
package com.verizon.sp.kie.model;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author tordi7z
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "verizon-reflow-task")
public class ReflowRequest {

	@XmlElement(name = "compensation-name")
	private String compensationName;
	@XmlElement(name = "process-vars")
	private Map<String, Object> processVars;
	@XmlElement(name = "death-pool")
	private List<String> deathPool;

	public String getCompensationName() {
		return compensationName;
	}

	public void setCompensationName(String compensationName) {
		this.compensationName = compensationName;
	}


	public Map<String, Object> getProcessVars() {
		return processVars;
	}

	public void setProcessVars(Map<String, Object> processVars) {
		this.processVars = processVars;
	}

	public List<String> getDeathPool() {
		return deathPool;
	}

	/**
	 * Sets the list of nodes to be cancelled during reflow
	 * @param listOfNodesToCancel
	 */
	public void setDeathPool(List<String> deathPool) {
		this.deathPool = deathPool;
	}

}
