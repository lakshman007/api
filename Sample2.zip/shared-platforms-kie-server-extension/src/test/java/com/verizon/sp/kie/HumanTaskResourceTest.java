package com.verizon.sp.kie;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.UserTaskInstanceDesc;
import org.junit.Test;
import org.kie.api.runtime.query.QueryContext;

public class HumanTaskResourceTest extends ExternalCallerAbstractTest {

	/*@Test
	public void testHumanTaskCompleteStatus() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), HT_PROCESS);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "{}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		// Complete work item comes in for the Human task
		String htNodeInstanceId = String.valueOf(activeNodes.iterator().next().getWorkItemId());
		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), htNodeInstanceId,
				"{}");

		// Assert the human task is not completed
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		humanTaskResource.completeHumanTask(processInstanceId, "Example Human Task", "{}");

	}

	@Test
	public void testNoHumanTasksAvaliable() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(),
				WIH_RECEIVE_TASK_PROCESS_NAME);
		assertNotNull(processInstanceId);
		Response response = humanTaskResource.completeHumanTask(processInstanceId, "Example Human Task", "{}");
		assertEquals(response.getStatus(), 404);
		assertEquals(response.getEntity().toString(),
				"{\"Error\": \"No active human task found for processInstanceId: "+processInstanceId+"\"}");
		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testNoAvaliableTaskName() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), HT_PROCESS);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "{}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		// Complete work item comes in for the Human task
		String htNodeInstanceId = String.valueOf(activeNodes.iterator().next().getWorkItemId());
		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), htNodeInstanceId,
				"{}");

		// Assert the human task is not completed
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		Response response = humanTaskResource.completeHumanTask(processInstanceId, "Example Human", "{}");

		assertEquals(response.getStatus(), 404);
		assertEquals(response.getEntity().toString(),
				"{\"Error\": \"No active tasks with task name: " + "Example Human" + "\"}");
		processService.abortProcessInstance(processInstanceId);

	}

	@Test
	public void testIncorrectProcessInstance() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), HT_PROCESS);
		assertNotNull(processInstanceId);

		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), "1", "{}");

		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		// Complete work item comes in for the Human task
		String htNodeInstanceId = String.valueOf(activeNodes.iterator().next().getWorkItemId());
		completeWorkItemAndWait(deploymentUnit.getIdentifier(), String.valueOf(processInstanceId), htNodeInstanceId,
				"{}");

		// Assert the human task is not completed
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Example Human Task", activeNodes.iterator().next().getName());

		Response response = humanTaskResource.completeHumanTask(20L, "Example Human Task", "{}");
		assertEquals(response.getStatus(), 404);

		assertEquals(response.getEntity().toString(),"{\"Error\": \"No active human task found for processInstanceId: 20\"}");
		processService.abortProcessInstance(processInstanceId);

	}*/
	
	
	/*==============Complete Task API status Code changes Test Cases==================*/
	
	@Test
	public void humanTaskCompleteTestusingTasknstanceId() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), HT_PROCESS_Test_APIStatuscode);
		assertNotNull(processInstanceId);
		
		UserTaskInstanceDesc utid=runtimeDataService.getProcessInstanceById(processInstanceId).getActiveTasks().get(0);
		long taskinstanceid=utid.getTaskId();
		Map<String, Object> person=new HashMap<String, Object>();
		person.put("firstName", "Lak");
		person.put("lastName", "cher");
		person.put("age", 12);		
		Map<String, Object> outputvariables=new HashMap<String, Object>();
		outputvariables.put("Person", person);
		Response response = humanTaskResource.completeUserTask(testHeaders(), taskinstanceid, "pamAdmin", true, outputvariables);
		assertEquals(response.getStatus(),200);
		assertEquals(response.getEntity().toString(),"{\"statusCode\":0, \"errorCode\":\"SUCCESS\"}");
		processService.abortProcessInstance(processInstanceId);
	  }

}
