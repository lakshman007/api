package com.jbpm.web.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.kie.server.client.UserTaskServicesClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jbpm.beans.Model;
import com.jbpm.constants.JBPMConstants;
import com.jbpm.services.JBPMService;

@RestController
@RequestMapping(produces = { MediaType.APPLICATION_JSON_UTF8_VALUE })
public class JBPMController {
	private static final Logger logger = LoggerFactory.getLogger(JBPMController.class);

	ObjectMapper objectMapper = new ObjectMapper();
	@Autowired
	private JBPMService service;

	final String CONTAINER_ID = "APITest_1.0.0";

	@PostMapping(value = "/completetask/{id}", consumes = { MediaType.APPLICATION_JSON_UTF8_VALUE })
	public String completeTask(@RequestBody String jsonInput, HttpServletRequest request,
			@PathVariable("id") Long taskId) throws JsonParseException, JsonMappingException, IOException {
		logger.debug("[completetask]");
		String response = null;

		try {
			// Initiate task client
			UserTaskServicesClient taskServices = service.getTaskClient();

			Map<String, Object> params = new HashMap<String, Object>();
			Model m = objectMapper.readValue(jsonInput, Model.class);
			params.put("model", m);

			taskServices.startTask(CONTAINER_ID, taskId, JBPMConstants.JBPM_USER);
			taskServices.completeTask(CONTAINER_ID, taskId, JBPMConstants.JBPM_USER, params);
			response = "Success";

		} catch (Exception e) {
			logger.error("[completetask][Exception]-->", e);
			response = "Error";
		}
		logger.debug("[completetask][End]");
		return response;
	}

}
