/**
 * 
 */
package com.verizon.sp.kie.test;

/**
 * @author tordi7z
 *
 */
public class TestException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public TestException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TestException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TestException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TestException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TestException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
