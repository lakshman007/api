package com.verizon.sp.kie;

import static org.kie.server.remote.rest.common.util.RestUtils.getContentType;
import static org.kie.server.remote.rest.common.util.RestUtils.getVariant;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Variant;

import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.TaskNotFoundException;
import org.jbpm.services.api.UserTaskService;
import org.kie.api.task.model.TaskSummary;
import org.kie.internal.query.QueryFilter;
import org.kie.server.services.impl.marshal.MarshallerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;

@Api(value = "Verizon Human Task")
@Path("verizon/server")
public class HumanTaskResource {

	private static final Logger logger = LoggerFactory.getLogger(HumanTaskResource.class);

	private RuntimeDataService runtimeDataService;
	private UserTaskService userTaskService;
	
	private MarshallerHelper marshallerHelper;
	
	public static final String COMPLETE_USERTASK_JSON = "{\n" +
            "    \"Age\" : 30,\n" +
            "    \"person\" : {\n" + 
            "        \"First name\" : \"John\",\n" +
            "        \"Last name\" : \"smith\",\n" +
            "        \"ID\" : \"1345\"\n" +
            "    }\n" +
            "}";

	public HumanTaskResource(RuntimeDataService runtimeDataService, UserTaskService userTaskService
			) {
		// TODO Auto-generated constructor stub

		this.runtimeDataService = runtimeDataService;
		this.userTaskService = userTaskService;
		this.marshallerHelper = new MarshallerHelper(null);
	}

	@ApiOperation(value = "Complete Human Task based on taskname aand processinstanceid", response = String.class, code = 200)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message = "Process instance, Container id or node name not found"),
			@ApiResponse(code = 200, message = "{\"Result\": \"Succesfull\"}", examples = @Example(value = {
					@ExampleProperty(mediaType = "text/plain", value = "Successful") })) })
	@POST
	@Path("/processes/instances/{processInstanceId}/taskcompletion/{taskName}")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.TEXT_PLAIN })
	public Response completeHumanTask(
			@ApiParam(value = "identifier of the process instance to be modified", required = true, example = "123") @PathParam("processInstanceId") Long processInstanceId,
			@ApiParam(value = "task name to complete", required = true, example = "TaskA") @PathParam("taskName") String taskName,
			@ApiParam(value = "payload fpr complete task", required = false, examples = @Example(value = {
					@ExampleProperty(mediaType = "application/json", value = "{}") })) String payload) {

		logger.info("completing human task with process Instance id: {} and taskName: {}", processInstanceId, taskName);
		Map<String, Object> payloadItems = new HashMap<>();

		try {

			if (null != payload && !payload.isEmpty()) {
				payloadItems = marshallerHelper.unmarshal(payload, "application/json", Map.class);
			}

			List<TaskSummary> taskSummaryList = runtimeDataService
					.getTasksByStatusByProcessInstanceId(processInstanceId, null, new QueryFilter(0, 1000));
			if (taskSummaryList.isEmpty()) {
				return Response.status(Status.NOT_FOUND).entity("{\"Error\": \"No active human task found for processInstanceId: "+processInstanceId+"\"}").build();
			}

			for (TaskSummary task : taskSummaryList) {

				if (task.getName().equals(taskName)) {
					logger.debug("Task Name : {}", taskName);
					userTaskService.completeAutoProgress(task.getId(), task.getActualOwnerId(), payloadItems);
					return Response.ok().entity("{\"Result\": \"Succesfull\"}").build();
				}
			}
		} catch (TaskNotFoundException e) {
			logger.error("Task not  found exception: {}", e);
			return Response.status(Status.NOT_FOUND).entity("{\"Error\": \"Task not found\"}").build();
		} catch (Exception e) {
			logger.error("Exception while triggering node", e);

			return Response.status(Status.INTERNAL_SERVER_ERROR).entity("{\"Error\":" + e.getMessage() + "}").build();
		}

		return Response.status(Status.NOT_FOUND)
				.entity("{\"Error\": \"No active tasks with task name: " + taskName + "\"}").build();
	}
	
	
	
	@ApiOperation(value = "Completes Specified User Task in a specified KIE Container.", code = 200)
	@ApiResponses(value = { @ApiResponse(code = 500, message = "Unexpected error"),
			@ApiResponse(code = 404, message="User Task Not Found"),
			@ApiResponse(code = 200,message="SUCCESS")/* examples = @Example(value = {
					@ExampleProperty(mediaType ="application/json", value = "NO-Content") }))*/ })
	@PUT
	@Path("container/{containerId}/tasks/{taskInstanceId}/states/completed")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN })
	public Response completeUserTask(@javax.ws.rs.core.Context HttpHeaders headers,
			/*@ApiParam(value = "identifier of the Container to be fetched", required = true, example = "Example_1.0.3-SNAPSHOT") @PathParam("containerId") String containerId,*/
			@ApiParam(value = "identifier of the TaskInstance to be fetched", required = true, example = "12") @PathParam("taskInstanceId") Long taskInstanceId,
			@ApiParam(value = "optional user id to be used instead of authenticated user - only when bypass authenticated user is enabled", required = false) @QueryParam("user") String user,
			@ApiParam(value = "optional flag that allows to directly claim and start task (if needed) before completion", required = false) @QueryParam("auto-progress") boolean autoprogress,
			@ApiParam(value = "Optional Output Variables can be passed to User Task", required = false, examples=@Example(value= {
                    @ExampleProperty(mediaType ="application/json", value=COMPLETE_USERTASK_JSON)})) Map<String, Object> outputvariables) {
		
		Variant v = getVariant(headers);
		String type = getContentType(headers);
		Response resp=null;
		String response=null;
		String containerId=null;
	try {
		try {
			if (runtimeDataService.getTaskById(taskInstanceId) == null) {
				  throw new TaskNotFoundException("No task found with id ");}
			if(!runtimeDataService.getTaskById(taskInstanceId).getStatus().equalsIgnoreCase("Completed")) 
			{
				containerId=runtimeDataService.getTaskById(taskInstanceId).getDeploymentId();
				response=runtimeDataService.getTaskById(taskInstanceId).getStatus();
				logger.debug("taskInstanceId is: "+taskInstanceId+" containerId is: "+containerId);
				if(autoprogress==true) {
			userTaskService.completeAutoProgress(containerId, taskInstanceId, user, outputvariables);
			logger.debug("Completed by AutoProgress");
			return Response.ok().entity("{\"statusCode\":0, \"errorCode\":\"SUCCESS\"}").build();
				}
				else {
					userTaskService.complete(containerId, taskInstanceId, user, outputvariables);
					return Response.ok().entity("{\"statusCode\":0, \"errorCode\":\"SUCCESS\"}").build();
				}
			}
			else {
				logger.info("came into Already Complete");
				return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":-1, \"errorCode\":\"FLOW_NODE_NOT_ACTIVE\"}").build();
				}
		   }
			catch (TaskNotFoundException e){
				e.printStackTrace();
				return Response.status(Status.NOT_FOUND).entity("{\"statusCode\":1, \"errorCode\":\"FLOW_NODE_NOT_PRESENT\"}").build();
			}
		}
	catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity("{\"statusCode\":3, \"errorCode\":\"UnExpected error\"}").build();
		}
	}
		

}
