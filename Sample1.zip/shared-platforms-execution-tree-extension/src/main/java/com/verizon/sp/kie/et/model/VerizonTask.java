package com.verizon.sp.kie.et.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "node-instance")
public class VerizonTask implements Serializable {
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "taskName")
	String taskName;

	@XmlElement(name = "startDate")
	String startDate;

	@XmlElement(name = "startDateMillis")
	Long startDateMillis;

	@XmlElement(name = "endDateMillis")
	Long endDateMillis;

	@XmlElement(name = "endDate")
	String endDate;

	@XmlElement(name = "taskId")
	Long taskId;

	@XmlElement(name = "parentContainerId")
	Long parentContainerId;

	@XmlElement(name = "rootContainerId")
	Long rootContainerId;

	@XmlElement(name = "parentName")
	String parentName;

	@XmlElement(name = "taskType")
	String taskType;

	@XmlElement(name = "taskStatus")
	String taskStatus;

	@XmlElement(name = "sourceObjectId")
	Long sourceObjectId;

	@XmlElement(name = "subWorkFlow")
	List<VerizonTask> subWorkFlow = new ArrayList<VerizonTask>();

	public VerizonTask() {
		super();
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public Long getStartDateMillis() {
		return startDateMillis;
	}

	public void setStartDateMillis(Long startDateMillis) {
		this.startDateMillis = startDateMillis;
	}

	public Long getEndDateMillis() {
		return endDateMillis;
	}

	public void setEndDateMillis(Long endDateMillis) {
		this.endDateMillis = endDateMillis;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public Long getParentContainerId() {
		return parentContainerId;
	}

	public void setParentContainerId(Long parentContainerId) {
		this.parentContainerId = parentContainerId;
	}

	public Long getRootContainerId() {
		return rootContainerId;
	}

	public void setRootContainerId(Long rootContainerId) {
		this.rootContainerId = rootContainerId;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public Long getSourceObjectId() {
		return sourceObjectId;
	}

	public void setSourceObjectId(Long sourceObjectId) {
		this.sourceObjectId = sourceObjectId;
	}

	public List<VerizonTask> getSubWorkFlow() {
		return subWorkFlow;
	}

	public void setSubWorkFlow(List<VerizonTask> subWorkFlow) {
		this.subWorkFlow = subWorkFlow;
	}

	@Override
	public String toString() {
		return "VerizonTask [taskName=" + taskName + ", startDate=" + startDate + ", startDateMillis=" + startDateMillis
				+ ", endDateMillis=" + endDateMillis + ", endDate=" + endDate + ", taskId=" + taskId
				+ ", parentContainerId=" + parentContainerId + ", rootContainerId=" + rootContainerId + ", parentName="
				+ parentName + ", taskType=" + taskType + ", taskStatus=" + taskStatus + ", sourceObjectId="
				+ sourceObjectId + ", subWorkFlow=" + subWorkFlow + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + ((endDateMillis == null) ? 0 : endDateMillis.hashCode());
		result = prime * result + ((parentContainerId == null) ? 0 : parentContainerId.hashCode());
		result = prime * result + ((parentName == null) ? 0 : parentName.hashCode());
		result = prime * result + ((rootContainerId == null) ? 0 : rootContainerId.hashCode());
		result = prime * result + ((sourceObjectId == null) ? 0 : sourceObjectId.hashCode());
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((startDateMillis == null) ? 0 : startDateMillis.hashCode());
		result = prime * result + ((subWorkFlow == null) ? 0 : subWorkFlow.hashCode());
		result = prime * result + ((taskId == null) ? 0 : taskId.hashCode());
		result = prime * result + ((taskName == null) ? 0 : taskName.hashCode());
		result = prime * result + ((taskStatus == null) ? 0 : taskStatus.hashCode());
		result = prime * result + ((taskType == null) ? 0 : taskType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VerizonTask other = (VerizonTask) obj;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (endDateMillis == null) {
			if (other.endDateMillis != null)
				return false;
		} else if (!endDateMillis.equals(other.endDateMillis))
			return false;
		if (parentContainerId == null) {
			if (other.parentContainerId != null)
				return false;
		} else if (!parentContainerId.equals(other.parentContainerId))
			return false;
		if (parentName == null) {
			if (other.parentName != null)
				return false;
		} else if (!parentName.equals(other.parentName))
			return false;
		if (rootContainerId == null) {
			if (other.rootContainerId != null)
				return false;
		} else if (!rootContainerId.equals(other.rootContainerId))
			return false;
		if (sourceObjectId == null) {
			if (other.sourceObjectId != null)
				return false;
		} else if (!sourceObjectId.equals(other.sourceObjectId))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (startDateMillis == null) {
			if (other.startDateMillis != null)
				return false;
		} else if (!startDateMillis.equals(other.startDateMillis))
			return false;
		if (subWorkFlow == null) {
			if (other.subWorkFlow != null)
				return false;
		} else if (!subWorkFlow.equals(other.subWorkFlow))
			return false;
		if (taskId == null) {
			if (other.taskId != null)
				return false;
		} else if (!taskId.equals(other.taskId))
			return false;
		if (taskName == null) {
			if (other.taskName != null)
				return false;
		} else if (!taskName.equals(other.taskName))
			return false;
		if (taskStatus == null) {
			if (other.taskStatus != null)
				return false;
		} else if (!taskStatus.equals(other.taskStatus))
			return false;
		if (taskType == null) {
			if (other.taskType != null)
				return false;
		} else if (!taskType.equals(other.taskType))
			return false;
		return true;
	}

}