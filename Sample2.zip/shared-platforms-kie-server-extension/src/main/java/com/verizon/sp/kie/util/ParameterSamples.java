package com.verizon.sp.kie.util;


public class ParameterSamples {

    public static final String CREATE_CONTAINER_JSON = "{\n" +
            "    \"container-alias\" : \"baz\",\n" +
            "    \"release-id\" : {\n" + 
            "        \"group-id\" : \"foo\",\n" +
            "        \"artifact-id\" : \"bar\",\n" +
            "        \"version\" : \"1.0\"\n" +
            "    }\n" +
            "}";

    public static final String CREATE_CONTAINER_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" + 
            "<kie-container container-alias=\"baz\">\n" +
            "    <release-id>\n" + 
            "        <group-id>foo</group-id>\n" +
            "        <artifact-id>bar</artifact-id>\n" + 
            "        <version>1.0</version>\n" +
            "    </release-id>\n" +
            "</kie-container>\n";
}