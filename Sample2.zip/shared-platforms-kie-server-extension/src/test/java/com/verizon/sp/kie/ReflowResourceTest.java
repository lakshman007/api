package com.verizon.sp.kie;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.jbpm.services.api.admin.ProcessInstanceAdminService;
import org.jbpm.services.api.model.DeploymentUnit;
import org.jbpm.services.api.model.NodeInstanceDesc;
import org.jbpm.services.api.model.ProcessInstanceDesc;
import org.jbpm.services.api.model.UserTaskInstanceDesc;
import org.jbpm.services.api.model.VariableDesc;
import org.junit.Test;
import org.kie.api.runtime.query.QueryContext;
import org.kie.api.task.model.Status;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReflowResourceTest extends ExternalCallerAbstractTest {
	private static Logger logger = LoggerFactory.getLogger(ReflowResourceTest.class);

	protected static final String ARTIFACT_ID = "test-module";
	protected static final String GROUP_ID = "com.verizon.pam";
	protected static final String VERSION = "1.0.0";

	protected static final String REFLOW_STRAIGHT = "reflow-straight-ht";
	protected static final String REFLOW_PARALLEL = "reflow-parallel-ht";
	protected static final String MULTI_GATEWAY_PROCESS = "test-resources.multi-gateway-process";
	protected static final String REFLOW_PARENT = "reflow-parent-ht";

	private ProcessInstanceAdminService processAdminService;
	private ReflowResource reflowResource;

	@Override
	protected List<String> getProcessDefinitionFiles() {
		return Arrays.asList("reflow-straight-ht.bpmn", "reflow-parallel-ht.bpmn", "multi-gateway-process.bpmn",
				"reflow-parent-ht.bpmn", "wih-ht-process.bpmn");
	}

	@Override
	protected DeploymentUnit prepareDeploymentUnit() throws Exception {
		return createAndDeployUnit(GROUP_ID, ARTIFACT_ID, VERSION);
	}

	@Override
	protected void configureServices() {
		super.configureServices();
		this.processAdminService = serviceConfigurator.getProcessAdminService();
		this.reflowResource = new ReflowResource(processService, runtimeDataService, processAdminService);
	}

	@Override
	protected boolean createDescriptor() {
		return true;
	}

	@Test
	public void testReflowTask() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), REFLOW_STRAIGHT);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Task B"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task B", activeNodes.iterator().next().getName());

		String reflowRequest = "{\"death-pool\": [ \"Task B\"]}";

		reflowResource.reflow(processInstanceId, "Task A", reflowRequest);

		// Assert that the state of the process is in "Task A" (Again)
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testReflowTaskCompensation() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), REFLOW_STRAIGHT);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Task B"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task B", activeNodes.iterator().next().getName());

		String reflowRequest = "{\"compensation-name\": \"reflowSignal\"}";

		reflowResource.reflow(processInstanceId, "Task A", reflowRequest);

		// Assert that the state of the process is in "Task A" (Again), and
		// "Task D" for compensation is also waiting.
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(3, activeNodes.size());
		boolean compTask = false;
		boolean reflowedTask = false;
		for (NodeInstanceDesc nodeinstance : activeNodes) {
			if (nodeinstance.getName().equals("Task D")) {
				compTask = true;
			} else if ("Task A".equals(nodeinstance.getName())) {
				reflowedTask = true;
			}
		}
		// Assert that the state of the process is in "Task D"
		assertTrue(compTask);
		assertTrue(reflowedTask);
		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testReflowTaskProcessVars() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), REFLOW_STRAIGHT);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Task B"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task B", activeNodes.iterator().next().getName());

		String reflowRequest = "{\"process-vars\" : {\"nodeType\" : \"HumanTask\"}, \"death-pool\": [ \"Task B\"]}";

		reflowResource.reflow(processInstanceId, "Task A", reflowRequest);

		// Assert that the state of the process is in "Task A" (Again)
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());
		Collection<VariableDesc> processVar = (List<VariableDesc>) runtimeDataService
				.getVariableHistory(processInstanceId, "nodeType", new QueryContext());

		// Assert that the process variable nodeType value is HumanTask
		assertEquals("HumanTask", processVar.iterator().next().getNewValue());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testReflowTaskCancelNodes() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), REFLOW_PARALLEL);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Task B"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(3, activeNodes.size());

		String reflowRequest = "{\"death-pool\": [ \"Task B\", \"Signal\", \"Task D\"]}";

		reflowResource.reflow(processInstanceId, "Task A", reflowRequest);

		// Assert that the state of the process is in "Task A" (Again)
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testReflowTaskCancelAllNodes() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), REFLOW_PARALLEL);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Task B"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(3, activeNodes.size());

		String reflowRequest = "{\"death-pool\": [ \"ALL\"]}";

		reflowResource.reflow(processInstanceId, "Task A", reflowRequest);

		// Assert that the state of the process is in "Task A" (Again)
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testRestartHumanTask() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), REFLOW_STRAIGHT);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		UserTaskInstanceDesc userTask = runtimeDataService
				.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId());
		Long initialId = userTask.getTaskId();
		assertEquals(Status.Ready.name(), userTask.getStatus());

		// Claim the task
		userTaskService.claim(userTask.getTaskId(), "Administrator");

		// Assert task new status (Reserved)
		userTask = runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId());
		assertEquals(Status.Reserved.name(), userTask.getStatus());

		// Restart the task
		String reflowRequest = "{\"death-pool\": [ \"Task A\"]}";
		reflowResource.reflow(processInstanceId, "Task A", reflowRequest);

		// Assert that process continues to wait for "Task A"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Assert that Task A has a different id now
		userTask = runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId());
		Long newId = userTask.getTaskId();
		assertNotEquals(initialId, newId);

		// Assert that status was reset to Ready
		assertEquals(Status.Ready.name(), userTask.getStatus());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testRestartServiceTask() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), WIH_HT_PROCESS);
		// Long processInstanceId =
		// processService.startProcess(deploymentUnit.getIdentifier(),
		// "test-resources.test-gateway");
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Test Work Item Handler", activeNodes.iterator().next().getName());
		// assertEquals("Decision Task",
		// activeNodes.iterator().next().getName());

		// Restart the task
		String reflowRequest = "{\"death-pool\": [ \"ALL\"]}";
		reflowResource.reflow(processInstanceId, "Test Work Item Handler", reflowRequest);

		// Assert that process continues to wait for "Task A"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Test Work Item Handler", activeNodes.iterator().next().getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testReflowToSingleBranch() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), MULTI_GATEWAY_PROCESS);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task A"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());

		// Claim and complete Task 1
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Claim and complete Task 2 and Task 3
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());

		for (NodeInstanceDesc node : activeNodes) {
			logger.debug("Should I complete node {}?", node.getName());
			if ("Task 2".equals(node.getName()) || "Task 3".equals(node.getName())) {
				logger.debug("Completing Human task {}", node.getName());
				userTaskService.completeAutoProgress(
						runtimeDataService.getTaskByWorkItemId(node.getWorkItemId()).getTaskId(), "Administrator",
						new HashMap<String, Object>());

			}
		}

		// Assert that the state of the process is in "Task 4"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task 4", activeNodes.iterator().next().getName());

		String reflowRequest = "{\"death-pool\": [ \"Task 4\"]}";

		reflowResource.reflow(processInstanceId, "Task 2", reflowRequest);

		// Assert that the state of the process is in "Task 2"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task 2", activeNodes.iterator().next().getName());

		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Task 4" (Again)
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		NodeInstanceDesc lastActiveNode = activeNodes.iterator().next();
		logger.debug("node {} with type {}", lastActiveNode, lastActiveNode.getNodeType());

		// FIXME: The expected result is failing, after completing task 2, the
		// next active node should be task 4 again, but the process instance
		// keep waiting in the gateway.
		// assertEquals("Task 4", activeNodes.iterator().next().getName());

		// ********************
		// TESTING WORKAROUND:
		// Notice that the current active "Task" is the Join gateway, after
		// completing "Task 2" users will need to come back and reflow "Task 4"
		// ********************
		reflowRequest = "{\"death-pool\": [ \"ALL\"]}";
		reflowResource.reflow(processInstanceId, "Task 4", reflowRequest);
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		lastActiveNode = activeNodes.iterator().next();
		logger.debug("node {} with type {}", lastActiveNode, lastActiveNode.getNodeType());
		assertEquals("Task 4", lastActiveNode.getName());

		processService.abortProcessInstance(processInstanceId);
	}

	@Test
	public void testReflowTaskSubProcess() {
		Long processInstanceId = processService.startProcess(deploymentUnit.getIdentifier(), REFLOW_PARENT);
		assertNotNull(processInstanceId);

		// Assert that the state of the process is in "Task X"
		Collection<NodeInstanceDesc> activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId,
				new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task X", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		// Assert that the state of the process is in "Sub-process"
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Sub-process", activeNodes.iterator().next().getName());

		// Get the sub-process instance
		Collection<ProcessInstanceDesc> subProcessInstance = runtimeDataService
				.getProcessInstancesByParent(processInstanceId, new ArrayList<Integer>(), new QueryContext());
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(subProcessInstance.iterator().next().getId(),
				new QueryContext());

		// Assert that the child process instances are not empty
		assertTrue(!subProcessInstance.isEmpty());

		// Assert that the state of the process is in "Task A"
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task A", activeNodes.iterator().next().getName());

		// Claim and complete task
		userTaskService.completeAutoProgress(
				runtimeDataService.getTaskByWorkItemId(activeNodes.iterator().next().getWorkItemId()).getTaskId(),
				"Administrator", new HashMap<String, Object>());

		String reflowRequest = "{\"death-pool\": [\"ALL\"]}";

		reflowResource.reflow(processInstanceId, "Task X", reflowRequest);

		// Assert that the state of the process is in "Task X" (Again)
		activeNodes = runtimeDataService.getProcessInstanceHistoryActive(processInstanceId, new QueryContext());
		assertNotNull(activeNodes);
		assertEquals(1, activeNodes.size());
		assertEquals("Task X", activeNodes.iterator().next().getName());

		subProcessInstance = runtimeDataService.getProcessInstancesByParent(processInstanceId, new ArrayList<Integer>(),
				new QueryContext());

		// Assert that the child process instances are empty
		assertTrue(subProcessInstance.isEmpty());

		processService.abortProcessInstance(processInstanceId);
	}
}
