package com.verizon.sp.kie.et.model;

import java.util.Arrays;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.kie.server.api.model.instance.ProcessInstance;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "process-instance-tree")
public class ProcessInstanceTree extends ProcessInstance {
    @XmlElement(name = "process-nodes")
    private NodeInstanceTree[] processNodes;

    /**
     * @return ProcessNodeList return the nodes
     */
    public NodeInstanceTree[] getProcessNodes() {
        return processNodes;
    }

    /**
     * @param processNodes the nodes to set
     */
    public void setProcessNodes(NodeInstanceTree[] processNodes) {
        this.processNodes = processNodes;
    }

	@Override
	public String toString() {
		return "ProcessInstanceTree [processNodes=" + Arrays.toString(processNodes) + ", getId()=" + getId()
				+ ", getProcessId()=" + getProcessId() + ", getProcessName()=" + getProcessName()
				+ ", getProcessVersion()=" + getProcessVersion() + ", getState()=" + getState() + ", getContainerId()="
				+ getContainerId() + ", getInitiator()=" + getInitiator() + ", getDate()=" + getDate()
				+ ", getProcessInstanceDescription()=" + getProcessInstanceDescription() + ", getCorrelationKey()="
				+ getCorrelationKey() + ", getParentId()=" + getParentId() + ", getVariables()=" + getVariables()
				+ ", getActiveUserTasks()=" + getActiveUserTasks() + ", getSlaCompliance()=" + getSlaCompliance()
				+ ", getSlaDueDate()=" + getSlaDueDate() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
}