package com.jbpm.beans;

import java.io.Serializable;

public class Model implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long itemId;
	private String currentStatus;
	private String Action;
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getAction() {
		return Action;
	}
	public void setAction(String action) {
		Action = action;
	}
	
	

}
