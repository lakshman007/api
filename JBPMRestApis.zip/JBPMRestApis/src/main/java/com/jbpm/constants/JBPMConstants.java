package com.jbpm.constants;

/**
 *
 *
 */
public class JBPMConstants {
	private JBPMConstants(){
		throw new IllegalStateException("JBPMConstants class");

	}
	public static final String JBPM_CONTAINER_ID="jbpm.containerId";
	public static final String JBPM_SERVER_URL="jbpm.server.url";
	public static final String JBPM_USER="jbpm.user";
	public static final String JBPM_PASSWORD ="jbpm.password";
	public static final String JBPM_PROCESS_ID ="jbpm.process.id";
	
}
